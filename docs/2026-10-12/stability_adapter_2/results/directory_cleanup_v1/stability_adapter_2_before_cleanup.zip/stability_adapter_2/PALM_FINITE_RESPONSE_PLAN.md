# 손바닥 지지를 위한 0.1초 팔 목표 응답 교정

평행에 가까운 방향은 부드러운 선호다. 손바닥의 실제 넥 지지와 기타 초기 p/q 유지를
우선하며, 지지를 돕는 기울기를 허용한다. 면각만으로 채택/탈락하지 않는다.
이전 스트랩 비교의 0.1초 개선은 0.5초까지 이어지지 않아 새 길이를 채택하지 않았다.
첫 step 응답으로 후기 움직임을 예측하지 않고 같은 시간 길이의 응답을 측정한다.

## 불변 조건과 가정

- 기존 초기 q·기타 p/q·LA 1.1018469719600776m·PD gain·root/하체 물리 고정·
  self collision ON·몸통9/오른팔/손가락 목표를 유지한다. 기타는 free/중력/수동 strap이다.
- Leftarm12 최종 목표는 initial±0.3rad∩native, 66축 합성 경로를 유지한다.
  초기각이 아닌 PD 목표만 바꾸며 기타/관절 state 덮어쓰기·손 부착·인위적 기타힘은 없다.
- 교정은 기존 startup bias 주변의 **constant bias** 조건이다. 기존 tracking PI와
  분리한다. task는 기존 위치3+법선 회전3-vector(.08m/rad)이며 평행 hard 제약은 없다.
  접촉을 우선하는 계층 제어가 구현된 것은 아니다.
- 0.1초 응답은 이 초기 상태·조건·시간에 국한한다. 정적 FK, 순간 Jacobian,
  장기 feedback Jacobian, 전 범위 응답으로 대체 해석하지 않는다.

## 작은 실행 단위

- [x] 1. 새 constant-bias runner의 목표만 쓰는 경로·입력 SHA·고정 하체·나머지 목표·
  native bounds·source palm-up proxy·PD/strap 불변을 검증한다. 시작/끝 입력 봉인을 남긴다.
- [x] 2. 기준 1개+왼팔12 단축 probe+독립 조합 heldout 1개를 각24steps(.1초) 실행한다.
  단축 probe는 가능한 방향으로 0.01rad, heldout은 축별 ±0.002rad다. 실제 float32
  목표 차이를 분모로 사용한다. 예상14init/336steps이며 실패/실제 집계를 보존한다.
- [x] 3. 종료 오차 차이로 6×12 유한시간 응답 B를 구하고 heldout 예측 차이를 읽는다.
  이 오차에 임의 성공 문턱을 정하지 않는다. regularized bounded LS로 추가 bias를
  축별 최대±0.05rad∩기존 box 안에서 구한다. 초기 q/기타/LA는 그대로다.
- [x] 4. 보정 후보 constant-bias를 실제24steps로 검증한다. 첫step과0.1초를 각각 보고,
  실제 접촉/raw lambda·기타p/q·몸통 drift를 먼저 읽는다. 개선이면 같은 기존 tracking
  PI에 bias만 바꾼24steps와 기준 tracking 재현을 별도로 비교한다. B를 feedback에
  바로 넣지 않는다. 후기 연장은 결과를 읽고 별도 단위로 정한다.
- [x] 5. 확정된 raw 해석으로 Luna 산출물·설명 그림을 만들고 Sol 확인·독립 검수를 한다.
  코드/계획/설정은 stability_adapter_2, raw/로그/그림/결과는
  docs/2026-10-12/stability_adapter_2/results/palm_finite_response_v1에 저장한다.

source 면 간격·정렬각은 보조 진단이며 PhysX cooked clearance/지지력 인증이 아니다.
raw lambda 단위를 임의 N로 변환하지 않는다. 접촉행 한 개를 지속 지지로 해석하지 않는다.
성공·연주 검증은 아직 완료되지 않았다. 중요한 결정은 사용자 자율 진행 지침에 따라
승인 대기로 멈추지 않고 근거와 검증 결과를 남긴다.

## 실제 첫 보정과 다음 분리 비교

14개 측정/heldout과 보정1개, 총15init/360steps를 실행했다. heldout의 point 예측차이는
0.000523mm이며 방향 rotation-vector 차이는0.0000179°다. 이것은 .002rad 조합 주변의
검증이며 .05rad 보정의 인증이 아니다. 보정후 실제 종료 point오차14.208→6.671mm,
기타 최대5.108mm/.969°→8.219mm/1.292°다. 손바닥 접촉은step1–8까지 있고
양의raw lambda는step1–4에 나타났으나 지속지지/기타 안정화는 아니다.

기타 오차가 커져 tracking 및 후기 연장 전에 bias delta의1/4·1/2 두 조건을 같은24step로
추가 비교한다(초기각·LA·PD·기존box 그대로, 추가2init/48steps). 접촉으로 응답이
비선형화되는 구간에서 원래 보정을 채택하지 않는다. 실제 기타 오차/접촉을 보고 다음 방향을
정하며 방향 정렬각만으로 결정하지 않는다. 기존 raw/producer는 변경하지 않는다.

## 단계 결과와 다음 판단

1/4 constant 보정은 point11.094mm/기타5.093mm/.969°,1/2은8.998mm/5.527mm/1.025°다.
1/4의 기존 tracking PI 분리 비교는 point12.187→9.712mm/source normal gap11.864→9.524mm,
기타5.107730→5.093149mm/.969008→.968555°다. 기타 차이는 매우 작고 손바닥rawlambda는
모두0,step4 뒤 접촉 소실이 남아 새bias를 안정화 후보로 최종채택하지 않는다.
전체보정의 작은point오차·방향각만으로 지지/기타 안정화라고 판정하지 않는다.

총19headless init/456steps 및 실제Gym카메라2init/48steps로21init/504steps다.
카메라는 저장PD명령으로 실제물리를 재실행했으며 pose재생이 아니다. 두조건5raw exact,
7시점×2view×2조건28PNG다. 원래tracking도 이전0.5초 current의첫24step5raw를exact재현했다.
독립 계산 검수에서 B차이0,LS차이≤5.64e−17rad,tracking float32target exact,
passive strap pre-step law차이0이었다. 입력 봉인과 이전7phase 보존을 확인했다.

12개.01rad 단축probe는 기타body state가 모두baseline과exact/양의palmλ없음이었다.
이번B는 그국소범위에서 기타제어응답을 측정하지못했다. 접촉이생긴전체/1/2보정에서는
기타가더움직이므로 이 B를기타 p/qfeedback으로 곧바로 사용하지않는다. 다음에는
접촉이생기는경계에서손과기타응답을함께측정하고, 기타오차악화를동반한접근을피한다.
PD gain·초기각·길이·손가락닫기·후기시간을동시에바꾸지않으며 지속지지와연주검증은미완료다.

최종PNG4개/문서/절대링크/producer60입력·4출력SHA 독립검수완료(Critical/Warning/
Suggestion 없음). phase review.md는 동결했고 이소단계 산출물과최종source snapshot을보존한다.

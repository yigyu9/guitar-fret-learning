"""Create six labeled contact sheets from the saved 13 native sway endpoints."""
import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
PHASE = ROOT / 'docs/2026-10-12/stability_adapter_2/results/guitar_playing_sway_envelope_v1'
COMPARISON = PHASE / 'native/comparison.json'
OUT = PHASE / 'artifacts_v2'
FONT = Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
CELL = (480, 270)
GUTTER, TITLE_H, HEADER_H = 380, 42, 44
VIEWS = {
    'front': lambda case: Path(case['path']) / 'front.png',
    'side': lambda case: Path(case['path']) / 'side.png',
    'hands': lambda case: Path(case['path']) / 'images/frames/hands/00000.png',
}
TRANSLATION_ROWS = [('World X', 'x_min', 'center', 'x_max', ['-50 mm', '0 mm', '+50 mm']),
                    ('World Y', 'y_min', 'center', 'y_max', ['-50 mm', '0 mm', '+50 mm']),
                    ('World Z', 'z_min', 'center', 'z_max', ['-50 mm', '0 mm', '+50 mm'])]
ROTATION_ROWS = [('Neck elevation (absolute)', 'elevation_min', 'center', 'elevation_max', ['10° absolute', '22° absolute', '40° absolute']),
                 ('Audience yaw (absolute)', 'audience_yaw_min', 'center', 'audience_yaw_max', ['-10° absolute', '5° absolute', '20° absolute']),
                 ('Board recline (baseline correction)', 'board_recline_min', 'center', 'board_recline_max', ['-5° Δ baseline', '+3° Δ baseline', '+15° Δ baseline'])]


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    with Path(path).open(encoding='utf-8') as stream:
        return json.load(stream)


def write(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, sort_keys=True)
        stream.write('\n')


def centered(draw, box, text, font, color):
    left, top, right, bottom = box
    bounds = draw.textbbox((0, 0), text, font=font)
    width, height = bounds[2] - bounds[0], bounds[3] - bounds[1]
    draw.text((left + (right-left-width)/2-bounds[0], top + (bottom-top-height)/2-bounds[1]),
              text, font=font, fill=color)


def main():
    if not COMPARISON.is_file():
        raise FileNotFoundError('native comparison is not ready: '+str(COMPARISON))
    if OUT.exists():
        raise FileExistsError('refusing to overwrite '+str(OUT))
    producer = Path(__file__).resolve()
    comparison_sha = sha(COMPARISON)
    data = read(COMPARISON)
    rows = data.get('rows')
    if not isinstance(rows, list) or len(rows) != 13 or data.get('physics_steps') != 0:
        raise ValueError('expected 13 completed native endpoints with physics_steps=0')
    if not data.get('checks') or not all(data['checks'].values()):
        raise ValueError('native comparison checks failed')
    by_id = {row['id']: row for row in rows}
    if len(by_id) != 13 or 'center' not in by_id:
        raise ValueError('native endpoint IDs are incomplete or duplicated')
    if not FONT.is_file():
        raise FileNotFoundError(FONT)
    inputs = {str(producer): sha(producer), str(COMPARISON.resolve()): comparison_sha,
              str(FONT): sha(FONT)}
    images, source_records = {}, {}
    native_root = (PHASE / 'native').resolve()
    for case in rows:
        case_dir = Path(case['path']).resolve()
        try:
            case_dir.relative_to(native_root)
        except ValueError:
            raise ValueError('native case path escapes phase root')
        local_path = case_dir / 'comparison.json'
        capture_path = case_dir / 'images/capture.json'
        local, capture = read(local_path), read(capture_path)
        if local.get('id') != case['id'] or not local.get('checks') or not all(local['checks'].values()):
            raise ValueError('native per-case checks failed: '+case['id'])
        if local.get('native_state', {}).get('physics_step') != 0:
            raise ValueError('native case is not at physics step zero: '+case['id'])
        inputs[str(local_path.resolve())] = sha(local_path)
        inputs[str(capture_path.resolve())] = sha(capture_path)
        images[case['id']] = {}
        source_records[case['id']] = {'case_path': str(case_dir), 'images': {}}
        for view, path_fn in VIEWS.items():
            path = path_fn(case).resolve()
            actual = sha(path)
            if view in ('front', 'side'):
                expected = local.get('extra_image_sha256', {}).get(str(path))
            else:
                frames = capture.get('frames', [])
                if len(frames) != 1 or frames[0].get('physics_step') != 0:
                    raise ValueError('hands capture is not a single t0 frame: '+case['id'])
                expected = next((value for recorded, value in frames[0].get('image_sha256', {}).items()
                                 if Path(recorded).resolve() == path), None)
            if expected != actual:
                raise ValueError('source image SHA mismatch: '+str(path))
            inputs[str(path)] = actual
            with Image.open(path) as source:
                if source.size[0] <= 0 or source.size[1] <= 0:
                    raise ValueError('invalid image dimensions: '+str(path))
                image = source.convert('RGB')
                image.thumbnail(CELL, Image.Resampling.LANCZOS)
                images[case['id']][view] = image.copy()
            source_records[case['id']]['images'][view] = {'path': str(path), 'sha256': actual}

    for path, digest in inputs.items():
        if sha(path) != digest:
            raise RuntimeError('bounded input changed during preparation: '+path)
    OUT.mkdir(parents=True, exist_ok=False)
    fonts = {'title': ImageFont.truetype(str(FONT), 25),
             'header': ImageFont.truetype(str(FONT), 24),
             'row': ImageFont.truetype(str(FONT), 20)}
    mapping = {'source_comparison': str(COMPARISON.resolve()),
               'source_comparison_sha256': comparison_sha,
               'layout': '3 rows by 3 columns; cells 480x270; separate labels; aspect-preserving fit; no crop or overlay',
               'translation_columns': ['-50 mm', '0 mm', '+50 mm'],
               'rotation_columns': {'neck_elevation': 'absolute semantic angles', 'audience_yaw': 'absolute semantic angles', 'board_recline': 'correction relative to original baseline'},
               'source_cases': source_records, 'sheets': {}}
    outputs = {}
    for kind, row_specs in [('translation', TRANSLATION_ROWS), ('rotation', ROTATION_ROWS)]:
        for view in VIEWS:
            width, height = GUTTER + 3*CELL[0], TITLE_H + 3*(HEADER_H + CELL[1])
            sheet = Image.new('RGB', (width, height), (242, 244, 247))
            draw = ImageDraw.Draw(sheet)
            centered(draw, (GUTTER, 0, width, TITLE_H), kind.title()+' — '+view.title()+' view',
                     fonts['title'], (20, 28, 38))
            cells = []
            for row_i, (axis, low, middle, high, labels) in enumerate(row_specs):
                row_y = TITLE_H + row_i*(HEADER_H + CELL[1])
                y = row_y + HEADER_H
                centered(draw, (0, y, GUTTER, y+CELL[1]), axis, fonts['row'], (25, 35, 45))
                for col_i, (case_id, label) in enumerate(zip((low, middle, high), labels)):
                    case = by_id[case_id]
                    x = GUTTER + col_i*CELL[0]
                    centered(draw, (x, row_y, x+CELL[0], row_y+HEADER_H), label, fonts['header'], (25, 35, 45))
                    sheet.paste(images[case_id][view], (x, y))
                    cells.append({'row': axis, 'column': label, 'case_id': case_id,
                                  'case_path': case['path'], 'source_image': source_records[case_id]['images'][view]['path'],
                                  'source_image_sha256': source_records[case_id]['images'][view]['sha256']})
            filename = 'contact_sheet_%s_%s.png' % (kind, view)
            path = OUT / filename
            sheet.save(path, format='PNG', optimize=False)
            digest = sha(path)
            outputs[str(path.resolve())] = digest
            mapping['sheets'][filename] = {'path': str(path.resolve()), 'sha256': digest, 'cells': cells}
    for path, digest in inputs.items():
        if sha(path) != digest:
            raise RuntimeError('bounded input changed during sheet generation: '+path)
    write(OUT/'case_mapping.json', mapping)
    outputs[str((OUT/'case_mapping.json').resolve())] = sha(OUT/'case_mapping.json')
    write(OUT/'artifact_manifest.json', {'producer': str(producer), 'producer_sha256': inputs[str(producer)],
          'source_comparison': str(COMPARISON.resolve()), 'source_comparison_sha256': comparison_sha,
          'bounded_input_sha256': inputs, 'outputs_sha256': outputs, 'native_case_count': len(rows),
          'sheet_count': len(outputs)-1, 'scope': 'packaging saved native PNGs only; no simulation or source-image edits'})
    print(json.dumps({'output': str(OUT), 'sheets': len(outputs)-1, 'bounded_inputs': len(inputs)}, indent=2))


if __name__ == '__main__':
    main()

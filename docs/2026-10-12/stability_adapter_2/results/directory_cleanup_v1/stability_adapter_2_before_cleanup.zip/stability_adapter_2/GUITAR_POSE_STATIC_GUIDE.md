# 자연스러운 기타 배치 고르기 — 물리 없는 정적 도구

이 도구는 Isaac Gym의 화면에서 기타 배치만 직접 고른다. **물리 시간은 항상0이고, 중력·접촉 반응·PD 움직임·스트랩 힘은 없다.** 사람이 기타에 밀리거나 기타가 떨어지지 않는다. 사용자가 입력한 기타 위치·회전만 바뀐다.

그래픽 화면이 연결된 VS Code 터미널에서 다음 새 launcher를 실행한다.

```bash
bash /home/ajou/yigyu/3/stability_adapter_2/open_guitar_pose_editor_static.sh
```

| 키 | 기능 |
|---|---|
| F1 / F2 / F3 | 이동 X / Y / Z 축 선택 |
| F4 / F5 / F6 | 회전 X / Y / Z 축 선택 |
| J / L | 선택 축의 음 / 양 방향 조절 |
| F | 기본2mm·1° ↔ 정밀0.5mm·0.25° |
| Tab | world / 기타 local 축 |
| Z / R | 실행취소 / 기준 기타 배치 복원 |
| T | 참고용 스트랩 경로 표시 ON/OFF. 힘은 항상 없음 |
| C / G | 전체·손 시점 / 시각·충돌 형상 보기 |
| S | 후보 JSON·전체/손 이미지 저장 |
| H / Esc | 도움말 / 종료 |

Space와 E는 물리를 시작하지 않는다. 마우스는 Gym 기본 시점 조작에 사용한다. 회전 중심은 기타 actor 원점이다. G의 충돌 형상 보기는 기하 배치를 눈으로 확인하는 용도이며 충돌 반응을 켜지 않는다. 겹친 배치도 직접 편집할 수 있다.

결과는 `/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/interactive_guitar_pose_static_sessions/<실행시각>/`에 저장된다. S를 누를 때마다 새 `candidate_000/pose.json` 및 `candidate_000/images/frames/{whole_body,hands}/00000.png`를 만든다. 기타 절대 위치(m)·xyzw quaternion·기준 대비 차이·humanoid 초기각과 기준 목표를 기록한다. `physics_enabled=false`, `simulation_steps=0`, `strap_enabled=false`, 별도의 `strap_visible`을 저장해 참고 표시와 힘을 구별한다. 동영상이나 물리 trial은 만들지 않는다.

저장 후보를 다시 열려면 `--candidate <pose.json 절대 경로>`를 추가한다. 예전 v1 후보도 읽을 수 있으며 저장됐던 스트랩 ON/OFF는 표시 조건으로만 해석한다. `--no-strap`은 처음부터 스트랩 참고선을 숨기는 옵션이다. 후보를 불러오면 후보에 저장된 표시 조건이 우선한다.

이전 `open_guitar_pose_editor.sh`와 v1 문서는 물리 preview가 포함된 과거 재현용으로 보존한다. **자연스러운 배치 선택에는 이 문서의 새 static launcher를 사용한다.** 마음에 드는 후보를 여러 개 저장해 기타 배치의 범위와 이후 손 자세를 함께 검토한다. 저장 후보가 실제로 지지 가능한지는 별도의 후속 실험에서 확인한다.

[이번 정적 검증·이미지 설명](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/interactive_guitar_pose_static_v2/README.md:1)에 결과를 정리한다.

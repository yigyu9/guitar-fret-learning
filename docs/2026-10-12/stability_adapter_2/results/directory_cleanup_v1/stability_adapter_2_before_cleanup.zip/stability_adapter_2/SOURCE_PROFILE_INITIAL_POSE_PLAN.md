# Fret source 범위와 호환되는 초기 손 자세의 실제 시험

## 변경 근거와 범위

현재−2mm 유지 기준은 왼손6관절의 초기 실제각/PD목표가 Fret source의 범위 밖이다.
초기각의 최대 최소 변경폭은 thumb1_y0.661268771rad, 유지 목표는0.617647946rad다.
이것은 이전 팔 ±0.3rad 검색과 별도의 **손6관절 초기 배치 변경**이다.
사용자의 필요한 결정 자율 진행 지침에 따라 근거를 기록하고 작은 단위로 검증한다.
기존 native 모델·checkpoint·이전 안정화 결과는 수정하지 않는다.

## 후보와 불변 조건

1. 현재 실제 초기81각과 유지81목표에서 source/native/normalized 표현 교집합을 구한다.
   위반 손6관절의 초기각과 유지 목표를 각각 가장 가까운 유효 범위 안에 둔다.
   float32 합성 후 범위를 다시 확인하고 필요한 경우 경계 안쪽1ULP를 사용한다.
   나머지75관절의 초기각/유지목표를 exact 보존한다. 기존 hand offset은 변경되는6개에
   대해서만 새 초기/유지 목표 차이를 기록한다. 모델 joint state는 초기화 때만 설정한다.
2. 기타 초기 world p/q·passive LA1.0998469719600776m·root/하체·body9 PD×2,
   나머지gain·물리/충돌조건·손목±0.005rad1Hz 파형은 유지한다.
   Source profile을 target/초기각 범위로 사용하며 현재 PhysX 실제 joint limit을
   이미 source profile로 교체했다고 설명하지 않는다. Actual 범위 이탈은 측정한다.
3. finger1의 여러 축 관절이 포함되어 기존 조건부18변수 FK 모델의 예측 인증을 사용할 수 없다.
   새 관절각의 **fresh native 실제 pose**에서 source human–G/cross-hands/
   native허용+same-left graph>2 전체 self 및 palm up을 검사한다.
   실제81각 readback·root/하체/G 초기값·filter/PD를 입력과 대조한다.
   불가능한 FK 예측을 통과로 꾸미지 않는다. FK prediction은 이번 후보에 적용하지 않음을
   별도 표시하고, fresh actual pose의 직접 형상 gate로 안전성을 판단한다.
   이 admission 구현·범위를 코드 검수한 뒤 실행한다.
4. 초기 gate 실패는0step/실제초기값·이미지·실패이유로 보존한다. 통과 후보는
   단 한 번 actual1200step/0~5초의 두151frame strap 영상을 남긴다.
   필요하면 별도fresh 초기probe와rollout을 각각 집계하며 중복 물리 실행을 숨기지 않는다.
   현재−2mm baseline과 초기G이탈/후기변화/손접촉/actual손범위를 비교한다.

첫 후보가 geometry gate에서 실패하면 실패 pair/각도 방향을 검토한 뒤 새 후보 계획을 기록한다.
같은 consumed 소스·입출력은 덮어쓰지 않는다. 이번 단계에서 policy/학습을 동시에 추가하지 않는다.
초기p/q 복원/유지와 최종66권한은 유지하며, 특정palm접촉·WAIT/REACH/GRIP 순서를
연주 시작의 필수 선행 단계로 추가하지 않는다.

- [ ] 새 입력/float32/source profile 범위 준비.
- [ ] Fresh native 직접 형상 admission 구현·코드 검수.
- [ ] 한 후보 actual5초/초기값/영상·baseline 비교·다음 결정.

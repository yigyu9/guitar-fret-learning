# 왼손 native Jacobian–fresh FK 대조

2026-10-07. PALM_POSITION_CURRENT_PROPOSAL.md의 A 계측 단계다.
기존 현재 초기각/LA/물리 조건을 사용하고 위치 controller는 추가하지 않는다.
현재 초기 Jacobian과 왼손 source 형상 중심 local offset은 palm_frame_audit_v1의
검수된 measurements_validated를 읽는다. p/q 유지 목표는 기타 초기 +5mm 상태다.

- [x] 1. baseline과 왼팔12의 fresh 초기 FK를 조회한다. 초기각 차이는 최대0.001rad,
  C02±0.3∩모델 한계 안의 central 차분 또는 경계의one-sided 차분이다.
  다른 관절 초기각·target/PD·root·기타·LA·solver는 그대로이며 rollout steps=0이다.
  각 scene의 설정·전체 native 상태·palm COM/local point·actual q를 저장한다.
  측정용 FK probe는 연주 시작 자세 후보로 채택하지 않는다.
- [x] 2. actual q 차이를 분모로 world body-origin/COM/source point 위치 미분과
  body world 회전의 angular 미분을 구한다. native row L17·동일 DOF 열과 비교한다.
  raw 선형 Jacobian이 body-origin과 COM 중 어느 점의 미분과 대응하는지 구분한다.
  각 가설에서 source point로 옮긴 Jacobian도 비교한다. API frame을 미리 가정하지 않는다.
  오차 수치와 방향·열 대응을 보고하고 맞지 않으면 위치 제어를 구현하지 않는다.
- [x] 3. Luna가 미분 오차 그림·설명을 저장하고 별도 검수를 받는다.
  원자료 SHA·실제 CLI·보존본·변경 절대경로/줄을 기록한다. 결과는 누적36절에 추가한다.

Angular 차분은 두 fresh body 회전의 world 상대회전 log를 actual q 차이로 나눈다.
형상 중심은 고정된 source convex-hull 체적 중심이며 접촉점/해부학적 중심/COM이 아니다.
이 계측으로 원본 기타 목표 유지·물리 지지·연주 안정성이나 runtime Jacobian 정확성을
인증하지 않는다. 실제 task/변화율 제한/gain/학습 변경은 확인 후 별도 비교한다.

새 코드/계획은 stability_adapter_2, 원자료/그림/보고서는
docs/2026-10-12/stability_adapter_2/results/palm_jacobian_fk_v1에 둔다.

## 측정 결과와 다음 단계

성공 실행은 baseline과22 probe의23 fresh 초기화, rollout0이다. Thorax_x는forward,
Thorax_z는backward, 나머지10열은central 차분이다. 초기화/보존 계약6개는 통과했지만
raw Jacobian의 COM 미분 오차는 최대0.215649m/rad, angular 오차는0.678073rad/rad였다.
따라서 raw 행렬을 관절 위치 좌표 변화에 직접 적용할 수 없다.

현재 초기각에서 각3좌표 블록에 SO(3) left tangent를 적용하고 선형 기준점을 native COM으로
해석하면 COM 오차0.000275001m/rad, source 중심 오차0.000274299m/rad,
angular 오차0.000194957rad/rad로 줄었다. 원점 기준 source shift는0.042214636m/rad다.
이는 현재 초기 자세의 수치 미분이 지지하는 해석이며 MJCF importer·native DOF velocity의
전체 계약이나 실행 중 정확성을 증명하지 않는다. 순수 SO(3) 독립 미분6case도 통과했다.

다음 소단계는 동일 초기각/LA/승인 PI로 짧게 실행하면서 native Jacobian 조회 시점과
native 관절·body 속도의 대응을 계측하는 것이다. 새 위치 task·gain·변화율 제한은
이 진단 뒤 구체적 비교안을 확인받아 적용한다. 기타 초기 p/q 유지 성공은 아직 아니다.

# 현재 관절 보정 범위의 손 위치 선형 가능 범위

2026-10-07. 새 위치 제어 확인을 기다리는 동안 저장된0.1초 계측만 분석한다.
Native 실행/새 controller 구현·적용은 없다. 기존 승인±0.15rad 보정과
C02±0.3rad∩모델 한계를 사용한다. 미승인0.02rad/update 제한은 적용하지 않는다.

- [x] 현재 native q에서 왼팔12의 SO(3) tangent/COM→source Jacobian을 구성한다.
- [x] 세 singular values와 기존 보정 box의 각 world 축 선형 변위 최솟값/최댓값을 계산한다.
  q_play−q_actual의 변위도 포함하고 초기 source 중심까지의 필요 변위와 대조한다.
- [x] 결과 표/그림·설명·입력 SHA·독립 검수를 저장한다.

각 축의 interval은 서로 다른 box 모서리에서 구한 독립 범위다. 세 축을 동시에
달성할 수 있다는 증명이나 큰 관절 변화의 정확한 FK/접촉/기타 유지 인증은 아니다.
계획/분석은 stability_adapter_2, 결과는
docs/2026-10-12/stability_adapter_2/results/palm_task_authority_v1에 둔다.

0.1초 초기점 복귀에 필요한 x/y/z 변위는−9.389475/+23.138609/+41.648954mm다.
이들은 각 축의 독립 선형 범위 안에 있다. Singular values는0.653878/0.619258/0.203809m/rad다.
따라서 각 축 범위만으로 위치 task를 배제할 근거는 없지만, 동시달성/비선형/물리 안정성은
별도 검증이 필요하다. 기존 제어 보정 범위를 분석했으며 새 controller 확인 상태는 그대로다.

"""Read source palm/neck geometry at saved early native poses; no native run."""
import argparse
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

from .environment import np
from .replay_contact_geometry import recorded_probe
from .search_hand_support import palm_neck_gap
from .pose_strap_inputs import pose_metrics
from .plot_neck_palm import geometry
from .plot_joint_hold import geometry_asset_paths


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists() and any(args.out.iterdir()):
        raise FileExistsError('preserve previous source diagnostic')
    args.out.mkdir(parents=True, exist_ok=True)
    paths = [args.run / (n + '.json') for n in ('report', 'states', 'trace', 'contacts')]
    report, states, trace, contacts = [read(p) for p in paths]
    if not all(report['checks'].values()) or not all(sha(p) == h for p, h in report['source_sha256'].items()):
        raise ValueError('saved PI contracts or sources differ')
    rows, surfaces = [], []
    for step in (0, 1, 2, 4, 8, 12, 24):
        state = states[step]
        if state['physics_step'] != step or trace[step]['time_s'] != step / report['physics_hz']:
            raise ValueError('saved frame alignment differs')
        probe = recorded_probe(args.run, step)
        model, data, shapes = probe
        scene = SimpleNamespace(human=0, guitar=1, human_bodies=report['human_body_names'],
            guitar_bodies=report['guitar_body_names'], bodies=lambda actor: state['human_body_states'] if actor == 0 else state['guitar_body_states'])
        hand = pose_metrics(scene, probe)
        gap = palm_neck_gap(probe)
        if step:
            sample = contacts[step - 1]
            if sample['physics_step'] != step:
                raise ValueError('saved contact alignment differs')
            left = [c for c in sample['contacts'] if any(n.startswith('human/LH:') for n in (c['body0_name'], c['body1_name'])) and any(n.startswith('guitar/') for n in (c['body0_name'], c['body1_name']))]
        else:
            left = None
        rows.append({'physics_step': step, 'time_s': step / report['physics_hz'], 'palm_neck': gap,
            'hand': hand, 'native_LH_contact_rows': left,
            'guitar_position_error_m': trace[step]['position_error_m'],
            'guitar_rotation_error_deg': trace[step]['rotation_error_deg']})
        if step in (0, 24):
            visible = [s for s in shapes if s['actor'] == 'guitar' or s['body'].startswith('LH:') or s['body'] in ('L_Wrist', 'L_Elbow')]
            surfaces.append({'physics_step': step, 'time_s': step / report['physics_hz'],
                'shapes': [dict(actor=s['actor'], body=s['body'], geom_id=s['geom_id'],
                    triangles_world_m=geometry(model, data, s).triangles.tolist()) for s in visible]})
    helper_names = ['analyze_left_early_source.py', 'replay_contact_geometry.py', 'search_hand_support.py',
        'pose_strap_inputs.py', 'plot_neck_palm.py', 'initial_overlap.py', 'plot_joint_hold.py', 'environment.py', 'config.json']
    paths += [Path(__file__).with_name(n) for n in helper_names] + geometry_asset_paths()
    inputs = dict(report['source_sha256'])
    inputs.update({str(p.resolve()): sha(p) for p in paths})
    result = {'scope': 'saved native poses reconstructed with source collision shapes; no native/controller run',
        'checks': {'seven_saved_frames': [r['physics_step'] for r in rows] == [0, 1, 2, 4, 8, 12, 24],
            'source_hull_solves_feasible': all(r['palm_neck']['solver_feasibility_error_m'] <= 1e-7 for r in rows),
            'palm_normal_proxies_valid': all(r['hand']['palm_normal_valid'] for r in rows),
            'consumed_sources_unchanged': all(sha(p) == h for p, h in inputs.items())},
        'semantics': 'unsigned source convex-hull distance; backend signed query cutoff20mm is separate, negative magnitude not depth. Landmark normal anatomical sign unverified. Native contacts are completed-step records, not simultaneous source query/contact-force evidence.',
        'rows': rows, 'input_sha256': inputs}
    (args.out / 'geometry.json').write_text(json.dumps({'scope': 'source triangles at saved native poses, not native renderer', 'snapshots': surfaces}, indent=2, allow_nan=False) + '\n')
    (args.out / 'analysis.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'checks': result['checks'], 'input_hashes': len(inputs),
        'samples': [{'step': r['physics_step'], 'unsigned_gap_mm': r['palm_neck']['source_hull_distance_m'] * 1000,
            'up_proxy': r['hand']['palm_up_dot'], 'height_vs_local_lower_mm': None if r['hand']['palm_height_vs_local_lower_m'] is None else r['hand']['palm_height_vs_local_lower_m'] * 1000,
            'LH_contacts': None if r['native_LH_contact_rows'] is None else len(r['native_LH_contact_rows'])} for r in rows]}, indent=2))
    if not all(result['checks'].values()):
        raise SystemExit(1)


if __name__ == '__main__':
    main()

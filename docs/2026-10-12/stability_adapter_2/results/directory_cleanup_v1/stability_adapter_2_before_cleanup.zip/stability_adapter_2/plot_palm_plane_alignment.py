#!/usr/bin/env python3
"""Plot saved source-plane alignment measurements; performs no simulation."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np


DEFAULT_MEASUREMENTS = Path(
    '/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/'
    'results/palm_plane_alignment_v1/validated/measurements.json')
COLORS = {'off': '#666666', 'bias': '#e07a24', 'tracking': '#1878b8'}
LABELS = {'off': 'OFF', 'bias': 'Bias', 'tracking': 'Tracking'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--measurements', type=Path, default=DEFAULT_MEASUREMENTS)
    parser.add_argument('--out-dir', type=Path, required=True)
    args = parser.parse_args()
    data_path = args.measurements.resolve()
    out = args.out_dir.resolve()
    if out.exists():
        raise FileExistsError(f'output directory already exists: {out}')
    data = json.loads(data_path.read_text())
    if len(data.get('checks', {})) != 3 or not all(data['checks'].values()):
        raise ValueError('expected three passing structural checks')
    if data.get('native_initializations') != 0 or data.get('physics_steps') != 0:
        raise ValueError('measurements must remain saved-data-only')
    rows = data['rows']
    modes = ('off', 'bias', 'tracking')
    if set(rows) != set(modes) or any(len(rows[m]) != 25 for m in modes):
        raise ValueError('expected 25 saved samples for OFF, bias, and tracking')
    times = np.asarray([r['time_s'] for r in rows['off']], dtype=float)
    if not np.isfinite(times).all() or times[0] != 0.0 or abs(times[-1] - 0.1) > 1e-12:
        raise ValueError('saved sample times must span 0 to 0.1 seconds')
    fields = ('facing_normal_angle_deg', 'signed_source_normal_gap_mm',
              'source_tangent_distance_to_patch_center_mm')
    for mode in modes:
        t = np.asarray([r['time_s'] for r in rows[mode]], dtype=float)
        if not np.array_equal(t, times):
            raise ValueError('mode sample times differ')
        values = np.asarray([[r[f] for f in fields] for r in rows[mode]], dtype=float)
        if values.shape != (25, 3) or not np.isfinite(values).all():
            raise ValueError(f'{mode}: malformed or nonfinite measurements')

    out.mkdir(parents=True)
    font_path = '/usr/share/fonts/truetype/nanum/NanumGothic.ttf'
    if Path(font_path).exists():
        plt.rcParams['font.family'] = font_manager.FontProperties(fname=font_path).get_name()
    plt.rcParams['axes.unicode_minus'] = False
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.8))
    titles = ('source facet 법선 대향 각도', '부호 있는 source 법선 간격',
              'patch 중심까지 source 접선 거리')
    ylabels = ('각도 (°)', '부호 있는 간격 (mm)', '접선 거리 (mm)')
    for index, ax in enumerate(axes):
        for mode in modes:
            y = np.asarray([r[fields[index]] for r in rows[mode]], dtype=float)
            ax.plot(times, y, color=COLORS[mode], marker='o', markersize=2.5,
                    linewidth=1.7, label=LABELS[mode])
        ax.set_title(titles[index])
        ax.set_xlabel('저장 시각 (s)')
        ax.set_ylabel(ylabels[index])
        ax.set_xlim(0.0, 0.1)
        ax.grid(True, alpha=0.25)
        ax.legend()
    fig.suptitle('저장 native pose의 source 평면 정렬 측정', y=1.02)
    fig.tight_layout()
    image = out / 'palm_plane_alignment.png'
    fig.savefig(image, dpi=160, bbox_inches='tight')
    plt.close(fig)
    manifest = {
        'producer': str(Path(__file__).resolve()),
        'producer_sha256': sha(__file__),
        'measurement_input': str(data_path),
        'measurement_sha256': sha(data_path),
        'output_sha256': {image.name: sha(image)},
        'scope': 'Three saved source-plane metrics only; no native initialization or physics step.'
    }
    (out / 'plot_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'image': str(image), 'manifest': str(out / 'plot_manifest.json')}))


if __name__ == '__main__':
    main()

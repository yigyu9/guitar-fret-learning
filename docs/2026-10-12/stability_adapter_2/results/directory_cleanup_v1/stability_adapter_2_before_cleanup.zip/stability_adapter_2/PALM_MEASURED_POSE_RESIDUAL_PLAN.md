# 다음 단위: 실제손 pose의 source 형상으로palm residual 안전성 확인

두축FK의네수학가설은저장4+20시점전체손gate를모두통과하지못했다. 원인을확정하지않고기존fingerFK로손가락21각을바꾼미래형상을인증하지않는다. 이문제를그대로보존한다.

동일24시점의왼팔12/palm subchain은최대palm origin0.000312034mm·회전6.383681e-7rad로잘맞았다. Palm anchor4시점최대오차0.000157460mm다. 이는팔12의작은현재FK미분을계산할근거이며PD/접촉응답은아니다. 전체손gate실패를통과로바꾸거나최종제어범위를12로줄이지않는다.

1. Native저장actual hand bodypose와기타pose로현재 source mesh를만든다. 네시점의source실제겹침과palmar world+Z/현재normal·targetpatch영역을조회한다. Source hull진단은cooked contact/관통인증이아니다. Actualfinger relativepose를실제값으로읽으며finger q예측모델을가정하지않는다.
2. Palm runtime FK의현재3좌표팔chain에대해위치미분으로계산된12각기하제안의1/0.5/0.25배를offline비교한다. Palm예측변화의rigid transform을현재measured fingerbody source mesh에적용해finger pose를순간일정하게둔가정에서겹침/위치변화를본다. 팔body는검증된12축FK로만움직인다. 매시점새로실제fingerpose를읽는것과trajectory예측을refit하는것은구분한다. 실제시뮬레이션관절/body/guitarstate에는쓰지않는다. 실제finger PD응답에의한미래변화는아직모른다.
3. 안전한방향이있으면같은initial81/G/LA·body9PD×2·기존절대81목표를base로한bounded/rate-limitedpalm feedback ON 한actual5초를별도실행계약에서만든다. Finger21/몸통9/R팔손 목표는이소단계에서유지한다. 최종66연주권한·손가락제어권은유지한다. Residual의최대0.05rad와q0±0.3∩native한계교집합을검토하고속도/적분gain은geometry/실제PD응답을보고정한다. Actual q를base목표로바꾸지않는다.
4. 라이브actualpalm점과actualG patch의오차를사용하며기타에별도force/고정/부착을쓰지않는다. 접촉이생기면initial worldG p/q복원항을추가하는물리반응을다음소단계에서확인한다. 연주66목표+stabilization residual의최종target·clipping/antiwindup·우선순위와제어권을설계한뒤학습구조를정한다. WAIT→REACH→GRIP→TRANSPORT는연주필수선행상태기로쓰지않는다.

- [ ] 저장actual source형상과12축기하제안의전체손/기타/양손 진단
- [ ] 안전성·PD목표경계/변화율에근거한새feedback 실행계약
- [ ] ON 한5초·스트랩전신/손영상·초기값/제어·실제G오차와접촉검증

계획은미실행이다. 기존FK/이전source검색·source거절결과와같이보존한다. 초기에실제로움직인R_Thorax_x는3step에서native정적한계를최대0.000099935rad(0.005726°)넘었다. 이를숨기지않고최종PD목표의한계통과와실제물리한계준수범위를별도측정한다. 기타초기복원·유지·thumb후면/손가락전면/palm옆면지지·연주안정화의전체목표는미완료다.

"""Plot frozen native joint series and window maxima; never invokes simulation."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import shutil

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / 'docs/2026-10-12/stability_adapter_2/results/fixed_strap_middle_relax_v1'
A = ROOT / 'stability_adapter_2'
NATIVE = P / 'native'
RUN_SERIES = ['baseline', 'middle3_minus005']
DECISION = A / 'FIXED_STRAP_MIDDLE_RELAX_DECISION.md'
PLAN = A / 'FIXED_STRAP_MIDDLE_RELAX_PLAN.md'
ANALYZER = A / 'analyze_fixed_strap_middle_relax.py'
MEDIA = [
    NATIVE / 'frames/hands/00000.png', NATIVE / 'frames/hands/00150.png',
    NATIVE / 'hands.mp4', NATIVE / 'whole_body.mp4',
]
EXTRA_FILES = [
    P / 'analysis.json', P / 'joint_series.jsonl', P / 'windows.jsonl',
    P / 'analysis_execution.json', P / 'native_execution.json', P / 'native.log',
    P / 'native/videos.json', DECISION, PLAN, ANALYZER,
    Path('/tmp/run_fixed_strap_middle_analysis.py'), A / 'run_fixed_strap_middle_relax_phase.py',
] + MEDIA
COLORS = {'baseline': '#4C78A8', 'middle3_minus005': '#F58518'}
DISPLAY = {'baseline': 'Baseline', 'middle3_minus005': 'Middle3 −0.05 rad'}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read_rows(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()]


def archive_path(path, destination):
    path = Path(path).resolve()
    try:
        rel = path.relative_to(ROOT)
        return destination / 'repo' / rel
    except ValueError:
        return destination / 'external' / Path(*path.parts[1:])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out-dir', required=True)
    args = parser.parse_args()
    out = Path(args.out_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    figure = out / 'middle_relax_native_summary.png'
    manifest_path = out / 'artifact_manifest.json'
    snapshot_path = out / 'source_snapshot.json'
    wrapper = out / 'run_producer.sh'
    if any(p.exists() for p in (figure, manifest_path, snapshot_path, out / 'source_snapshot', out / 'producer_execution.json')):
        raise SystemExit('refusing to overwrite prior artifact evidence')

    analysis = json.loads((P / 'analysis.json').read_text())
    if len(analysis.get('checks', {})) != 19 or not all(analysis['checks'].values()):
        raise RuntimeError('analysis checks are missing or failed')
    if analysis['input_sha256_before'] != analysis['input_sha256_after'] or len(analysis['input_sha256_before']) != 29:
        raise RuntimeError('analysis input SHA closure is incomplete or changed')
    expected_sources = analysis['input_sha256_before']
    summary = {row['label']: row for row in analysis['summary']}
    if set(summary) != set(RUN_SERIES):
        raise RuntimeError('unexpected summary labels')

    paths = {Path(p) for p in expected_sources}
    paths.update(EXTRA_FILES)
    paths.update([Path(__file__).resolve(), wrapper])
    paths = sorted((p.resolve() for p in paths), key=str)
    before = {str(path): sha(path) for path in paths}
    for path, expected_sha in expected_sources.items():
        if before.get(path) != expected_sha:
            raise RuntimeError('current input SHA differs from analysis closure: ' + path)

    snapshot_root = out / 'source_snapshot'
    records = []
    for path in paths:
        copied = archive_path(path, snapshot_root)
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, copied)
        digest = sha(path)
        if sha(copied) != digest:
            raise RuntimeError('source archive SHA mismatch: ' + str(path))
        records.append({'original_path': str(path), 'copy_path': str(copied), 'sha256': digest})
    snapshot_path.write_text(json.dumps({'files': records}, indent=2) + '\n')

    series_rows = read_rows(P / 'joint_series.jsonl')
    window_rows = read_rows(P / 'windows.jsonl')
    series = {}
    for label in RUN_SERIES:
        rows = [r for r in series_rows if r['label'] == label]
        if len(rows) != 1201 or [r['physics_step'] for r in rows] != list(range(1201)):
            raise RuntimeError('joint series incomplete or unordered: ' + label)
        if any(not math.isclose(r['time_s'], r['physics_step'] / 240.0, abs_tol=1e-12, rel_tol=0.0) for r in rows):
            raise RuntimeError('joint-series clock mismatch: ' + label)
        series[label] = rows
        target = summary[label]['middle3_goal_deg']
        if any(not math.isclose(r['middle3_held_goal_deg'], target, abs_tol=1e-9) for r in rows):
            raise RuntimeError('held middle3 target mismatch: ' + label)
        at_five = rows[-1]['middle3_actual_deg']
        if not math.isclose(at_five, summary[label]['middle3_actual_samples_deg']['5.0'], abs_tol=1e-9):
            raise RuntimeError('5-second sample differs from summary: ' + label)

    if len(series_rows) != 2402 or len(window_rows) != 242:
        raise RuntimeError('unexpected series/window row counts')
    windows_by_label = {label: [r for r in window_rows if r['label'] == label] for label in RUN_SERIES}
    for label, rows in windows_by_label.items():
        if len(rows) != 121:
            raise RuntimeError('unexpected window count: ' + label)
        pass_count = sum(bool(r['within_provisional_limits']) for r in rows)
        if pass_count != summary[label]['windows_within_provisional_limits']:
            raise RuntimeError('window pass count differs from analysis summary: ' + label)
        max_position = max(r['max_position_change_mm'] for r in rows)
        max_rotation = max(r['max_rotation_change_deg'] for r in rows)
        if not math.isclose(max_position, summary[label]['max_1s_position_change_mm'], abs_tol=1e-12):
            raise RuntimeError('window position max differs from analysis summary: ' + label)
        if not math.isclose(max_rotation, summary[label]['max_1s_rotation_change_deg'], abs_tol=1e-12):
            raise RuntimeError('window rotation max differs from analysis summary: ' + label)

    fig, (ax_series, ax_bars) = plt.subplots(1, 2, figsize=(14.2, 6.6), gridspec_kw={'width_ratios': [1.25, 1.0]})
    for label in RUN_SERIES:
        rows = series[label]
        times = np.asarray([r['time_s'] for r in rows])
        actual = np.asarray([r['middle3_actual_deg'] for r in rows])
        goal = float(summary[label]['middle3_goal_deg'])
        color = COLORS[label]
        ax_series.plot(times, actual, color=color, linewidth=1.7, label=DISPLAY[label] + ' actual')
        ax_series.axhline(goal, color=color, linestyle='--', linewidth=1.25, alpha=0.82,
                          label=DISPLAY[label] + ' held goal')
    ax_series.set_xlim(0.0, 5.0)
    ax_series.set_xticks(np.arange(0, 5.01, 1.0))
    ax_series.set_xlabel('simulation time (s)')
    ax_series.set_ylabel('middle3 scalar joint angle (deg)')
    ax_series.set_title('Actual angle and constant held goal', loc='left', fontweight='bold')
    ax_series.grid(alpha=0.22)
    ax_series.legend(loc='center right', fontsize=8, frameon=True)

    metric_specs = [
        ('position', 'max_1s_position_change_mm', 5.0, 'mm', '#4C78A8'),
        ('rotation', 'max_1s_rotation_change_deg', 1.0, '°', '#F58518'),
    ]
    entries = [
        ('position', 'baseline'), ('position', 'middle3_minus005'),
        ('rotation', 'baseline'), ('rotation', 'middle3_minus005'),
    ]
    y_values = [3.0, 2.2, 0.8, 0.0]
    for (metric, label), y in zip(entries, y_values):
        spec = next(s for s in metric_specs if s[0] == metric)
        _, key, limit, unit, metric_color = spec
        actual_value = float(summary[label][key])
        fraction = actual_value / limit
        bar_color = COLORS[label]
        ax_bars.barh(y, fraction, height=0.55, color=bar_color, edgecolor=metric_color, linewidth=1.6)
        ax_bars.text(fraction + 0.02, y, '{:.3f} {}'.format(actual_value, unit), va='center', fontsize=8)
    ax_bars.axvline(1.0, color='#333333', linestyle='--', linewidth=1.2)
    ax_bars.axhline(1.5, color='#999999', linewidth=0.8)
    ax_bars.set_yticks(y_values, [DISPLAY[label] for _, label in entries])
    ax_bars.set_xlim(0.0, 1.1)
    ax_bars.set_ylim(-0.5, 4.0)
    ax_bars.set_xticks(np.arange(0.0, 1.11, 0.2))
    ax_bars.set_xlabel('fraction of provisional limit')
    ax_bars.set_title('Rolling 1 s maximum change', loc='left', fontweight='bold')
    ax_bars.grid(axis='x', alpha=0.22)
    ax_bars.set_axisbelow(True)
    ax_bars.text(0.02, 3.58, 'Position · limit 5 mm', fontsize=8, color='#333333')
    ax_bars.text(0.02, 1.37, 'Rotation · limit 1°', fontsize=8, color='#333333')

    fig.suptitle('Fixed-strap middle3 target relaxation · saved native trial', fontsize=14, y=0.98)
    fig.text(0.5, 0.055, 'Left dashed lines = held targets; solid curves = actual middle3 angle. Right dashed line = provisional limit.', ha='center', fontsize=9)
    fig.text(0.5, 0.032, 'Window maxima use complete 1 s / 241-sample windows starting at 2.000–4.000 s (121 starts at 60 Hz).', ha='center', fontsize=9)
    fig.text(0.5, 0.009, 'Provisional limits only; saved actual trial does not certify naturalness or playing success.', ha='center', fontsize=9)
    fig.tight_layout(rect=(0.02, 0.105, 0.98, 0.93), w_pad=2.0)
    fig.savefig(figure, dpi=220, bbox_inches='tight')
    plt.close(fig)

    after = {str(path): sha(path) for path in paths}
    if before != after:
        raise RuntimeError('input SHA changed during artifact generation')
    outputs = {figure.name: sha(figure)}
    manifest = {
        'producer_sha256_before': before[str(Path(__file__).resolve())],
        'producer_sha256_after': after[str(Path(__file__).resolve())],
        'inputs_sha256_before': before,
        'inputs_sha256_after': after,
        'outputs_sha256': outputs,
        'native_initializations_during_artifact': 0,
        'physics_steps_during_artifact': 0,
        'actor_inference_calls_during_artifact': 0,
        'training_updates_during_artifact': 0,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'figure': str(figure), 'sha256': outputs[figure.name], 'input_count': len(before)}))


if __name__ == '__main__':
    main()

# Isaac Gym 실제 카메라 초기 장면

사용자 요청: MuJoCo 재생 대신 Isaac Gym 환경의 이미지를 제공한다.
이전 이미지는 native 실행의 저장 자세를 MuJoCo에서 재구성한 것으로 구분한다.

1. 현재 self-collision ON·하체 고정·자유 기타의 near2µm 입력으로 native 장면을 생성한다.
   기존 자산/환경/결과를 수정하지 않고 graphics_device_id만 별도 wrapper에서 활성화한다.
2. 초기 상태만 native camera sensor로 촬영한다. 물리 step은 추가하지 않는다.
   초기 body/DOF 상태를 이전 ON 결과와 대조하고 native 충돌 행렬을 검사한다.
   native 목표각 getter를 통한 별도 대조는 수행하지 않는다.
3. 전신·손 확대 PNG와 실제 실행 로그/설정/입력 SHA를 새 결과 폴더에 저장한다.
   렌더 불가 시 native 실패 기록을 보존하고 원인을 설명하며 다른 renderer 이미지를
   Isaac Gym 이미지로 대신 표기하지 않는다. 장치 설치나 시스템 설정 변경은 하지 않는다.
4. 문서·누적 보고서·변경 파일 실제 줄 번호를 정리하고 독립 검수한다.

현재 시스템 nvidia-smi는 드라이버 연결 실패를 보고했다. 기본 Vulkan 장치와
설치된 Lavapipe 소프트웨어 Vulkan을 작은 별도 실행으로 확인한다.

- [x] native graphics 초기화와 카메라 촬영
- [x] 이미지 또는 실패 원자료 검증
- [x] 결과 문서·독립 검토

기본 graphics device0로 native 카메라 초기화2회/physics0 완료. 기존 ON의 초기
full state와 exact이며 전신·손 확대 visual PNG가 정상이다. 색상·카메라만 조정했다.
front/hands_collision.png는 hands.png와 byte-identical이므로 별도 충돌 형상
확인용으로 사용하지 않고 진단 원자료로 보존한다. 초기 검정 화면 설명은 저장
파일 SHA·pixel 검증으로 정정했다. 실제 Vulkan 장치명은 조회하지 않아 단정하지 않는다.

촬영 producer가 읽은 이전 report.json 자체는 input SHA map에서 빠져 있었다.
최종 audit에서 해당 report의 SHA를 보존된 self_collision_v1 artifact inventory와
대조해 연결했다. 실행 당시 producer 사본은 수정하지 않는다.

기본 graphics device0에서 촬영돼 ICD 강제 추가 시험 없이 마쳤다. [독립 검수](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/isaac_gym_camera_v1/review.md:9)는 완료됐고 남은 지적사항은 없다.

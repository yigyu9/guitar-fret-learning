# 가장 유망한 기존 실행의 전체 영상

2026-10-07. 사용자 요청으로 기존 자유 기타 실행을 비교하고 시작부터 종료까지 영상화한다.
필요한 결정은 별도 승인 없이 진행한다는 새 운영 지침을 workflow에 반영했다.

- [x] 1초 이상 저장된 자유 기타 54실행의 전체 구간 최대 위치/회전 오차를 비교한다.
- [x] 선택한 원자료 전체를 source geometry 영상으로 재생하고 첫/중간/마지막 프레임을 확인한다.
- [x] 원자료 SHA·frame/time mapping·codec·결과 설명·실제 변경 줄을 기록하고 독립 검수한다.

선택: left_palm_boundary_v1/hold_1s/l_wrist_x_minus0125. 1초 전체 최대73.268255mm/
13.439339°로 1초 비교군의 두 오차가 모두 최소다. left_wrist_strap_v1의0N 반복과
동일 수치이며 먼저 측정한 원본을 사용한다. 3초 실행은251.150465mm/81.526863°였다.
0.1/0.5초의 작은 오차를 더 긴 유지 성능과 같은 순위로 취급하지 않는다.
성공·연주 가능·후기 안정성을 선언하지 않으며 목표+5mm와 절대LA1.1010801317960974m를 따른다.

원본 native states/trace241개(0–240step,0–1초)를 모두 포함한다. 보기 편하게 0.25배속으로
60fps241프레임 영상(약4.017초)을 만들고 실시간도 같은 frame mapping으로 제공한다.
새 native 물리 실행은 없다. 저장된 body pose를 source collision 형상에 적용한 replay이며
PhysX renderer/cooked contact/피부 mesh 인증이 아니다. 전신과 기타·양손 확대, 저장 strap
route 및 실제 오류/시각을 표시한다. camera/범위는전체구간에서 고정한다.

EGL offscreen을 먼저 확인하고 불가하면 CPU source geometry 그리기로 전환한다.
영상 생성 코드와 메인계획은 stability_adapter_2에, MP4/preview/설명/로그는
docs/2026-10-12/stability_adapter_2/results/best_run_video_v1에 저장한다.

# 5초근접진단 저장원자료 분석 재시도

첫analyzer는PHASE 전체파일을입력으로수집해 자신의실행중stdout log까지봉인했다. Gymimport가로그를기록하면서 입력SHA가달라져 마지막inputs_unchanged 검사에서 exit1로멈췄다. 분석JSON은없고 native두조건/영상은완료상태다. 실패source/wrapper/metadata/log를 analysis_failure_v1에exact 보존했다.

새analyze_near_contact_diagnostic_v2는 완료된native폴더와명시한proposal/native실행기록·source snapshot·자신의소스/계획을입력으로한다. 기존물리/목표/camera/raw재계산은같고 stdout파일은입력에포함하지않는다. 출력은analysis_v2.json으로새경로다. native재실행0이다. 아직실행되지않은artifact/feature후처리는해당v2분석을읽는다. 오류를자료/성공게이트완화로우회하지않는다.

- [ ] 두raw/영상/source불변성·목표차이·법칙 검증
- [ ] 실제feature 위치·그림·문서·원본보존

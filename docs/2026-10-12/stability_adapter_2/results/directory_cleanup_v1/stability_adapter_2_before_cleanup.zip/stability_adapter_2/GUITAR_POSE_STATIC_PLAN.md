# 기타 자연스러움 판단용 정적 편집 도구

사용자 정정: 이 도구는 시각적으로 자연스러운 기타 위치·회전 후보를 고르는 용도다. 물리적 상호작용은 없어야 한다. 이전 v1의 물리 preview는 새 도구에서 제거하고 기존 v1 소스·로그·영상은 보존한다. 기존 자동 실험은 중단 상태를 유지한다.

1. native Isaac Gym graphics만 사용한다. 처음부터 중력을0으로 구성하고 simulate/fetch_results/외력 제출과 환경 step_physics를 차단한다. 렌더·수동 배치·저장·불러오기 동안 물리 시간은0이다. 접촉 반응·PD에 의한 자세 변화·스트랩 힘은 없다. 형상 겹침은 시각적으로 살필 수 있으나 물리 반응이나 접촉 인증으로 해석하지 않는다.
2. 6축 이동/회전·world/local·정밀 조절·실행취소·기준 복원·카메라·스크린샷·후보 JSON을 유지한다. T는 스트랩의 참고 경로 표시만 바꾼다. Space/E로 물리가 시작되지 않는다. 기존 후보 JSON도 불러오며 새 후보에는 physics_enabled=false, simulation_steps=0, strap_visible 및 비활성 strap_enabled=false를 명시한다.
3. 실행 전 독립 검수 → 새 정적 native 창에서 실제 키 입력·6축 변경·human 불변·이미지 저장/load·Space/E 무효·물리 API 차단·시간0 검증 → 결과 문서에 실제 이미지와 설명을 남긴다. 물리 trial이나 영상 재생성은 하지 않는다.

새 진입점: `bash /home/ajou/yigyu/3/stability_adapter_2/open_guitar_pose_editor_static.sh`.
구현은 stability_adapter_2, 결과는 docs/2026-10-12/stability_adapter_2/results/interactive_guitar_pose_static_v2에 저장한다. 이전 launcher는 과거 재현용이며 새 정적 launcher가 자연스러움 판단용 기본이다.

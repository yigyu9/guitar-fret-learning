# 고정 스트랩의 두 초기 자세와 연주 source 범위 재조사

직전 초기 middle3 정렬 비교는 실제5초·원자료23검사·최종141검사와 그림/영상 문서까지 완료했다. 초기 목표 오차는0이 됐지만 기타 움직임은 늘어 두 자세를 함께 보존했다. 이번에는 현재 자세를 기존 fret·strike 제어에 연결할 때 필요한 범위 변경을 계산한다. 이전 LA−2mm의 손6관절 숫자를 그대로 재사용하지 않는다.

## 작은 단위와 검증

1. 현재 held-only와 initial-aligned의 실제 초기81각·초기 PD81각·유지81목표·1200개 명령을 읽는다. 기존 fret47,000/strike10,000 checkpoint 계약·공용 MJCF·fret hard-limit profile에서 source 범위를 다시 계산한다. 저장된 bridge mapping과 이름/float32 mid·half·scale를 exact 대조한다.
2. Native 범위, source 범위, 정규화 action [-1,1]이 표현하는 범위의 교집합을 이름으로 구성한다. 각 조건/관절의 실제 초기각·PD초기각·유지목표와 명령 최솟값/최댓값의 이탈량·가장 가까운 범위까지의 signed 최소 변경을 rad/도로 저장한다. 위반0/유효 자세를 강제하는 결과 gate는 두지 않는다. 양쪽30+30/Thorax6/held15 제어권과 동일 명령 계약도 검산한다.
3. 현재 목표가 범위 밖이면 bridge warm-start가 거절하는지 실제 CPU 호출로 확인한다. 가까운 유효각은 계산상 참고값이며 trial이나 물리 상태에 적용하지 않는다. 두 조건의 strict G0 자격도 원본 metadata 그대로 기록한다. 모델은 instantiate/forward하지 않는다.
4. Sol이 변경 방향을 정하고 Luna가 확정 brief의 표/그래프·한국어 설명을 만든다. 별도 change-reviewer 검수 뒤 해당 결과를 다음 fresh-native 초기 배치 계획에 사용한다.

- [ ] 새 분석 코드·기록 wrapper 작성 및 사전 검수
- [ ] CPU 범위 재계산·현재 두 후보 대조·입력 전후SHA 확인
- [ ] 최소 변경량의 물리적 의미 검토·다음 초기 배치 결정
- [ ] 저장자료 그림·결과·독립검수·보존 기록

## 범위와 보존

이번 단위는 필요한 표현 범위 조건을 조사한다. Strike pick-grip 후처리와 Fret event/stage별 추가 제약, 전체 관측420/303·clock/history의 runtime 연결과 자유기타 연주 성능까지 인증하지 않는다. 초기 실제각과 PD목표/제출 명령을 구별하고 scalar각을 해부학적 bone 회전으로 설명하지 않는다. 범위까지의 최소각은 안정한 변경 방향이나 관통 없는 자세의 예측이 아니다. Finger1 다축을 기존18좌표 조건부FK에 넣지 않는다.

Root·하체 고정/몸통9 목표/Thorax이하66권한/기타 초기p·q/현재 LA1.1018469719600776m는 유지한다. 이번 신규 native/physics/actor추론/학습은0이며 기타 고정·손부착·지속pose덮어쓰기·무단history clipping을 하지 않는다. 스트랩 출처 질문은 pending이지만 길이 탐색은 하지 않는다. 자연스러운 임시 허용구역을 정식 성공 기준으로 바꾸지 않는다.

메인 계획·구현은 /home/ajou/yigyu/3/stability_adapter_2, 결과는 /home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/fixed_strap_source_compatibility_v1 이다. 기존 봉인 결과/공용 자산은 수정하지 않는다. 측정 전에 wrapper·분석 소스·실제 import된 프로젝트 helper와 직접 읽는 자료의 SHA/사본을 저장한다. 과거 snapshot을 재귀 복사하거나 모든 이전 입력closure를 새 측정 입력으로 확장하지 않는다. 명령·환경·로그·종료·전후SHA를 남긴다.

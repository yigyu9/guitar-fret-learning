"""Build labeled contact sheets from the sealed 25-case native static comparison."""
import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
PHASE = ROOT / 'docs/2026-10-12/stability_adapter_2/results/static_guitar_natural_range_v1'
COMPARISON = PHASE / 'native/comparison.json'
OUT = PHASE / 'artifacts'
FONT = Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
CELL = (480, 270)
ROW_GUTTER = 190
TITLE_H = 42
COLUMN_H = 44
VIEWS = {
    'front': lambda case: Path(case['path']) / 'front.png',
    'side': lambda case: Path(case['path']) / 'side.png',
    'hands': lambda case: Path(case['path']) / 'images/frames/hands/00000.png',
}
TRANSLATION_COLUMNS = [-40, -20, 0, 20, 40]
ROTATION_COLUMNS = [-10, -5, 0, 5, 10]


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    with Path(path).open(encoding='utf-8') as stream:
        return json.load(stream)


def write_json(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, sort_keys=True)
        stream.write('\n')


def resolved_under(path, parent):
    path, parent = Path(path).resolve(), Path(parent).resolve()
    try:
        path.relative_to(parent)
    except ValueError:
        raise ValueError('native comparison row path escapes its phase')
    return path


def case_index(rows):
    result = {row['id']: row for row in rows}
    if len(result) != len(rows):
        raise ValueError('duplicate comparison case id')
    return result


def zero_vector(vector):
    return len(vector) == 3 and all(abs(float(value)) < 1e-12 for value in vector)


def translation_cases(index, axis):
    values = {}
    for case in index.values():
        translation = case['translation_W_m']
        rotation = case['rotation_delta_deg']
        if not zero_vector(rotation):
            continue
        delta_mm = [float(value) * 1000.0 for value in translation]
        other_axes_zero = all(abs(delta_mm[i]) < 1e-9 for i in range(3) if i != axis)
        if not other_axes_zero:
            continue
        amount = int(round(delta_mm[axis]))
        if amount not in TRANSLATION_COLUMNS:
            continue
        if amount == 0 and case['id'] != 'baseline':
            continue
        if amount != 0 and case['id'] == 'baseline':
            continue
        if amount in values:
            raise ValueError('duplicate translation sample on axis '+str(axis))
        values[amount] = case
    if set(values) != set(TRANSLATION_COLUMNS):
        raise ValueError('incomplete translation samples on axis '+str(axis))
    return values


def rotation_cases(index, axis):
    values = {}
    for case in index.values():
        if not zero_vector(case['translation_W_m']):
            continue
        delta = [float(value) for value in case['rotation_delta_deg']]
        other_axes_zero = all(abs(delta[i]) < 1e-9 for i in range(3) if i != axis)
        if not other_axes_zero:
            continue
        amount = int(round(delta[axis]))
        if amount not in ROTATION_COLUMNS:
            continue
        if amount == 0 and case['id'] != 'baseline':
            continue
        if amount != 0 and case['id'] == 'baseline':
            continue
        if amount in values:
            raise ValueError('duplicate rotation sample on axis '+str(axis))
        values[amount] = case
    if set(values) != set(ROTATION_COLUMNS):
        raise ValueError('incomplete rotation samples on axis '+str(axis))
    return values


def expected_image_sha(case, view, path, capture_json):
    if view in ('front', 'side'):
        mapping = case['extra_image_sha256']
        expected = mapping.get(str(path))
        if expected is None:
            expected = mapping.get(str(path.resolve()))
        if expected is None:
            raise ValueError('extra camera SHA missing for '+str(path))
        return expected
    capture = read_json(capture_json)
    frames = capture.get('frames', [])
    if len(frames) != 1 or frames[0].get('physics_step') != 0:
        raise ValueError('hands capture is not the single t0 static frame')
    for recorded_path, expected in frames[0].get('image_sha256', {}).items():
        if Path(recorded_path).resolve() == path.resolve():
            return expected
    raise ValueError('hands image SHA missing from capture metadata')


def prepare_case(case, native_root, input_hashes):
    case_dir = resolved_under(case['path'], native_root)
    case_json = case_dir / 'comparison.json'
    capture_json = case_dir / 'images/capture.json'
    for path in (case_json, capture_json):
        if not path.is_file():
            raise FileNotFoundError(path)
        input_hashes[str(path.resolve())] = sha256(path)
    local = read_json(case_json)
    if local.get('id') != case['id'] or not all(local.get('checks', {}).values()):
        raise ValueError('per-case record mismatch or failed native checks: '+case['id'])
    if local.get('native_state', {}).get('physics_step') != 0:
        raise ValueError('nonzero native state step: '+case['id'])
    prepared = {}
    for view, path_fn in VIEWS.items():
        path = path_fn(case).resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        actual = sha256(path)
        expected = expected_image_sha(local, view, path, capture_json)
        if actual != expected:
            raise ValueError('image SHA mismatch: '+str(path))
        input_hashes[str(path)] = actual
        with Image.open(path) as source:
            if source.size[0] <= 0 or source.size[1] <= 0:
                raise ValueError('invalid source image dimensions: '+str(path))
            if source.mode == 'RGBA' and source.getchannel('A').getextrema() != (255, 255):
                raise ValueError('transparent source image cannot be flattened losslessly: '+str(path))
            image = source.convert('RGB')
            image.thumbnail(CELL, Image.Resampling.LANCZOS)
            prepared[view] = image.copy()
    return prepared, {'case_id': case['id'], 'case_path': str(case_dir),
                      'comparison_json': str(case_json.resolve()),
                      'comparison_sha256': input_hashes[str(case_json.resolve())]}


def centered(draw, box, text, font, fill):
    left, top, right, bottom = box
    bounds = draw.textbbox((0, 0), text, font=font)
    width, height = bounds[2] - bounds[0], bounds[3] - bounds[1]
    draw.text((left + (right-left-width)/2 - bounds[0],
               top + (bottom-top-height)/2 - bounds[1]), text, font=font, fill=fill)


def build_sheet(kind, axis_name, view, values, labels, images, out_path, fonts):
    width = ROW_GUTTER + len(labels) * CELL[0]
    height = TITLE_H + COLUMN_H + len(axis_name) * CELL[1]
    sheet = Image.new('RGB', (width, height), (242, 244, 247))
    draw = ImageDraw.Draw(sheet)
    title = ('Translation' if kind == 'translation' else 'Rotation') + ' — ' + view.title() + ' view'
    centered(draw, (ROW_GUTTER, 0, width, TITLE_H), title, fonts['title'], (20, 28, 38))
    for col, label in enumerate(labels):
        x0 = ROW_GUTTER + col * CELL[0]
        centered(draw, (x0, TITLE_H, x0 + CELL[0], TITLE_H + COLUMN_H), label,
                 fonts['column'], (25, 35, 45))
    cells = []
    for row_idx, (axis, cases_by_value) in enumerate(axis_name):
        y0 = TITLE_H + COLUMN_H + row_idx * CELL[1]
        centered(draw, (0, y0, ROW_GUTTER, y0 + CELL[1]), axis,
                 fonts['row'], (25, 35, 45))
        for col_idx, value in enumerate(values):
            case = cases_by_value[value]
            x0 = ROW_GUTTER + col_idx * CELL[0]
            image = images[case['id']][view]
            if image.size != CELL:
                raise ValueError('source is not a 16:9 cell fit: '+case['id']+'/'+view)
            sheet.paste(image, (x0, y0))
            cells.append({'row': axis, 'column': labels[col_idx], 'case_id': case['id'],
                          'case_path': case['path'], 'source_image': str(VIEWS[view](case).resolve()),
                          'source_image_sha256': sha256(VIEWS[view](case))})
    sheet.save(out_path, format='PNG', optimize=False)
    return cells


def main():
    if not COMPARISON.is_file():
        raise FileNotFoundError('native comparison is not ready: '+str(COMPARISON))
    comparison_sha = sha256(COMPARISON)
    data = read_json(COMPARISON)
    rows = data.get('rows')
    if not isinstance(rows, list) or len(rows) != 25:
        raise ValueError('expected exactly 25 native comparison rows')
    if data.get('physics_steps') != 0 or not all(data.get('checks', {}).values()):
        raise ValueError('native comparison top-level checks failed or physics steps are nonzero')
    index = case_index(rows)
    if 'baseline' not in index:
        raise ValueError('baseline row is missing')

    producer = Path(__file__).resolve()
    input_hashes = {str(producer): sha256(producer), str(COMPARISON.resolve()): comparison_sha,
                    str(FONT): sha256(FONT)}
    native_root = (PHASE / 'native').resolve()
    image_cache = {}
    for case in rows:
        image_cache[case['id']], _ = prepare_case(case, native_root, input_hashes)

    fonts = {'title': ImageFont.truetype(str(FONT), 25),
             'column': ImageFont.truetype(str(FONT), 22),
             'row': ImageFont.truetype(str(FONT), 20)}
    input_sha_before = dict(input_hashes)
    if any(sha256(path) != digest for path, digest in input_sha_before.items()):
        raise RuntimeError('a bounded input changed while validating native images')
    OUT.mkdir(parents=True, exist_ok=False)
    mapping = {'source_comparison': str(COMPARISON.resolve()),
               'source_comparison_sha256': comparison_sha,
               'image_cell_px': list(CELL),
               'aspect_handling': 'aspect-preserving thumbnail fit; no crop, overlay, or geometry edit',
               'views': list(VIEWS), 'sheets': {}}
    output_hashes = {}

    translation_rows = [('World X', translation_cases(index, 0)),
                        ('World Y', translation_cases(index, 1)),
                        ('World Z', translation_cases(index, 2))]
    rotation_rows = [('Neck elevation', rotation_cases(index, 0)),
                     ('Audience yaw', rotation_cases(index, 1)),
                     ('Board recline', rotation_cases(index, 2))]
    sheet_specs = [
        ('translation', 'translation', translation_rows, TRANSLATION_COLUMNS,
         ['-40 mm', '-20 mm', 'Baseline', '+20 mm', '+40 mm']),
        ('rotation', 'rotation', rotation_rows, ROTATION_COLUMNS,
         ['-10°', '-5°', 'Baseline', '+5°', '+10°']),
    ]
    for kind, prefix, row_specs, values, labels in sheet_specs:
        for view in VIEWS:
            filename = 'contact_sheet_%s_%s.png' % (prefix, view)
            cells = build_sheet(kind, row_specs, view, values, labels, image_cache,
                                 OUT / filename, fonts)
            out_path = OUT / filename
            output_hashes[str(out_path.resolve())] = sha256(out_path)
            mapping['sheets'][filename] = {'kind': kind, 'view': view,
                                           'row_labels': [item[0] for item in row_specs],
                                           'column_labels': labels, 'cells': cells,
                                           'output_sha256': output_hashes[str(out_path.resolve())]}

    if sha256(COMPARISON) != comparison_sha or any(sha256(path) != digest for path, digest in input_sha_before.items()):
        raise RuntimeError('a bounded input changed while building contact sheets')
    write_json(OUT / 'case_mapping.json', mapping)
    output_hashes[str((OUT / 'case_mapping.json').resolve())] = sha256(OUT / 'case_mapping.json')
    manifest = {'producer': str(producer), 'producer_sha256': input_sha_before[str(producer)],
                'source_comparison': str(COMPARISON.resolve()), 'source_comparison_sha256': comparison_sha,
                'bounded_input_sha256': input_sha_before, 'outputs_sha256': output_hashes,
                'case_count': len(rows), 'sheet_count': len(mapping['sheets']),
                'sheet_names': sorted(mapping['sheets']),
                'scope': 'contact-sheet packaging of existing native PNGs; no simulation or source-image editing'}
    write_json(OUT / 'artifact_manifest.json', manifest)
    print(json.dumps({'output': str(OUT), 'sheets': sorted(mapping['sheets']),
                      'case_count': len(rows), 'source_count': len(input_sha_before)}, indent=2))


if __name__ == '__main__':
    main()

"""Plot the recorded static guitar-Z source-shape preview (no simulation)."""
import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="preview.json")
    parser.add_argument("--output", type=Path, required=True, help="PNG output path")
    args = parser.parse_args()
    preview = json.loads(args.input.read_text())
    rows = preview["rows"]
    offsets = [row["guitar_z_offset_mm"] for row in rows]
    hips, elbows, negative_pairs, routes, rest_lengths = [], [], [], [], []
    for row in rows:
        gaps = {}
        for pair in row["source_geometry"]["pairs_within_limit"]:
            body = pair["human_body"]
            gap_mm = pair["signed_gap_m"] * 1000
            gaps[body] = min(gaps.get(body, float("inf")), gap_mm)
        hips.append(gaps.get("R_Hip", float("nan")))
        elbows.append(gaps.get("R_Elbow", float("nan")))
        negative_pairs.append(row["source_geometry"]["negative_gap_pair_count"])
        routes.append(row["initial_route_length_m"])
        rest_lengths.append(row["absolute_rest_length_m"])

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
    ax = axes[0]
    ax.plot(offsets, hips, marker="o", color="#2563a6", label="R_Hip minimum signed gap")
    ax.plot(offsets, elbows, marker="s", color="#d97706", label="R_Elbow minimum signed gap")
    ax.axhline(0, color="#222", lw=1)
    ax.axvline(5, color="#16803c", lw=1, ls="--", label="+5 mm candidate")
    ax.set(xlabel="Guitar initial world-Z offset (mm)", ylabel="Source-query signed gap (mm)",
           title="Static source-shape gaps")
    ax.grid(True, alpha=.25)
    ax.legend(fontsize=8)

    ax = axes[1]
    route_delta_mm = [(route - rest) * 1000 for route, rest in zip(routes, rest_lengths)]
    ax.plot(offsets, route_delta_mm, marker="o", color="#7c3aed", label="Route − absolute rest length")
    ax.axhline(0, color="#222", lw=1)
    ax.axvline(5, color="#16803c", lw=1, ls="--", label="+5 mm candidate")
    ax.set(xlabel="Guitar initial world-Z offset (mm)", ylabel="Route minus rest length (mm)",
           title="Static route-length comparison")
    ax.grid(True, alpha=.25)
    ax.legend(fontsize=8)
    fig.suptitle("Static CPU source-geometry preview — no native rollout", fontsize=12)
    fig.text(.5, .01,
             "Negative pair counts at offsets 0/2/5/10/15 mm: " + ", ".join(map(str, negative_pairs)) +
             ". 1404 pairs per offset. Signed gap is not calibrated PhysX clearance; strap length is static at zero velocity.",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .075, 1, .92))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=170, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()

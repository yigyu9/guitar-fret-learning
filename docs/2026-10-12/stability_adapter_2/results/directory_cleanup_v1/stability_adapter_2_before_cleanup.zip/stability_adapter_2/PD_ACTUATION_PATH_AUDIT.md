# 원본 연주 PD와 CPU 진단 구동 경로 감사

2026-10-07. Shoulder stiffness300이 추종·손 이탈을 개선하지 못했다. 초기각/LA를
계속 세분화하기 전에 원본 fret·strike와 현재 진단이 같은 구동 경로인지 확인한다.
이 단계는 코드·저장 자료만 읽으며 native 초기화/step과 제어 조건 변경이 없다.

- [x] 1. 원본 base/safety의 실제 함수로105 이름의 nominal gain/cap을 계산해
  현재 stiffness200 저장 properties와 대조한다. Fret/Strike/Main66/Torso9 연결을 확인한다.
- [x] 2. driveMode·토크/목표 API와 설치된 공식 문서를 source 줄·SHA로 기록한다.
  문서의 EFFORT 요구와 원본 POS+force tensor 코드 사이 차이를 runtime 효과와 구별한다.
- [x] 3. Luna가 경로 그림·표·설명을 만들고 독립 검수한다. 다음 구동 변경은
  먼저 사용자에게 확인하며, 원본 기타 고정·하체 state 재주입을 승계하지 않는다.

기준 자료는 shoulder_pd_compare_v1/hold_05s/kp200/report.json이다. 동일 숫자의
gain/cap이 같아도 solver position PD와 명시적 stiffness torque는 같은 actuator가 아니다.
원본 `kp*(target-q)`에는 Python의 SO(3) 오차나 explicit velocity damping이 없고,
감쇠는 solver에 맡긴다. Solver 내부 구면 오차와 실제 tensor torque 적용은 별도 검증 대상이다.
Total DOF force는 actuator-only 토크가 아니므로 그 값으로 API 무시·포화를 단정하지 않는다.

코드에서 원본은 기타 fixed base/gravity OFF, 하체 pinch limits·armature·매step state
재주입을 사용한다. 현재 자유 기타/몸통 PD 목표/주요66과 비교할 때 이 조건은 제외한다.
Strike의 grip 'pinch' action 제한을 손의 hard-limit 고정으로 설명하지 않는다.
현재 main66은 인터페이스이며 학습 action 차원을 정하지 않는다. 연주 목표+안정화
보정은 하나의 최종 관절 목표로 합친 뒤 검증된 구동기 한 경로에 전달해야 한다.

실행/그림/설명은 docs/2026-10-12/stability_adapter_2/results/pd_actuation_paths_v1에
저장한다. 이 감사가 원본 실행 실패나 새 actuator의 물리적 성공을 증명하지는 않는다.

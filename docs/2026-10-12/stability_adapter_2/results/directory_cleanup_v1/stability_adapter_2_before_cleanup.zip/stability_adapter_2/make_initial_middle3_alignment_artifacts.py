"""Plot frozen saved-series for initial middle3 alignment; no simulation calls."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import shutil

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / 'docs/2026-10-12/stability_adapter_2/results/initial_middle3_alignment_v1'
A = ROOT / 'stability_adapter_2'
NATIVE = P / 'native'
LABELS = ['held_only', 'initial_aligned']
DISPLAY = {'held_only': 'Held-only start', 'initial_aligned': 'Initial aligned'}
COLORS = {'held_only': '#4C78A8', 'initial_aligned': '#F58518'}
DECISION = A / 'INITIAL_MIDDLE3_ALIGNMENT_DECISION.md'
PLAN = A / 'INITIAL_MIDDLE3_ALIGNMENT_PLAN.md'
ANALYZER = A / 'analyze_initial_middle3_alignment.py'
MEDIA = [
    NATIVE / 'frames/hands/00000.png', NATIVE / 'frames/hands/00150.png',
    NATIVE / 'hands.mp4', NATIVE / 'whole_body.mp4',
]
EXTRA_FILES = [
    P / 'analysis.json', P / 'joint_series.jsonl', P / 'guitar_series.jsonl', P / 'windows.jsonl',
    P / 'analysis_execution.json', P / 'native_execution.json', P / 'native.log',
    P / 'native/videos.json', P / 'native/attempt.json', P / 'native/tasks.jsonl',
    DECISION, PLAN, ANALYZER,
    Path('/tmp/run_initial_middle3_alignment_analysis.py'),
    A / 'run_initial_middle3_alignment_phase.py',
] + MEDIA


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read_rows(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()]


def archive_path(path, destination):
    path = Path(path).resolve()
    try:
        rel = path.relative_to(ROOT)
        return destination / 'repo' / rel
    except ValueError:
        return destination / 'external' / Path(*path.parts[1:])


def limits_with_margin(values):
    low = float(np.min(values))
    high = float(np.max(values))
    margin = max((high - low) * 0.08, max(abs(low), abs(high), 1.0) * 0.015)
    return low - margin, high + margin


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out-dir', required=True)
    args = parser.parse_args()
    out = Path(args.out_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    figure = out / 'initial_middle3_alignment_summary.png'
    manifest_path = out / 'artifact_manifest.json'
    snapshot_path = out / 'source_snapshot.json'
    wrapper = out / 'run_producer.sh'
    if any(p.exists() for p in (figure, manifest_path, snapshot_path, out / 'source_snapshot', out / 'producer_execution.json')):
        raise SystemExit('refusing to overwrite prior artifact evidence')

    analysis = json.loads((P / 'analysis.json').read_text())
    checks = analysis.get('checks', {})
    if len(checks) != 23 or not all(checks.values()):
        raise RuntimeError('expected 23 passing analysis checks')
    if analysis.get('input_sha256_before') != analysis.get('input_sha256_after'):
        raise RuntimeError('analysis input hashes differ before/after')
    expected_sources = analysis['input_sha256_before']
    if len(expected_sources) != 29:
        raise RuntimeError('expected exactly 29 analysis input hashes')
    summary = {row['label']: row for row in analysis['summary']}
    if list(summary) != LABELS:
        raise RuntimeError('unexpected condition order in analysis summary')

    paths = {Path(path) for path in expected_sources}
    paths.update(EXTRA_FILES)
    paths.update([Path(__file__).resolve(), wrapper])
    paths = sorted((path.resolve() for path in paths), key=str)
    before = {str(path): sha(path) for path in paths}
    for path, expected_sha in expected_sources.items():
        if before.get(path) != expected_sha:
            raise RuntimeError('current source differs from analysis SHA: ' + path)

    snapshot_root = out / 'source_snapshot'
    records = []
    for path in paths:
        copied = archive_path(path, snapshot_root)
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, copied)
        digest = sha(path)
        if sha(copied) != digest:
            raise RuntimeError('source archive SHA mismatch: ' + str(path))
        records.append({'original_path': str(path), 'copy_path': str(copied), 'sha256': digest})
    snapshot_path.write_text(json.dumps({'files': records}, indent=2) + '\n')

    joint_rows = read_rows(P / 'joint_series.jsonl')
    guitar_rows = read_rows(P / 'guitar_series.jsonl')
    window_rows = read_rows(P / 'windows.jsonl')
    if len(joint_rows) != 2 * 1201 or len(guitar_rows) != 2 * 1201 or len(window_rows) != 2 * 121:
        raise RuntimeError('unexpected series/window record counts')
    joint_by_label, guitar_by_label, windows_by_label = {}, {}, {}
    for label in LABELS:
        joints = [row for row in joint_rows if row['label'] == label]
        guitar = [row for row in guitar_rows if row['label'] == label]
        if len(joints) != 1201 or len(guitar) != 1201:
            raise RuntimeError('incomplete series: ' + label)
        for rows in (joints, guitar):
            if [row['physics_step'] for row in rows] != list(range(1201)):
                raise RuntimeError('unordered series: ' + label)
            if any(not math.isclose(row['time_s'], row['physics_step'] / 240.0, rel_tol=0.0, abs_tol=1e-12) for row in rows):
                raise RuntimeError('series clock mismatch: ' + label)
        goal = float(summary[label]['middle3_goal_deg'])
        if any(not math.isclose(row['middle3_held_goal_deg'], goal, rel_tol=0.0, abs_tol=1e-9) for row in joints):
            raise RuntimeError('held middle3 goal mismatch: ' + label)
        if not math.isclose(joints[-1]['middle3_actual_deg'], summary[label]['middle3_actual_samples_deg']['5.0'], rel_tol=0.0, abs_tol=1e-9):
            raise RuntimeError('five-second middle3 angle mismatch: ' + label)
        early = [row for row in guitar if row['time_s'] <= 0.5]
        if len(early) != 121 or early[0]['time_s'] != 0.0 or early[-1]['time_s'] != 0.5:
            raise RuntimeError('early window must be 121 samples including endpoints: ' + label)
        early_summary = summary[label]['early_0_to_05s']
        comparisons = [
            (max(row['position_error_mm'] for row in early), early_summary['max_initial_position_error_mm']),
            (max(row['rotation_error_deg'] for row in early), early_summary['max_initial_rotation_error_deg']),
            (max(row['linear_speed_mps'] for row in early), early_summary['max_linear_speed_mps']),
            (max(row['angular_speed_rad_s'] for row in early), early_summary['max_angular_speed_rad_s']),
        ]
        if any(not math.isclose(a, b, rel_tol=0.0, abs_tol=1e-9) for a, b in comparisons):
            raise RuntimeError('early guitar summary mismatch: ' + label)
        local_windows = [row for row in window_rows if row['label'] == label]
        if len(local_windows) != 121:
            raise RuntimeError('unexpected late window count: ' + label)
        if sum(bool(row['within_provisional_limits']) for row in local_windows) != summary[label]['windows_within_provisional_limits']:
            raise RuntimeError('window pass count differs from summary: ' + label)
        outside_initial = sum(
            row['position_error_mm'] > 30.0 or row['rotation_error_deg'] > 5.0
            for row in guitar
        )
        if outside_initial != summary[label]['outside_initial_envelope_samples']:
            raise RuntimeError('initial envelope count differs from guitar series: ' + label)
        if not math.isclose(max(row['max_position_change_mm'] for row in local_windows), summary[label]['max_1s_position_change_mm'], rel_tol=0.0, abs_tol=1e-12):
            raise RuntimeError('late position summary mismatch: ' + label)
        if not math.isclose(max(row['max_rotation_change_deg'] for row in local_windows), summary[label]['max_1s_rotation_change_deg'], rel_tol=0.0, abs_tol=1e-12):
            raise RuntimeError('late rotation summary mismatch: ' + label)
        joint_by_label[label], guitar_by_label[label], windows_by_label[label] = joints, guitar, local_windows

    fig, axes = plt.subplots(2, 2, figsize=(14.4, 9.0), gridspec_kw={'width_ratios': [1.15, 1.0]})
    ax_joint, ax_early_position = axes[0]
    ax_early_rotation, ax_late = axes[1]
    handles = []
    for label in LABELS:
        color = COLORS[label]
        joints = joint_by_label[label]
        times = np.asarray([row['time_s'] for row in joints])
        actual, = ax_joint.plot(times, [row['middle3_actual_deg'] for row in joints], color=color, linewidth=1.7, label=DISPLAY[label])
        handles.append(actual)
    common_goal = float(summary['held_only']['middle3_goal_deg'])
    if not math.isclose(common_goal, summary['initial_aligned']['middle3_goal_deg'], rel_tol=0.0, abs_tol=1e-12):
        raise RuntimeError('conditions do not share the same absolute held target')
    goal_line = ax_joint.axhline(common_goal, color='#222222', linestyle='--', linewidth=1.25, label='Common held goal')
    handles.append(goal_line)
    ax_joint.set_xlim(0.0, 5.0)
    ax_joint.set_xticks(np.arange(0.0, 5.01, 1.0))
    ax_joint.set_xlabel('simulation time (s)')
    ax_joint.set_ylabel('middle3 scalar joint angle (deg)')
    ax_joint.set_title('Middle3 actual angle · common held target', loc='left', fontweight='bold')
    ax_joint.grid(alpha=0.22)

    for label in LABELS:
        rows = [row for row in guitar_by_label[label] if row['time_s'] <= 0.5]
        color = COLORS[label]
        times = np.asarray([row['time_s'] for row in rows])
        ax_early_position.plot(times, [row['position_error_mm'] for row in rows], color=color, linewidth=1.6, label=DISPLAY[label])
        ax_early_rotation.plot(times, [row['rotation_error_deg'] for row in rows], color=color, linewidth=1.6, label=DISPLAY[label])
    ax_early_position.set_xlim(0.0, 0.5)
    ax_early_position.set_xticks(np.arange(0.0, 0.501, 0.1))
    ax_early_position.set_ylim(*limits_with_margin([row['position_error_mm'] for rows in guitar_by_label.values() for row in rows if row['time_s'] <= 0.5]))
    ax_early_position.set_xlabel('simulation time (s)')
    ax_early_position.set_ylabel('guitar position error (mm)')
    ax_early_position.set_title('Early guitar position error · 0–0.5 s', loc='left', fontweight='bold')
    ax_early_position.grid(alpha=0.22)

    ax_early_rotation.set_xlim(0.0, 0.5)
    ax_early_rotation.set_xticks(np.arange(0.0, 0.501, 0.1))
    ax_early_rotation.set_ylim(*limits_with_margin([row['rotation_error_deg'] for rows in guitar_by_label.values() for row in rows if row['time_s'] <= 0.5]))
    ax_early_rotation.set_xlabel('simulation time (s)')
    ax_early_rotation.set_ylabel('guitar rotation error (deg)')
    ax_early_rotation.set_title('Early guitar rotation error · 0–0.5 s', loc='left', fontweight='bold')
    ax_early_rotation.grid(alpha=0.22)

    bar_entries = [
        ('held_only', 'max_1s_position_change_mm', 5.0, 'mm'),
        ('initial_aligned', 'max_1s_position_change_mm', 5.0, 'mm'),
        ('held_only', 'max_1s_rotation_change_deg', 1.0, '°'),
        ('initial_aligned', 'max_1s_rotation_change_deg', 1.0, '°'),
    ]
    y_values = [3.0, 2.2, 0.8, 0.0]
    fractions = []
    for (label, key, limit, unit), y in zip(bar_entries, y_values):
        value = float(summary[label][key])
        fraction = value / limit
        fractions.append(fraction)
        ax_late.barh(y, fraction, height=0.55, color=COLORS[label])
        ax_late.text(fraction + 0.02, y, '{:.3f} {}'.format(value, unit), va='center', fontsize=8)
    ax_late.axvline(1.0, color='#333333', linestyle='--', linewidth=1.2)
    ax_late.axhline(1.5, color='#999999', linewidth=0.8)
    ax_late.set_yticks(y_values, [DISPLAY[label] for label, _, _, _ in bar_entries])
    ax_late.set_xlim(0.0, max(1.1, max(fractions) + 0.18))
    ax_late.set_ylim(-0.5, 3.8)
    ax_late.set_xlabel('fraction of provisional limit')
    ax_late.set_title('Late rolling 1 s maximum change', loc='left', fontweight='bold')
    ax_late.grid(axis='x', alpha=0.22)
    ax_late.set_axisbelow(True)
    ax_late.text(0.02, 3.45, 'Position · limit 5 mm', fontsize=8)
    ax_late.text(0.02, 1.37, 'Rotation · limit 1°', fontsize=8)

    fig.suptitle('Initial middle3 alignment at unchanged absolute final target', fontsize=14, y=0.99)
    fig.legend(handles=handles, labels=[DISPLAY[label] for label in LABELS] + ['Common held goal'],
               loc='upper center', bbox_to_anchor=(0.5, 0.955), ncol=4, frameon=False, fontsize=8)
    fig.text(0.5, 0.055, 'Dashed black = shared middle3 held goal; other dashed lines = provisional thresholds in the bar panel.', ha='center', fontsize=9)
    fig.text(0.5, 0.032, 'Early panels: 0.000–0.500 s inclusive, 121 samples. Late windows: starts 2.000–4.000 s at 60 Hz, 121 × 241 samples.', ha='center', fontsize=9)
    fig.text(0.5, 0.009, 'Scalar angles and provisional envelope observations only; no naturalness or playing-success certification.', ha='center', fontsize=9)
    fig.tight_layout(rect=(0.02, 0.105, 0.98, 0.89), h_pad=2.2, w_pad=2.0)
    fig.savefig(figure, dpi=220, bbox_inches='tight')
    plt.close(fig)

    after = {str(path): sha(path) for path in paths}
    if before != after:
        raise RuntimeError('input SHA changed during artifact generation')
    outputs = {figure.name: sha(figure)}
    manifest = {
        'producer_sha256_before': before[str(Path(__file__).resolve())],
        'producer_sha256_after': after[str(Path(__file__).resolve())],
        'inputs_sha256_before': before,
        'inputs_sha256_after': after,
        'outputs_sha256': outputs,
        'native_initializations_during_artifact': 0,
        'physics_steps_during_artifact': 0,
        'actor_inference_calls_during_artifact': 0,
        'training_updates_during_artifact': 0,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'figure': str(figure), 'sha256': outputs[figure.name], 'input_count': len(before)}))


if __name__ == '__main__':
    main()

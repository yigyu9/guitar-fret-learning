# 현재 초기 자세에서 손 위치 유지 제어를 검토하는 순서

2026-10-07. 상태: 초기 FK 및 동일 PI0.1초 runtime 계측 완료. 새 위치 제어는 사용자 확인 전.
이전 p08 기반 `PALM_POSITION_RESIDUAL_PROPOSAL.md`는 보존한다.
현재 기준은 `trials/quiescent_3s_v1/reference.json`이며, LA1.1010801317960974m와
기타 +5mm 초기 위치·회전을 유지한다. 이탈한3초 기타 자세로 목표를 바꾸지 않는다.

## 이번 계측에서 확인한 문제

관절 PI ON에서도 왼손 source palm 체적 중심은1초138.278mm,3초144.535mm 이동했다.
같은 시점 palm body-origin 이동127.095/131.942mm와 다르다.
따라서 손 위치 task의 기준점을 관절·링크 원점으로 대신하면 다른 오차를 제어하게 된다.
현재 초기 왼손 source 중심 world 좌표는
`[-0.1442984888858093, 0.1317272392337778, 0.7436811806477285] m`다.
이는 해부학적 중심·접촉점·COM이 아니라 소스 충돌 형상 convex-hull 체적 중심이다.

Native 초기 Jacobian은CPU float32 `(1,65,6,105)`, palm rows L17/R43이다.
두 행에 값이 있고 조회 전후 상태·목표·PD·LA가 같지만, 아직 위치/회전 미분의
일반 runtime frame·속도 계약을 보장한 것은 아니다. 현재 초기 FK 대조에서는 왼팔12의
위치 좌표 변화에 SO(3) left tangent 변환이 필요하고 선형 기준점은 COM과 대응했다.
COM에서 source 중심으로 옮긴 최대 오차는0.274299mm/rad였다.
초기 수치 미분의 근거이며 같은-body MJCF importer의 일반 계약은 확정하지 않는다.
동일 PI0.1초 runtime 계측의 상태/trace/controls prefix도 재현했다. Refresh한 rawJ×native
velocity의 최대COM 속도 오차는LH1.500569mm/s/RH1.371527mm/s이며 정확한 항등식은 아니다.

## 다음 두 소단계

- [x] A. 현재 초기각에서 왼팔12의 fresh 초기 FK 유한차분을 native Jacobian과 대조한다.
  승인된C02±0.3rad∩모델 한계 안에서±0.001rad를 쓰고 경계는one-sided로 측정한다.
  양팔/손가락/몸통/C02하체의 다른 초기각·PD·LA·기타 목표를 유지한다.
  각 scene은 초기화 후 조회만 하고 물리 step을 실행하지 않는다.
  palm body-origin/COM/world source 중심과 angular Jacobian을 각각 비교한다.
  형상 중심의 Jacobian은 검증된 기준점에서 `J_point = J_linear - [r]× J_angular`로 옮긴다.
  frame·열 대응이 불일치하면 새 위치 controller를 실행하지 않는다.
- [ ] B. 동일 승인 PI 실행의 cache/속도 대응 계측을 완료했다.
  [현재3조건 비교안](PALM_POSITION_COMPARISON.md)의 중요 제어 변경 확인을 기다린다.
  기본 구조는 연주 `q_play + delta_final` 하나만 native PD에 전달하는 것이다.
  이번 무연주 진단의 위치 목표는 초기 손 위치이며 향후 연주에서는 연주 목표와 함께 갱신한다.
  임시 world 목표를 최종 연주의 영구 손 고정이나 강제 부착으로 승계하지 않는다.

이전 제안의 왼팔 bounded least-squares·PI regularizer·±0.15rad 보정 cap과
양팔0.02rad/update 변화율 제한은 검토 후보다. 새 변화율 제한도 제어 변경이므로
적용 전에 확인하며, 비교 시 기존 PI/변화율만 제한한PI/같은 변화율의 위치 보정을 구분한다.
실제 최종 목표에 대한 anti-windup, 위쪽 palm proxy 관찰, 목표/실제 관절 한계,
기타 p/q·속도·장력·접촉·포화를 기록한다. 임의 gain 확대·새 해부학적 hard limit은 추가하지 않는다.

주요 제어는Thorax 이하66이며 팔24만 이번 보정 진단에 쓴다. 몸통9·손가락42·
C02하체 목표 유지와 고정root·자유기타·기존물리를 유지한다. 기타 고정·손 부착·
지속 state/pose 덮어쓰기·기타에 직접 복원력 적용·학습은 없다.

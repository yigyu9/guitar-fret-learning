# 오른쪽 허벅지·왼손 손바닥의 초기 기타 접촉

사용자 요청: 초기 기타를 오른쪽 허벅지와 왼손 손바닥에서 지지하도록 관절을 설정한다.
추가 승인 없이 작은 단위로 시도한다. 원본/이전 실행은 보존한다.

첫 기준은 `lower_body_fixed_v1/full_1s`다. root·양쪽 하체는 물리 고정,
Torso/Spine/Chest 목표 유지, 주요 제어66, 손가락 초기각·오른팔·기존 PD/PI를 유지한다.
왼쪽 Thorax/Shoulder/Elbow/Wrist 초기각만 먼저 C02±0.3rad∩native 한계에서 조정한다.
기타는 초기화 뒤 자유이고 중력/수동 strap만 받는다. 손 부착/기타 고정/실행 중 pose 재주입은 없다.

1. 현재 H0를 읽고 R_Hip capsule–기타 body와 LH:palm–넥 간격을 계측한다.
   검증: analytic capsule 거리·convex hull QP/witness·위쪽 손바닥 proxy·국소 넥 아래.
   Signed mesh query의 cutoff 부호는 교차/접촉 증거로 단독 사용하지 않는다.
2. 왼팔 초기각 후보를 만들고 fresh native H0에서 검증한다. 초기 손–손 교차와
   의도하지 않은 사람–기타 관통을 제외한다. palm의 위쪽 반구 조건을 유지한다.
   초기 접촉은 목표이지만 형상 거리0만으로 PhysX 지지 접촉 성공이라고 부르지 않는다.
3. 최대3개 유망 조합을0.1초 free rollout으로 비교한다. 오른쪽 허벅지와 LH:palm의
   native 접촉 기록을 따로 확인하고 기타 p/q·strap·팔 실제각·손–손 교차를 기록한다.
   통과한 조합만0.5초로 연장하며 연주 안정 성공으로 간주하지 않는다.
4. 초기 장면/짧은 영상과 설명을 결과 문서에 추가하고 독립 검토한다.

하체와 기타 initial p/q가 모두 고정되면 R_Hip–기타 간격은 팔 관절로 바꿀 수 없다.
첫 계측에서 오른쪽 지지점에 간격이 있다면, 최소 이동의 기타 초기 배치 보정을 별도로
기록하고 그 새 위치를 유지 목표로 둔다. 이는 환경 초기화에 한정한 배치이며 runtime
기타 상태를 덮어쓰는 제어가 아니다. 초기 회전은 우선 유지한다. strap 경로가 달라지면
초기 무장력 LA를 다시 계산하고 이전 길이/장력을 그대로 성공 조건으로 승계하지 않는다.

코드/후보 설정: `stability_adapter_2/`.
원자료/로그/이미지/영상: `docs/2026-10-12/stability_adapter_2/results/thigh_palm_support_v1/`.

- [x] H0 두 지지점 계측
- [x] 초기 후보 설정·native 배치 검증
- [x] 짧은 free rollout·산출물·검토(목표 지지는 실패, 미채택)

H0 계측: R_Hip–기타 body 간격1.109889mm, LH:palm–넥0.545306mm다.
오른쪽 접촉을 위해 기타를 최초 생성 시 world(−0.397438,+0.011730,−0.982484)mm
정도 이동하는 후보를 만든다(실제 정밀값은 search.json). 회전은 유지한다.
목표 source gap50µm이며 native contact offset을 고려한 접근 후보이지 힘/접촉 보증은 아니다.

Wrist3만으로 접촉 witness를 이동한 첫3후보는 radial 이동 자유도가 부족해 약0.6mm
점 잔차와 작은 hull 교차가 남았다. native 시험 없이 제외하고 원자료를 보존한다.
다음에는 Wrist3+Elbow_x의4개 초기각만 기준±0.025rad∩C02±0.3rad/native 한계에서
함께 조정한다. 필요 최소 관절 이동을 부드럽게 선호하고50/100/150µm source 간격을
비교한다. Thorax/Shoulder/몸통/하체/손가락/오른팔은 유지한다.

후속 소단계: 세 후보 모두 첫 스텝부터 R_Hip 접촉이 있으나 LH:palm 접촉은0이다.
50µm 후보의 source gap은 완료step1에0.228878mm,0.1초에38.077508mm로 열린다.
0.5초 연장/안정 후보 채택은 하지 않는다. 두 초기 source 간격을2µm로 줄인 후보1개만
동일 범위/PD/PI에서 추가0.1초 검사한다. 초기 양손 교차는 없어도 step24에 공통
내부 구1쌍이 생기므로, 지속 지지로 채택하려면 실행 중 손–손 제약도 해결해야 한다.
Source/cooked 형상과 contact cache 시점이 다를 수 있어 source 간격을 native 지지와
동일시하지 않는다. 원래 세 후보·생성 코드 snapshot·runner 버전은 보존한다.

추가 결과:2µm 후보의 fresh source 손바닥–넥 간격은1.896279µm, 예측–native body
위치 차이 최대0.163782µm다. 실제 shape readback은 palm1/neck2 filter로 pair를
허용하고 두 contact offset은 각각0.1mm다. 그러나 native LH:palm contact0,
step1 source gap0.212747mm,step24 38.065514mm이며 R_Hip contact는24/24 step이다.
기타 최대4.041302mm/0.641189°(기준2.279551mm/0.997176°)로 이동·회전 tradeoff다.
초기 양손 source 교차0이나 마지막 표본 LH:palm–RH:index1 교차가 있어 지지 자세로
채택하지 않는다. cooked collider 차이/첫 solver phase는 미확정이고, 다음 진단은
첫 스텝의 왼팔 실제각·PD 목표·손바닥 이탈을 분리 계측하는 데 집중한다.
현재 구현은 초기 근접 자세 생성과 짧은 자유 실행 검증까지며 지속 지지 성공은 아니다.
원자료 provenance를 보완한 canonical 분석은 comparison_validated.json이다.

# 사전 검수 보완과 실제 실행 버전

원 계획 및 첫 producer와28개 순수 수학 검사 결과를 보존한다. 아직 native 실행은0회다. change-reviewer가 custom --cases의abs각상한이비대칭외곽의하한보다넓음을지적했다. 신규 render_guitar_playing_envelope_v2.py는각보정하한[-12,-15,-5]°와상한[18,15,15]°를분리해검사한다. 기본13끝점은변경없다.

실제 실행은 python -m stability_adapter_2.render_guitar_playing_envelope_v2 --out <새 native 경로>로 한다. 구 producer/계획/수학결과는 덮어쓰지 않는다. 신규버전의순수수학/범위거절검산과사전재검토후실제정적13개촬영을진행한다. 원계획의물리0/사람상태유지/스트랩표시OFF/원본보존/64조합미인증조건은그대로다.

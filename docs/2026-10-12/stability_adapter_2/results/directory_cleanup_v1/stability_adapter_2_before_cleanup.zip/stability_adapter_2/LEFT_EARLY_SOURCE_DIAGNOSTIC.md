# 왼손 초기 지지점의 첫 0.1초 source 형상 관찰

2026-10-07. 새 위치 제어 확인 대기와 독립적인 기존 초기 자세 진단이다.
quiescent_3s_v1/on의 저장 상태0/1/2/4/8/12/24를 읽고 추가 native 실행은 하지 않는다.

- [x] 원본 충돌 형상을 저장 native pose에 배치하여 palm–neck convex-hull unsigned
  거리/양 witness를 조회한다. 기존 backend20mm cutoff·부호 의미도 별도로 유지한다.
- [x] 같은 시점의 source 중심·palm landmark normal proxy·국소 neck 높이를 기록한다.
  완료 step의 native LH contact 행과 저장 pose 기반 형상 관찰을 구분한다.
  t=0에는 native contact 조회값을 만들지 않는다.
- [x] 초기/후기 source 형상과 witness/normal을 시각화하고 간격·방향 변화 표를 저장했다.
  원자료 SHA·실제 실행·기존 파일 보존·독립 검수를 기록한다.

거리 query와 normal은 원본 형상 진단이며 PhysX cooked clearance/힘/해부학적 palm
방향·지속 지지 인증은 아니다. Native state/pose·controller/gain/strap 길이를 바꾸지 않는다.
기존 주요66 연결·몸통9/손가락42/C02하체 목표·fixed root·기타 초기 +5mm 목표는 그대로다.
구현/계획은 stability_adapter_2, 결과는
docs/2026-10-12/stability_adapter_2/results/left_early_source_v1에 둔다.

## 실제 관측

Source convex-hull QP 거리0.545306mm는1 step0.610046mm,2 steps5.109051mm,
0.1초29.787930mm로 벌어졌다. 선택한 시점의 normal proxyZ는0.926890→0.965232로
양수였고, 국소 넥 하단 대비 중심 높이는−24.728169→−57.601284mm였다.
투영은 모두 넥 길이 범위 안이었다. T=0 native contact는 미조회이며 이후 선택한
완료 step의 native LH contact 행은0개다. 작은 초기 source 간격이 지속 지지를 뜻하지 않는다.

별도 backend signed query는 초기0.167218mm로 QP값과 달랐으며 원인은 확정하지 않는다.
0.1초 backend값20mm는 cutoff이고 실제20mm 간격으로 해석하지 않는다.
기존 현재 위치 제어 비교안의 확인 대기는 그대로이며 목표/gain/물리 변경은 없다.

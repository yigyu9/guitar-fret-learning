# 현재 고정LA 자세와 연주 source 범위의 차이

CPU 34검사와48입력/48사본 전후SHA를 확인했다. 체크포인트 fret47,000/strike10,000의 계약·공용 humanoid MJCF·fret profile에서 source/native/정규화 표현 교집합을 다시 계산했다. 이전 bridge의 float32 mapping은 exact였고 두현재후보의81×1200 최종 명령도 동일하다. 이번 신규 native/physics/actor추론/학습은0이다.

기존 held-only는 실제초기/PD초기6개, 유지목표/명령최솟값·최댓값5개가 범위 밖이다. 초기 middle3를52.09°에 맞춘 후보는 다섯종류 모두5개다. 남는 관절은 모두왼손 thumb1_x,thumb1_y,thumb3,index1_x,ring1_x다. 오른손과팔/Thorax의 이범위 위반은 없다. 이것은 필요한 box-range 조건의 결과이며 Strike pick-grip·Fret event/stage 후처리와 연주 기능까지 통과했다는 뜻은 아니다.

| 관절 | 새후보 실제초기에서 최소변경 rad | 유지목표에서 최소변경 rad |
|---|---:|---:|
| LH:thumb1_x |−0.167204916|−0.094772160|
| LH:thumb1_y |+0.661268771|+0.617647946|
| LH:thumb3 |−0.602567554|−0.505324721|
| LH:index1_x |−0.168908358|−0.204711854|
| LH:ring1_x |−0.141499698|−0.206355035|

부호는 현재값에 더할 방향이다. 최대초기차는 thumb1_y37.887910°이고 thumb3도34.524578°다. 이전LA−2mm의 thumb3 최소변경과 숫자가 다르므로 이전손6표를 그대로 사용하지 않는다. Scalar joint 좌표에서 범위까지의 수학적 거리를 구한 것이며 안정한 동작/해부학 회전/관통 없는 자세를 예측한 값이 아니다. 현재초기/유지목표는 native 관절범위 안에 있지만 source profile과의 차이가 남는다. Native 모델의 hard-limit을 source profile로 교체하지 않았다.

두조건의 현재유지목표를 그대로 넣은 PlayingTargetBridge warm-start는 CPU에서 모두거절했다. 임의 history clipping을 하지 않았다. 원본 strict G0 qualification도 두체크포인트 모두false인 상태로 보존했고 자격을 추가하거나 qualified loader를 우회하지 않았다. 이거절은 현재유지목표의 범위 문제이며, 실제연주 실패를 새로 측정한 결과가 아니다.

## 다음 물리 단위

[새 초기 배치 계획](/home/ajou/yigyu/3/stability_adapter_2/FIXED_STRAP_SOURCE_HAND_INITIAL_PLAN.md:1)에따라 초기52.09°후보를 시작점으로 위5관절의 초기각/유지목표를 각각 가장 가까운 source/native 교집합 경계 안쪽float32값으로 바꾼 한후보를 준비한다. 다른76초기각/목표·G초기p/q·LA1.1018469719600776m·PD·몸통목표/root하체고정·손목파형은유지한다. 초기값 변경이며 상태를매step 덮어쓰는 제어가 아니다. 큰엄지변경을 작고안전한 보정이라고 표현하지 않는다.

Finger1다축 때문에 기존18좌표 FK인증을 사용할수없다. Fresh native 실제초기pose에서 직접 source human–G/cross/self1188·palm상향/필터·관절 readback을검사한다. 실패하면0물리step 실제초기이미지와 이유를보존하고, 통과한한후보만actual5초/두스트랩영상으로검증한다. 계산상 가장가까운각도만으로후보를채택하지않으며 quiet 비교기준도보존한다. 다음초기각후보/새native gate/5초실험은아직미실행이다. 현재정지유지안정성만을기준으로팔·손·source제약을삭제하지않고 최종연주66권한을유지한다.

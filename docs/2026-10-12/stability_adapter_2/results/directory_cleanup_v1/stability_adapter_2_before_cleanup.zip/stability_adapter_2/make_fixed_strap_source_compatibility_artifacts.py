"""Plot direct saved-data range measurements for the two fixed-LA starts."""
from pathlib import Path
import hashlib
import json
import math
import shutil

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / 'docs/2026-10-12/stability_adapter_2/results/fixed_strap_source_compatibility_v1'
OUT = P / 'artifacts'
A = ROOT / 'stability_adapter_2'
INITIAL_FRAME = ROOT / 'docs/2026-10-12/stability_adapter_2/results/initial_middle3_alignment_v1/native/frames/hands/00000.png'
PNG_NAME = 'fixed_strap_source_range_changes.png'
LABELS = ['held_only', 'initial_aligned']
KINDS = ['actual_initial', 'initial_PD', 'held', 'command_min', 'command_max']
JOINTS = ['LH:thumb1_x', 'LH:thumb1_y', 'LH:thumb3', 'LH:index1_x', 'LH:middle3', 'LH:ring1_x']
DEG = 180.0 / math.pi
COLORS = {'held_only': '#3977a9', 'initial_aligned': '#e6812f', 'held': '#38946b'}
DISPLAY = {'held_only': 'Held-only actual initial',
           'initial_aligned': 'Initial-aligned actual initial',
           'held': 'Common held target'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text())


def load_jsonl(path):
    with Path(path).open() as stream:
        return [json.loads(line) for line in stream if line.strip()]


def direct_inputs():
    paths = [
        P / 'compatibility.json', P / 'joint_ranges.jsonl', P / 'execution.json',
        P / 'analysis.log', P / 'input_sha256_before.json',
        A / 'FIXED_STRAP_SOURCE_COMPATIBILITY_PLAN.md',
        A / 'FIXED_STRAP_SOURCE_COMPATIBILITY_DECISION.md',
        A / 'FIXED_STRAP_SOURCE_HAND_INITIAL_PLAN.md',
        A / 'audit_fixed_strap_source_compatibility.py',
        A / 'run_fixed_strap_source_compatibility.py',
        Path(__file__).resolve(), OUT / 'run_producer.sh',
        OUT / 'run_producer.sh.archived', INITIAL_FRAME,
    ]
    return [path.resolve() for path in paths]


def verify_source(compat, execution, before_map, rows):
    checks = compat.get('checks', {})
    if len(checks) != 34 or not all(checks.values()):
        raise RuntimeError('compatibility contract must contain 34 passing checks')
    if compat['input_sha256_before'] != compat['input_sha256_after']:
        raise RuntimeError('compatibility input maps changed during its run')
    if compat['input_sha256_before'] != before_map:
        raise RuntimeError('compatibility map differs from saved input_sha256_before.json')
    if execution['input_sha256_before'] != before_map or execution['input_sha256_after'] != before_map:
        raise RuntimeError('execution input maps differ from the frozen 48-input map')
    if len(before_map) != 48:
        raise RuntimeError('expected exactly 48 compatibility source hashes')
    if compat['joint_row_count'] != 810 or len(rows) != 810:
        raise RuntimeError('expected 810 joint range rows')
    if compat.get('native_initializations') != 0 or compat.get('physics_steps') != 0:
        raise RuntimeError('compatibility audit unexpectedly includes native/physics execution')
    if compat.get('actor_inference_calls') != 0 or compat.get('training_updates') != 0:
        raise RuntimeError('compatibility audit unexpectedly includes actor/training work')
    strict = [compat['sources'][task]['strict_G0_qualification']['qualified_for_g0']
              for task in ['fret', 'strike']]
    if strict != [False, False]:
        raise RuntimeError('checkpoint qualification state differs from the approved brief')

    summary = {entry['label']: entry for entry in compat['summary']}
    if set(summary) != set(LABELS):
        raise RuntimeError('unexpected summary labels')
    row_map = {}
    for row in rows:
        label, kind, name = row.get('label'), row.get('kind'), row.get('name')
        if label not in LABELS or kind not in KINDS or not isinstance(name, str):
            raise RuntimeError('malformed joint-range row identity')
        if not isinstance(row.get('outside_effective_range'), bool):
            raise RuntimeError('malformed range flag')
        rad = row.get('signed_minimum_change_rad')
        deg = row.get('minimum_change_deg')
        if not isinstance(rad, (int, float)) or not math.isfinite(rad):
            raise RuntimeError('malformed signed minimum change')
        if not isinstance(deg, (int, float)) or not math.isfinite(deg):
            raise RuntimeError('malformed degree conversion')
        if not math.isclose(deg, abs(rad) * DEG, rel_tol=0.0, abs_tol=1e-10):
            raise RuntimeError('radian-to-degree field mismatch')
        key = (label, kind, name)
        if key in row_map:
            raise RuntimeError('duplicate joint-range row')
        row_map[key] = row

    for label in LABELS:
        group_summary = summary[label]['ranges']
        for kind in KINDS:
            group = [row for row in rows if row['label'] == label and row['kind'] == kind]
            if len(group) != 81 or len({row['name'] for row in group}) != 81:
                raise RuntimeError('each label/kind must contain 81 unique joints')
            reference = group_summary[kind]
            outside_names = sorted(row['name'] for row in group if row['outside_effective_range'])
            if len(outside_names) != reference['outside_count']:
                raise RuntimeError('outside-range count differs from summary')
            if outside_names != sorted(reference['outside_names']):
                raise RuntimeError('outside-range names differ from summary')
            maximum = max(abs(row['signed_minimum_change_rad']) for row in group)
            if not math.isclose(maximum, reference['max_minimum_change_rad'], rel_tol=0.0, abs_tol=1e-12):
                raise RuntimeError('maximum minimum-change magnitude differs from summary')

    held_left = {row['name']: {key: value for key, value in row.items() if key != 'label'}
                 for row in rows if row['label'] == 'held_only' and row['kind'] == 'held'}
    held_right = {row['name']: {key: value for key, value in row.items() if key != 'label'}
                  for row in rows if row['label'] == 'initial_aligned' and row['kind'] == 'held'}
    if len(held_left) != 81 or held_left != held_right:
        raise RuntimeError('the two held-target maps are not exactly identical')
    for name in JOINTS:
        if name not in {row['name'] for row in rows}:
            raise RuntimeError('missing plotted joint: ' + name)
    return row_map, summary


def snapshot(paths, before):
    entries = []
    for path in paths:
        rel = path.relative_to(ROOT)
        copied = OUT / 'source_snapshot' / rel
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, copied)
        digest = sha(copied)
        if digest != before[str(path)]:
            raise RuntimeError('snapshot SHA mismatch: ' + str(path))
        entries.append({'original_path': str(path), 'copy_path': str(copied), 'sha256': digest})
    (OUT / 'source_snapshot.json').write_text(json.dumps({'files': entries}, indent=2) + '\n')


def make_figure(row_map):
    fig, ax = plt.subplots(figsize=(13.0, 8.3))
    y = np.arange(len(JOINTS))
    offsets = {'held_only': 0.22, 'initial_aligned': 0.0, 'held': -0.22}
    entries = [('held_only', 'actual_initial'), ('initial_aligned', 'actual_initial'), ('held', 'held')]
    heights = 0.19
    values = []
    for series, kind in entries:
        xs = [row_map[(series if series != 'held' else 'held_only', kind, joint)]['signed_minimum_change_rad'] * DEG
              for joint in JOINTS]
        values.extend(xs)
        yy = y + offsets[series]
        ax.barh(yy, xs, height=heights, color=COLORS[series], label=DISPLAY[series], zorder=3)
        for yi, xval in zip(yy, xs):
            pad = 0.55 if xval >= 0.0 else -0.55
            ax.text(xval + pad, yi, '{:+.2f}°'.format(xval),
                    ha='left' if xval >= 0.0 else 'right', va='center', fontsize=8.5)

    lo, hi = min(values), max(values)
    margin = max(2.0, (hi - lo) * 0.12)
    ax.set_xlim(lo - margin, hi + margin)
    ax.axvline(0.0, color='#252525', linewidth=1.1, zorder=2)
    ax.set_yticks(y)
    ax.set_yticklabels(JOINTS)
    ax.invert_yaxis()
    ax.set_xlabel('Signed minimum change toward effective range (degrees)')
    ax.set_ylabel('Scalar joint coordinate')
    ax.grid(axis='x', color='#dddddd', linewidth=0.7, zorder=0)
    for series, kind in entries:
        for yi, joint in zip(y + offsets[series], JOINTS):
            value = row_map[(series if series != 'held' else 'held_only', kind, joint)]['signed_minimum_change_rad']
            if value == 0.0:
                ax.scatter([0.0], [yi], marker='o', s=31, facecolors='white',
                           edgecolors=COLORS[series], linewidths=1.5, zorder=5)
    handles, labels = ax.get_legend_handles_labels()
    fig.suptitle('Current starts and held targets vs. source/native/normalized joint-range intersection',
                 y=0.985, fontsize=13, weight='bold')
    fig.legend(handles, labels, loc='upper center', bbox_to_anchor=(0.5, 0.935),
               ncol=3, frameon=False)
    fig.text(0.5, 0.035,
             'Bars convert signed_minimum_change_rad to degrees; positive means increase, negative means decrease.\n'
             'These are scalar range-distance references, not applied corrections or geometry/motion predictions.\n'
             'The shared held-target series is shown once because both measured held maps match exactly.',
             ha='center', va='bottom', fontsize=9.5, linespacing=1.4)
    fig.subplots_adjust(left=0.20, right=0.97, top=0.85, bottom=0.20)
    fig.savefig(OUT / PNG_NAME, dpi=190, bbox_inches='tight')
    plt.close(fig)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    expected_outputs = ['source_snapshot', 'source_snapshot.json', 'artifact_manifest.json',
                        'producer_execution.json', PNG_NAME]
    collisions = [name for name in expected_outputs if (OUT / name).exists()]
    if collisions:
        raise RuntimeError('refusing nonempty output path: ' + ', '.join(collisions))
    compat_path = P / 'compatibility.json'
    ranges_path = P / 'joint_ranges.jsonl'
    execution_path = P / 'execution.json'
    compat = load_json(compat_path)
    execution = load_json(execution_path)
    rows = load_jsonl(ranges_path)
    before_map = load_json(P / 'input_sha256_before.json')
    row_map, summary = verify_source(compat, execution, before_map, rows)
    paths = direct_inputs()
    before = {str(path): sha(path) for path in paths}
    snapshot(paths, before)
    make_figure(row_map)
    after = {str(path): sha(path) for path in paths}
    if before != after:
        raise RuntimeError('direct input files changed during plotting')
    output_path = OUT / PNG_NAME
    output_sha = sha(output_path)
    manifest = {
        'producer_sha256_before': before[str(Path(__file__).resolve())],
        'producer_sha256_after': after[str(Path(__file__).resolve())],
        'inputs_sha256_before': before,
        'inputs_sha256_after': after,
        'outputs_sha256': {PNG_NAME: output_sha},
        'direct_input_count': len(paths),
        'compatibility_closure_input_count': len(before_map),
        'compatibility_checks': len(compat['checks']),
        'joint_range_rows': len(rows),
        'native_initializations': 0,
        'physics_steps': 0,
        'actor_inference_calls': 0,
        'training_updates': 0,
    }
    (OUT / 'artifact_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'png': str(output_path), 'sha256': output_sha,
                      'direct_input_count': len(paths),
                      'held_range_exact': True,
                      'outside_counts': {label: {
                          kind: summary[label]['ranges'][kind]['outside_count'] for kind in KINDS
                      } for label in LABELS}}, indent=2))


if __name__ == '__main__':
    main()

# 위치 허용영역 시각 강조 계획

기존 위치영역과 기타 pose를 유지하면서 front/side/top 이미지에서 영역이 더 잘 보이도록 다시 만든다. 기존 `기타허용범위/front.png`, `side.png`, `top.png`는 수정하지 않고 `기타허용범위/범위강조_v2/`에 새 이미지 세 장을 저장한다.

- 의미는 기존과 동일하다: world guitar actor-root 허용영역 X `[-0.50,-0.15]m`, Y `[-0.15,0.15]m`, Z `[0.65, Chest-origin-z]m`; 중심 표시는 actor-root reference `[-0.325,0,0.800]m`다.
- 초기 humanoid·guitar pose는 고정한다. actor-root를 body center로 재해석하거나 위치를 바꾸지 않는다.
- 3D 박스의 가려지지 않는 면에는 깊이 검사된 반투명 색면, 모서리에는 굵고 선명한 선을 적용한다. camera view/projection을 사용해 front/side/top 모두 같은 world-space 박스를 표시한다.
- 사용자 제공 경로 안의 새 하위 폴더에 이미지, 설명, 검사 결과를 보존한다. 물리 step은 0이다.

완료 기준: 박스 색면과 상한이 세 시점에서 뚜렷하고, 노란 root marker가 지정 reference 좌표에 표시되며, native body/DOF/guitar 상태 불변·source SHA·세 PNG를 검사한다.

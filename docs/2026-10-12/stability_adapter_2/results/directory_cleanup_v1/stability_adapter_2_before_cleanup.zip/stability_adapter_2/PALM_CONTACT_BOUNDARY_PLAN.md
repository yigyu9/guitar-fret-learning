# 손바닥 접촉 경계의 손·기타 응답

이전 소단계는 진행이다. 자유 기타 유지·지속 손바닥 지지는 미달성이다.
기존 유한시간 응답의12개 작은probe에서는기타state가모두기준과같았으나,
보정량1/2·전체에서는초기접촉과기타이탈이함께커졌다. 이번에는이경계를측정한다.
평행은soft선호이며실제넥지지와기타초기p/q유지가우선이다.

## 불변 조건

초기 q·기타 p/q·LA1.1018469719600776m·PD·몸통9/오른팔/손가락 목표·root/하체
물리고정·self collision ON을 유지한다. 기존startupbias+alpha×저장delta의상수PD목표다.
Leftarm12 최종 initial±.3rad∩native/66합성은그대로다. 기타free·중력·수동strap이며
고정/손부착/상태덮어쓰기/인위적기타힘은없다. source면간격/법선과raw lambda는
cooked clearance·지지력인증이아니다. 이번alpha는초기각/스트랩을바꾸는입력이아니다.

- [x] 1. 이전phase의코드/원자료/inventory를읽기전SHA봉인하고보존한다. alpha
  .30/.35/.40/.45를새trial JSON으로생성한다. 이전1/4·1/2는저장자료로대조하며재실행하지않는다.
- [x] 2. 동결된 run_palm_finite_response.py를그대로재사용해각24step(.1초) 실행한다.
  새physics code없음, 계획4init/96steps다. 실제float32 PD목표·손/기타state/contact/trace를저장한다.
- [x] 3. 손point/source법선gap/실제접촉·양의rawlambda의시점과기타p/q오차를함께읽는다.
  전체traj의world기타위치변위3+초기방향대비rotation-vector3도저장한다. 접촉전/후에
  같은보정방향의응답이달라지는지측정한다. 작은면각만으로채택하지않는다.
- [x] 4. 접촉경계가확인되면그주변의12축작은목표probe와독립heldout을다음소단계로
  계획한다. 기타응답이있다면손task만줄이는fit대신기타p/q악화도동시에검사한다.
  식별전에새feedback/PDgain/strap/finger/후기시간을추가하지않는다.
- [x] 5. 확정된raw분석으로Luna의곡선·설명문서를만들고독립검수한다. 코드/계획/설정은
  stability_adapter_2, 결과/로그/그림은docs/2026-10-12/stability_adapter_2/results/palm_contact_boundary_v1다.

접촉이생기는경계는이번초기상태·PD·alpha방향·이산샘플에서의관측이다.
유일한임계값/장기안정성/연주성공을주장하지않는다. 양의rawlambda가생겨도기타를
밀어내는지함께읽고, 지속유지와연주에서의보정검증까지목표를유지한다.

## 측정 결과

4init/96steps, 여섯 조건 분석 계약7개 통과. 양의 palm raw lambda 관측은
alpha .40과 .45 사이에서 바뀌며 .45도 step2 두 행뿐이다. 지속지지는 아니다.
기타 최대 오차가 .40의5.048mm/.967°에서 .45의5.341mm/1.006°로 커졌다.
유일한 접촉 임계값이나 최종 bias로 해석하지 않는다.
다음은 [손·기타 응답 식별](PALM_COUPLED_RESPONSE_PLAN.md)이며 별도 .45 주변12축을 측정한다.

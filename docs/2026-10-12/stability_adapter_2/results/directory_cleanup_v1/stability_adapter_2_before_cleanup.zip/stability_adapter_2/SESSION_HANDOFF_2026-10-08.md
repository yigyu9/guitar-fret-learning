# 작업 마무리와 재개 시 방향 결정

사용자 요청으로 반복 실험을 여기서 중단한다. 이 문서는 재개를 위한 인계이며 새 실험 실행 지시가 아니다. 기존 startup slow/fast 계획도 보류한다. 사용자가 재개를 요청하기 전에는 방향을 논의하거나 선정하더라도 새 trial을 실행하지 않는다.

## 현재까지 확인한 것

자유 기타·고정 root/하체·원 스트랩 길이에서 5초 경과를 기록했고, 손목 Y/Z의 실제 관절 목표를 바꾸면 기타 자세에 작게 영향을 줄 수 있음을 확인했다. 현재 기타 world 위치·회전 오차를 읽어 PD 목표 보정으로 연결하는 OFF/ON 비교도 완료했다. 기타 고정·강제 손 부착·시작 후 상태 덮어쓰기는 사용하지 않았다.

| 같은 초기 자세의 비교 | 5초 위치 오차 (mm) | 5초 회전 오차 (°) | 후기 완전1초 최대 변화 (mm / °) |
|---|---:|---:|---:|
| 기준 / feedback OFF | 13.819696 | 2.918277 | 0.648625 / 0.115306 |
| 현재 오차 feedback ON | 13.665215 | 2.889313 | 0.693968 / 0.124492 |
| 스트랩 힘 OFF | 20.525764 | 12.145216 | 0.335897 / 0.064720 |

수치 출처는 [feedback 분석](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/quiet_wrist_yz_feedback_v1/analysis.json:1)과 [no-strap 분석](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/no_strap_current_pose_v1/analysis.json:1)이다. 초기 목표 대비 이탈과 후기 움직임을 구분한다. No-strap의 후기 변화가 작아도 초기 방향에서 약12° 벗어난 새 자세다. 현재 ON의 두 종료 오차 개선은 작고 후기 변화는 조금 늘었다. 다른 손목 후보까지 포함하면 유리한 조건은 지표마다 다르므로 단일 최종 자세나 제어기를 선정하지 않는다.

## 고정한 비교 조건과 재현 자료

- humanoid root와 하체는 별도 fixed-lower 모델로 고정한다. body9(Torso/Spine/Chest)의 초기 PD 목표를 유지하며 KP×2/KD×√2를 사용한다. 실제 몸통 관절 움직임은 별도로 관측한다.
- 주요 제어권은 양쪽 Thorax부터 손가락까지66관절이다. 이번 feedback만 왼손목 Y/Z 두 축에 제한했고, 다른 관절의 연주 제어권을 제거하지 않았다.
- 절대 strap rest length는 원본 환경 기준 `1.1018469719600776 m`로 유지한다. No-strap은 힘과 표시를 끈 별도 비교이며 본선 길이 변경이 아니다.
- [기준 trial 입력](/home/ajou/yigyu/3/stability_adapter_2/trials/initial_middle3_alignment_v1/middle3_initial_at_goal.json:1), [기준 실제 초기값과 유지목표](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/initial_middle3_alignment_v1/native/initial_values.json:1), [현재 ON 초기값](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/quiet_wrist_yz_feedback_v1/native/on/initial_values.json:1)을 보존한다.
- [현재 feedback 구현](/home/ajou/yigyu/3/stability_adapter_2/wrist_yz_guitar_feedback.py:13)은 world p/q 오차에서60Hz로 두 목표 보정각을 계산한다. 이번 시험에서는2초 뒤 활성화, 각 축±.005rad·.002rad/s 제한이다. 원 손목 X 작은 사인 움직임과 손가락 목표를 유지했다.
- 최신 phase는 [56개 저장 검사](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/quiet_wrist_yz_feedback_v1/analysis.json:1), [25개 최종 보존 감사](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/quiet_wrist_yz_feedback_v1/final_verification.json:1), [독립 검수](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/quiet_wrist_yz_feedback_v1/review.md:1)와 함께 봉인했다. 마무리 시1618개 inventory 파일의 크기/SHA를 다시 확인했다.

기존 source·leaf 계획·원자료·영상·실패 기록을 수정하지 않는다. 기존 phase runner는 완료한 경로를 다시 실행하려 하면 거절한다. 재개 시에는 선택한 방향에 맞춰 새 phase와 실행 기록을 만들고 재사용 helper의 SHA를 확인한다. 이 문서 정리 중에는 새 native 실행·학습·영상 재인코딩을 하지 않는다.

## 아직 해결하거나 결정하지 않은 것

1. 현재 수치는 동일한 시작 자세와 작은 손목 움직임의5초 결과다. 자연스러운 연주나 fret/strike checkpoint 성능을 검증한 결과가 아니다. 정식 허용 위치·회전·유지시간·자연스러움 기준은 확정하지 않았다.
2. 왼손바닥의 양의 raw lambda 접촉은 아직0이며, 손가락 접촉은 관측됐다. 접촉 행이나 source 형상 검사만으로 cooked 형상의 동적 침투 없음·완전한 지지력을 인증하지 않는다.
3. body9 목표는 유지됐지만 실제 Spine_z 관절좌표 변화는 약.06176rad였다. 이는 몸통 전체 world 회전각이 아니다. 실제 native 관절 한계의 약.0001rad 초과도 관측값으로 남아 있다.
4. source 정책의 목표 범위·이전 목표/history와 현재 유지 자세는 자동 호환되지 않는다. [기존 source 범위 조사](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/fixed_strap_source_compatibility_v1/README.md:1)를 재사용하되, 학습 동작 분포·action 표현 범위·native 한계를 서로 구분해야 한다. 기존 loader/qualification을 우회한 실행은 하지 않았다.
5. 영상 수집 wrapper의 metadata 인자 오류는 원본과 함께 보존했다. 실제 영상170개와 색인은 [별도 회수 감사](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/quiet_wrist_yz_feedback_v1/collection_recovery.json:1)로 확인했으며, 미기록 collector 종료코드와 실행시간은 미확인으로 남긴다.

## 재개 시 권장 순서 — 아직 실행하지 않음

**권장 방향은 정지 상태의 미세 오차 탐색을 잠시 접고, 현재 후보를 연주 가능한 시작점으로 쓸 수 있는지 확인하는 것이다.** 아래는 다음 논의를 위한 제안이며 확정된 새 실험이 아니다.

| 순서 | 결정하거나 확인할 내용 | 다음 단계로 가져갈 산출물 |
|---|---|---|
| 1 | 기존 손·전신 영상에서 기타 기울기, 양손 자세, 넥/현 접근 여유와 손가락의 자연스러움을 사용자와 검토한다. 미세 떨림을 허용한다는 기존 선호를 반영한다. | 우선 사용할 기준 후보와 시각적 허용 조건 |
| 2 | fret/strike 체크포인트의 현재 기타 frame 관측, 관절 목표 생성, 이전 목표/history를 현재 hold와 어떻게 연결할지 설계한다. 연주 목표와 안정화 보정의 제어권을 한 최종 PD 목표에서 조정한다. | 실제 코드·입출력에 근거한 전환 설계와 학습 필요 항목 |
| 3 | 선택한 전환을 새5초 trial에서 검증한다. 가능한 범위에서 같은 연주 목표의 안정화 OFF/ON을 비교하고 기타 오차와 fret/strike 수행 오차를 함께 측정한다. | 초기값·실제 영상·접촉·연주 및 안정화 지표 |
| 4 | 기존 정책을 그대로 쓸 때 남는 오차를 확인한 뒤, source 정책 고정+추가 보정 학습과 일부 fine-tuning 중 필요한 구조를 정한다. | 보정 권한·관측·보상·학습 범위의 구체적 계획 |

[시작부터 feedback slow/fast를 비교하는 기존 계획](/home/ajou/yigyu/3/stability_adapter_2/QUIET_WRIST_YZ_STARTUP_FEEDBACK_PLAN.md:1)은 초기 흔들림 자체가 영상상 문제일 때 선택할 수 있는 대안이다. 아직 구현·실행하지 않았고 자동으로 이어가지 않는다. No-strap을 본선으로 전환하는 것도 이번 정리에서 결정하지 않는다. WAIT→REACH→GRIP→TRANSPORT를 연주의 필수 선행 단계로 추가하지 않는다.

## 마무리 체크리스트

- [x] 새 실험을 시작하지 않고 실행 중인 stability_adapter_2 module process가 없음을 확인
- [x] 최신 feedback/Z/no-strap 봉인 자료와 영상170개 보존 상태 확인
- [x] 현재 구현·한계·재개 대안과 권장 순서를 이 문서에 기록
- [x] 결과 요약 문서·main README/PLAN에 중단 상태와 링크 추가
- 독립 검수와 시스템 중단 상태는 [마무리 기록](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/session_wrap_up_2026-10-08_v1/review.md:1) 및 마지막 도구 반환 상태로 확인한다.

[결과·영상 요약](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/SESSION_WRAP_UP_2026-10-08.md:1)과 [실행 상태/보존 확인](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/session_wrap_up_2026-10-08_v1/status_check.json:1)을 함께 읽는다.

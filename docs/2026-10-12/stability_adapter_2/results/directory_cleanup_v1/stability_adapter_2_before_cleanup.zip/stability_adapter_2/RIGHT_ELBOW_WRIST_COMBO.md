# 개선된 손목 자세와 팔꿈치 X 초기각 조합

2026-10-06. 현재 wrist 기준 주변의 세분화는1초 이탈을 줄이지 못했다.
기준 R_Wrist_x=−0.42467687010765076rad와 LA1.1010801317960974m를 유지하고
R_Elbow_x=−0.14782950282096863rad에서−0.0025/−0.005rad를 추가한다.
이전 elbow X음수 시험은다른 wrist와0.1/0.5초뿐이어서 새 조합을 직접 검사한다.

- [x] 1. 기존 기준 입력을 byte-copy하고 elbow X만 바꾼2후보를 만든다.
  기존 audit_arm_initial_inputs.py로 C02±0.3rad∩모델·기타초기p/q/목표·다른
  초기각·PD·route/LA·noSteps·source 음수pair0/LH 위쪽 반구/국소 넥 아래를 fresh 검사한다.
- [x] 2. 통과조건과 기준의0.1초 기존 PI ON을 비교한다. 새 어깨 접촉이 없는
  조건은0.5/1초 ON으로 직접 비교한다. source 거절 조건은 실행하지 않는다.
- [x] 3. 1초 최대 위치·회전이 모두 기준보다 작은 조합만 OFF0.1/0.5/1초를
  비교한다(최대2조건). 개선 없으면 기준각/LA를 유지한다. 기존 compare_arm_initial_trials.py
  및 새 read-only 참조symlink(group/on→negative_pose_late_v1/group/wrist_minus0050)를
  재사용해 기준raw5/prefix/PI/명령coverage/명시SHA를 검증한다.
- [x] 4. Luna가 표·저장trace·설명을 누적30절에 추가하고 별도 검수를 받는다.
  실제 경로/줄·설정/실행로그/원자료/보존본/검증을 남긴다.

기타 자유/+5mm 목표p/q, humanoid root 고정, 몸통9·손가락42·C02하체 초기 목표,
주요66 연결·팔24 PI±0.15rad/60Hz·기존PD/gain/solver를 유지한다.
고정·강제부착·runtime pose 덮어쓰기·동적strap·새 gate/제어/학습은 없다.
source query는 cooked PhysX clearance/지지 인증이 아니다. 실제각·접촉·속도·포화를 측정한다.
기타 p/q feedback은 사용자 확인 전이며 현재 관절 목표 유지 보정과 구별한다.

입력: stability_adapter_2/trials/right_elbow_wrist_combo_v1.
결과: docs/2026-10-12/stability_adapter_2/results/right_elbow_wrist_combo_v1.

## 실행 결과와 다음 방향

초기3입력은 모두 기존 source/LH 조건을 통과했다. 전체105개 중다른104개 native
초기각은 같았고 elbow X만−0.002499998/−0.004999995rad 달랐다. RH unsigned source
hull 간격은 기준2.313745mm에서2.747716/3.180791mm였다.
0.1/0.5/1초 ON9회를 완료했다. 1초 최대 위치·회전은기준73.660431mm/13.502121°,
−0.0025rad119.343878mm/28.970036°,−0.005rad119.009665mm/28.632557°였다.
개선 조합이 없어 OFF를 추가하지 않고 기존각/LA를 유지한다.

모든1초 보정은212physics samples에서 포화됐고 LH/어깨contact0이다.
RH thumb3 행/unique samples는 기준221/78,두후보134/54·125/42,
마지막 관측step163/141/142다. 관측수·끝점은 힘·깊이·인과·연속 지지 인증이 아니다.
큰 종료 속도·drift가 남아 안정·연주 성공이 아니다.
원본 참조 연결과 기준raw5/기간prefix는 exact,명시138입력SHA는 현재와 일치한다.

오른쪽 distal의 더 작은 세분화는 보류한다. 다음에는 오른팔/LA를 유지하고
L_Elbow_x/y와 L_Wrist_x/y 한축씩±0.025rad 초기 조건을 C02±0.3rad∩모델 안에서
fresh source로 검사한다. 양손 지지를 검토하며 기존 source/LH 조건과팔24 PI,
기타 목표/몸통·손가락·하체 목표/PD/solver를 바꾸지 않는다. 새 제어/학습은 확인 전이다.

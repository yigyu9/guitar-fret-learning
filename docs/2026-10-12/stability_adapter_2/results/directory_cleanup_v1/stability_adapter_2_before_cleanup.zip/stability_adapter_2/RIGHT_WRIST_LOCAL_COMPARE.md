# 현재 손목 X 기준각 주변의 중간 조건 비교

2026-10-06. 기준 R_Wrist_x=−0.42467687010765076rad의 이전 이웃각은1초에
더 큰 기타 이탈을 보였다. 이웃 사이±0.00125rad만 비교하고 개선이 없으면
X축의 추가 미세 세분화는 보류해 다른 팔 초기각 조합을 검토한다.

- [x] 1. 기존 기준 입력을 byte-copy하고 wrist X±0.00125rad 입력을 만든다.
  기존 audit_arm_initial_inputs.py로 C02±0.3rad∩모델·기타초기p/q/목표·다른
  초기각·PD·route/LA·noSteps와 fresh source 음수pair0/LH 위쪽 반구/국소 넥 아래를 검사한다.
- [x] 2. 통과한 조건과 기준의0.1초 기존 PI ON을 비교한다. 새 어깨 접촉이
  없는 조건은0.5/1초 ON으로 직접 비교한다. 단기 순위로 후기 성능을 추정하지 않는다.
- [x] 3. 1초 최대 위치·회전이 모두 기준보다 작은 후보만 OFF 0.1/0.5/1초
  비교한다(최대2조건). 기존 compare_arm_initial_trials.py와 새 read-only 참조
  symlink(group/on→negative_pose_late_v1/group/wrist_minus0050)를 재사용한다.
  원본 입력·원자료·도구를 수정하지 않고 기준raw5/prefix/PI/SHA/명령coverage를 검증한다.
- [x] 4. Luna가 표·저장trace·설명을 누적29절에 추가하고 별도 검수를 받는다.
  실제 파일 경로·줄, 설정/실행로그/원자료/보존본/검증을 남긴다.

LA1.1010801317960974m, 기타 자유/+5mm 목표p/q, humanoid root 고정,
Torso/Spine/Chest9·손가락42·C02하체 초기 목표·주요66 연결·팔24 PI±0.15rad/60Hz,
기존PD/gain/solver를 유지한다. 고정·강제부착·runtime pose 덮어쓰기·동적strap·
새 gate/제어/학습은 추가하지 않는다. source query는 PhysX cooked clearance/지지 인증이 아니다.
기타 p/q feedback은 아직 사용자 확인 전이며 관절 목표 유지 보정과 구별한다.

입력: stability_adapter_2/trials/right_wrist_local_v1.
결과: docs/2026-10-12/stability_adapter_2/results/right_wrist_local_v1.

## 실행 결과와 다음 방향

초기3입력은 모두 기존 source/LH 조건을 통과했다. 전체105개 중 다른104개의
native 초기각은 같았고 wrist X만±0.001249999rad 달랐다. unsigned RH source
hull 간격은 기준2.313745mm, 음수2.328165mm, 양수2.299420mm였다.
기준과 후보의0.1/0.5/1초 ON9회를 완료했다. 1초 최대 위치/회전은
기준73.660431mm/13.502121°, 음수117.748239mm/28.362203°,
양수119.007568mm/29.302065°였다. 양수는0.5초35.351546mm/4.948202°로
기준보다 작았지만1초에는 악화됐다. 새 OFF는 실행하지 않고 기존각/LA를 유지한다.

모든1초 보정은212physics samples에서 포화됐고 LH/어깨contact0이다.
RH thumb3 행/unique samples는기준221/78,음수143/53,양수141/55,
마지막 관측step163/143/139다. 관측수·끝점은 힘·깊이·인과·연속 지지 인증이 아니다.
큰 종료 속도·drift가 남아 안정·연주 성공이 아니다.
기준 raw5/기간prefix는 exact, 명시138입력SHA는 현재와 일치한다.
기존 코드·공용 자산·원자료와 read-only 원본 참조 연결을 보존한다.

계획대로 wrist X의 추가 미세 세분화는 보류한다. 다음에는 같은 기준 손목각/LA에서
R_Elbow_x 초기각−0.0025/−0.005rad 조합을 C02±0.3rad∩모델 안에서 fresh source부터
검사한다. 이전 팔꿈치 시험은 다른 손목각이었으며 X음수의1초 성능은 미측정이었다.
이전 clearance/후기 결과를 새 조합에 승계하지 않는다. 새 제어/학습은 확인 전이다.

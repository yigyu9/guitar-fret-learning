#!/usr/bin/env python3
"""Plot saved palm support-weight comparison traces; performs no simulation."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np


ROOT = Path('/home/ajou/yigyu/3')
PHASE = ROOT / 'docs/2026-10-12/stability_adapter_2/results/palm_support_weight_v1'
CONDITIONS = (
    ('scale_0p08', '0.08 m/rad', '#1878b8'),
    ('scale_0p02', '0.02 m/rad', '#e07a24'),
    ('scale_0', '0 m/rad', '#666666'),
)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out-dir', type=Path, required=True)
    args = parser.parse_args()
    out = args.out_dir.resolve()
    if out.exists():
        raise FileExistsError(f'output directory already exists: {out}')
    analysis_path = PHASE / 'analysis.json'
    analysis = read(analysis_path)
    if len(analysis.get('checks', {})) != 6 or not all(analysis['checks'].values()):
        raise ValueError('expected six passing saved-data checks')
    if analysis.get('counts') != {'native_initializations': 3, 'physics_steps': 72}:
        raise ValueError('unexpected native-run accounting')
    out.mkdir(parents=True)
    font = Path('/usr/share/fonts/truetype/nanum/NanumGothic.ttf')
    if font.exists():
        plt.rcParams['font.family'] = font_manager.FontProperties(fname=font).get_name()
    plt.rcParams['axes.unicode_minus'] = False
    fig, axes = plt.subplots(2, 2, figsize=(13, 8))
    inputs = {str(analysis_path.resolve()): sha(analysis_path),
              str(Path(__file__).resolve()): sha(__file__)}
    summaries = {row['label']: row for row in analysis['summary']}
    series = {}
    for folder, label, color in CONDITIONS:
        run = PHASE / folder
        trace_path, tasks_path = run/'trace.json', run/'normal_tasks.json'
        contacts_path, report_path = run/'contacts.json', run/'report.json'
        trace, tasks = read(trace_path), read(tasks_path)
        contacts, report = read(contacts_path), read(report_path)
        if len(trace) != 25 or len(tasks) != 25 or len(contacts) != 24:
            raise ValueError(f'{folder}: expected 25 saved samples and 24 contact records')
        if not all(report['checks'].values()):
            raise ValueError(f'{folder}: report contract check failed')
        times = np.asarray([row['time_s'] for row in trace], dtype=float)
        task = np.asarray(tasks, dtype=float)
        p_error = np.asarray([row['position_error_m'] for row in trace], dtype=float)*1000
        q_error = np.asarray([row['rotation_error_deg'] for row in trace], dtype=float)
        if task.shape != (25, 6) or not np.isfinite(task).all():
            raise ValueError(f'{folder}: task samples must be finite 25x6')
        if not (np.isfinite(times).all() and np.isfinite(p_error).all() and np.isfinite(q_error).all()):
            raise ValueError(f'{folder}: nonfinite plotted trace value')
        if times[0] != 0 or abs(times[-1]-.1)>1e-12 or np.any(np.diff(times)<=0):
            raise ValueError(f'{folder}: unexpected time coverage')
        point = np.linalg.norm(task[:, :3], axis=1)*1000
        # Keep the documented orientation scale for every condition, including scale_0.
        angle = np.rad2deg(np.linalg.norm(task[:, 3:], axis=1)/.08)
        series[folder] = (times, point, angle, p_error, q_error, label, color)
        summary = summaries[folder]
        if abs(float(np.max(point))-summary['max_point_error_mm']) > 1e-8:
            raise ValueError(f'{folder}: plotted point maximum disagrees with analysis summary')
        if abs(float(np.max(angle))-summary['max_normal_angle_deg']) > 1e-8:
            raise ValueError(f'{folder}: plotted angle maximum disagrees with analysis summary')
        for path in (trace_path, tasks_path, contacts_path, report_path):
            inputs[str(path.resolve())] = sha(path)
    panel_values = (
        ('손 추적점 오차 크기 (mm)', 1),
        ('source 법선 대향각 (°)', 2),
        ('기타 위치 오차 크기 (mm)', 3),
        ('기타 회전 오차 (°)', 4),
    )
    for ax, (title, column) in zip(axes.flat, panel_values):
        for folder, _, _ in CONDITIONS:
            t, point, angle, p_error, q_error, label, color = series[folder]
            values = (None, point, angle, p_error, q_error)[column]
            ax.plot(t, values, color=color, marker='o', ms=2.5, lw=1.7, label=label)
        ax.set_title(title)
        ax.set_xlabel('저장 시각 (s)')
        ax.set_xlim(0, .1)
        ax.grid(True, alpha=.25)
        ax.legend()
    fig.suptitle('Palm support-weight 비교 — 저장 trace', y=1.01)
    fig.tight_layout()
    image = out/'palm_support_weight.png'
    fig.savefig(image, dpi=160, bbox_inches='tight')
    plt.close(fig)
    manifest = {
        'producer': str(Path(__file__).resolve()),
        'producer_sha256': sha(__file__),
        'inputs_sha256': inputs,
        'outputs_sha256': {image.name: sha(image)},
        'scope': 'Saved trace/tasks/reports/contacts only; no native initialization or physics step.'
    }
    (out/'plot_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps({'image': str(image), 'manifest': str(out/'plot_manifest.json')}))


if __name__ == '__main__':
    main()

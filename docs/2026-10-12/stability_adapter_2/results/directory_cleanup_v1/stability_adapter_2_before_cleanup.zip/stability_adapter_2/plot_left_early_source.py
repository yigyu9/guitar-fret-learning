#!/usr/bin/env python3
"""Plot saved early-left-palm source measurements; performs no native query."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d.art3d import Poly3DCollection


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_inputs(results: Path):
    analysis_path = results / "measurements" / "analysis.json"
    geometry_path = results / "measurements" / "geometry.json"
    analysis = json.loads(analysis_path.read_text())
    geometry = json.loads(geometry_path.read_text())
    checks = analysis.get("checks", {})
    expected = {"seven_saved_frames", "source_hull_solves_feasible",
                "palm_normal_proxies_valid", "consumed_sources_unchanged"}
    if set(checks) != expected or not all(checks.values()):
        raise ValueError("analysis checks must all pass with the expected contract")
    embedded = analysis.get("input_sha256", {})
    if len(embedded) != 68:
        raise ValueError("expected 68 embedded source hashes")
    for name, digest in embedded.items():
        path = Path(name)
        if not path.is_file() or sha256(path) != digest:
            raise ValueError(f"source SHA mismatch: {path}")
    rows = analysis.get("rows", [])
    steps = [0, 1, 2, 4, 8, 12, 24]
    if [r["physics_step"] for r in rows] != steps:
        raise ValueError("expected saved measurement steps 0,1,2,4,8,12,24")
    snapshots = geometry.get("snapshots", [])
    if [s["physics_step"] for s in snapshots] != [0, 24]:
        raise ValueError("expected source-geometry snapshots at steps 0 and 24")
    return analysis_path, geometry_path, analysis, geometry


def plot_measurements(rows, output: Path):
    times = np.asarray([r["time_s"] for r in rows])
    hull_mm = np.asarray([r["palm_neck"]["source_hull_distance_m"] * 1000 for r in rows])
    signed_mm = np.asarray([r["palm_neck"]["backend_signed_gap_20mm_cutoff_m"] * 1000 for r in rows])
    up = np.asarray([r["hand"]["palm_up_dot"] for r in rows])
    height_mm = np.asarray([r["hand"]["palm_height_vs_local_lower_m"] * 1000 for r in rows])
    fig, axes = plt.subplots(2, 2, figsize=(11.5, 7.6))
    axes[0, 0].plot(times, hull_mm, "o-", color="#2563a6", lw=1.8)
    axes[0, 0].set(title="Unsigned source-hull distance", ylabel="Distance (mm)")
    axes[0, 1].plot(times[:-1], signed_mm[:-1], "o-", color="#d97706", lw=1.8,
                    label="Backend signed query")
    axes[0, 1].scatter(times[-1], signed_mm[-1], marker="^", s=65, color="#b91c1c",
                       label="20 mm cutoff (reported as 20 mm)")
    axes[0, 1].set(title="Separate backend signed query", ylabel="Reported gap (mm)")
    axes[0, 1].legend(frameon=False, fontsize=8)
    axes[1, 0].plot(times, up, "o-", color="#16a34a", lw=1.8)
    axes[1, 0].set(title="Palm-normal proxy", ylabel="World Z component (unitless)", ylim=(0.90, 0.99))
    axes[1, 1].plot(times, height_mm, "o-", color="#7c3aed", lw=1.8)
    axes[1, 1].axhline(0, color="#555", lw=.8)
    axes[1, 1].set(title="Palm center vs local neck lower section", ylabel="Relative height (mm)")
    for ax in axes.flat:
        ax.set_xlabel("Saved time (s)")
        ax.grid(True, alpha=.24)
    fig.suptitle("Saved early left-palm measurements — discrete samples", y=.99)
    fig.text(.5, .012,
             "Unsigned hull distance and cutoff signed query are different proxies; neither certifies cooked clearance, contact, or support.",
             ha="center", fontsize=8.5)
    fig.tight_layout(rect=(0, .04, 1, .96), h_pad=2.1, w_pad=1.8)
    fig.savefig(output, dpi=170, bbox_inches="tight")
    plt.close(fig)


def plot_geometry(snapshots, rows, output: Path):
    colors = {"guitar": "#2563eb", "left": "#16a34a", "gray": "#9ca3af"}
    selected = []
    for snap, row in zip(snapshots, (rows[0], rows[-1])):
        shapes = []
        for shape in snap["shapes"]:
            actor, body = shape["actor"], shape["body"]
            if actor == "guitar":
                color, alpha = colors["guitar"], .78
            elif actor == "human" and body.startswith("LH:"):
                color, alpha = colors["left"], .72
            elif actor == "human" and body in ("L_Elbow", "L_Wrist"):
                color, alpha = colors["gray"], .30
            else:
                continue
            triangles = np.asarray(shape["triangles_world_m"], dtype=float)
            shapes.append((triangles, color, alpha))
        witness = np.asarray(row["palm_neck"]["hull_witness_points_m"], dtype=float)
        hand = row["hand"]
        center = np.asarray(hand["palm_center_world_m"], dtype=float)
        normal = np.asarray(hand["palm_normal_world"], dtype=float)
        selected.append((snap["physics_step"], shapes, witness, center, normal, row))
    # Keep both panels at a shared close-up around the neck/hand witnesses;
    # the full guitar body would hide the sub-millimeter initial segment.
    points = np.concatenate([entry[2] for entry in selected] +
                            [entry[3][None, :] for entry in selected])
    center = (points.min(0) + points.max(0)) / 2
    half = .16
    fig = plt.figure(figsize=(12.5, 5.8))
    for i, (step, shapes, witness, palm, normal, row) in enumerate(selected, 1):
        ax = fig.add_subplot(1, 2, i, projection="3d")
        ax.computed_zorder = False
        for triangles, color, alpha in shapes:
            ax.add_collection3d(Poly3DCollection(triangles, facecolors=color,
                                                 edgecolors="none", alpha=alpha, zorder=1))
        ax.plot(*witness.T, color="#f97316", lw=3.2, marker="o", ms=5,
                markeredgecolor="white", markeredgewidth=.7, zorder=20)
        ax.scatter(*palm, color=colors["left"], s=22, depthshade=False, zorder=21)
        ax.quiver(*palm, *(normal * .06), color="#f59e0b", linewidth=2,
                  arrow_length_ratio=.22, zorder=21)
        ax.set(xlim=(center[0]-half, center[0]+half), ylim=(center[1]-half, center[1]+half),
               zlim=(center[2]-half, center[2]+half), xlabel="World X (m)",
               ylabel="World Y (m)", zlabel="World Z (m)")
        ax.set_box_aspect((1, 1, 1))
        ax.view_init(elev=18, azim=115)
        ax.set_title(f"t={row['time_s']:.3f} s · step {step} · witness {row['palm_neck']['source_hull_distance_m']*1000:.3f} mm",
                     pad=2)
    fig.suptitle("Saved source triangles at native poses — CPU geometry reconstruction, not native renderer", y=.98)
    fig.text(.5, .012,
             "Blue: guitar | green: LH source shapes | gray: elbow/wrist | orange line/points: witness overlay (not depth/visibility evidence) | arrow: normal proxy (sign unverified).",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .045, 1, .94), w_pad=.5)
    fig.savefig(output, dpi=150, bbox_inches="tight")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-dir", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    out = args.out_dir.resolve()
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f"refusing to overwrite nonempty output directory: {out}")
    analysis_path, geometry_path, analysis, geometry = load_inputs(args.results_dir.resolve())
    out.mkdir(parents=True, exist_ok=True)
    curves = out / "left_early_source_measurements.png"
    poses = out / "left_early_source_geometry.png"
    plot_measurements(analysis["rows"], curves)
    plot_geometry(geometry["snapshots"], analysis["rows"], poses)
    producer = Path(__file__).resolve()
    manifest = {
        "scope": "saved JSON plots only; no native run or geometry query",
        "inputs": {
            str(analysis_path): sha256(analysis_path),
            str(geometry_path): sha256(geometry_path),
            "embedded_source_hashes": analysis["input_sha256"],
        },
        "checks": analysis["checks"],
        "plotter": {"path": str(producer), "sha256": sha256(producer)},
        "outputs": {p.name: {"path": str(p), "sha256": sha256(p)} for p in (curves, poses)},
    }
    (out / "plot_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()

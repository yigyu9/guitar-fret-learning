# 같은 초기 설정의 3초 자유 기타 정지 진단

2026-10-07. left_wrist_strap_v1/load_00n 초기각과LA1.1010801317960974m를그대로쓴다.
1초최대73.268255mm/13.439339°·종료속도가남아후기동작을측정한다.
관측기간연장이며WAIT전제·성공기준·연주자세채택이아니다. 이전기록을덮어쓰지않는다.

- [x] 1. 입력byte-copy와이전검사/SHA를확인하고기존run_joint_hold로720 physics steps
  PI ON을실행한다. root고정·기타자유·같은목표/PD/solver/제어를유지한다.
- [x] 2. 새읽기전용compare_quiescent_run.py로기존1초 trace/states/contacts/controls/leg_torques prefix exact,
  모든721시점root·초기전체상태/targets·report계약·목표box/PI일정/LA고정·finite/현SHA검증.
  실제arm오차/limit·팔법선proxy·전체및1–3초p/q/속도·접촉행/sample/첫끝점·포화를집계한다.
  새성공판정·hardgate·새제어를만들지않는다.
- [x] 3. Luna가trace그래프와0/1/3초저장nativepose의source형상재구성이미지를만든다.
  기존geometry_snapshot를재사용하고동일world범위/카메라·시간·기타p/q·strap route표시.
  형상재구성은native renderer/cooked clearance/물리적지지인증이아니다.
  palm normal은native landmark proxy이며해부학적부호검증은없다.
- [x] 4. 코드문법/실제CLI·원자료·이미지/문서독립검수와보존본/검증/절대경로·줄을남긴다.
  산출물설명은누적34절에추가한다. 측정결과로다음실험을정하며수치성공을임의선언하지않는다.

주요Thorax이하66·팔24 PI±0.15rad/60Hz·C02±0.3∩모델·기존PD/gain/solver유지.
몸통9·손가락42·C02하체PD목표유지(실제상태고정아님). 기타+5mm초기p/q/목표와LA고정.
기타고정·강제부착·지속pose덮어쓰기·동적strap·기타p/q feedback·새controller/gate/학습없음.

입력: stability_adapter_2/trials/quiescent_3s_v1/reference.json.
결과: docs/2026-10-12/stability_adapter_2/results/quiescent_3s_v1.

## 실측 결과와 다음 검토

720 physics steps의 ON 실행이 정상 종료했고, 이전 1초의 trace/states/contacts/
controls/leg_torques 전체 prefix가 정확히 일치했다. 3초 내 최대 기타 오차는
251.150465mm/81.526863°, 종료 오차는236.386968mm/77.801738°였다.
종료 선속도0.012952304m/s·각속도0.038382001rad/s가 작아져도 초기 목표에서
크게 벗어난 자세이므로 안정성 성공으로 채택하지 않는다. 초기 기타 목표를 유지한다.
왼손 접촉은0이며 후기 Pelvis/R_Elbow 접촉이 관찰됐다. 접촉행은 힘·원인·
관통 깊이·연속 지지의 증거가 아니다. 팔 보정 포화는692/720 held physics samples다.

이번 결과로 초기각/길이의 미세 세분화만 반복하기보다 손의 작업공간 위치 유지와
관절 목표 보정의 관계를 먼저 검토한다. 기존 PALM_POSITION_RESIDUAL_PROPOSAL.md는
사용자 확인 전 제안이며 p08 기준을 쓰므로, 실제 적용 전 현재 기준으로 갱신하고
좌표계·Jacobian 검증 단계와 새 제어 비교를 구분해 확인한다. 이 실행에서 새 제어,
변화율 제한·gain·기타 p/q feedback·학습을 추가하지 않았다.

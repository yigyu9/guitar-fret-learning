"""Read native palm Jacobians and velocities during the unchanged approved PI run."""
import argparse
import ctypes
import hashlib
import json
from pathlib import Path

from .environment import InitialEnvironment, gymapi, np, vector
from .audit_palm_frames import pose
from .joint_hold_residual import JointHoldResidual
from .run_initialization import snapshot
from .run_physx_contacts import native_state
from .strap import rotate


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--settings', type=Path, required=True)
    parser.add_argument('--reference-run', type=Path, required=True)
    parser.add_argument('--frame-dir', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists() and any(args.out.iterdir()):
        raise FileExistsError('preserve previous runtime query')
    args.out.mkdir(parents=True, exist_ok=True)
    reference = read(args.reference_run / 'report.json')
    audit = read(args.frame_dir / 'audit.json')
    if not all(reference['checks'].values()) or not all(audit['checks'].values()):
        raise ValueError('reference diagnostic contracts failed')
    inputs = dict(reference['source_sha256'], **audit['input_sha256'])
    if not all(sha(p) == h for p, h in inputs.items()):
        raise ValueError('reference consumed-source SHA mismatch')
    paths = [args.settings, args.reference_run / 'report.json', args.frame_dir / 'audit.json',
        Path(__file__).resolve(), Path(__file__).with_name('audit_palm_frames.py'),
        Path(__file__).with_name('run_initialization.py'), Path(__file__).with_name('run_physx_contacts.py')]
    paths += [args.reference_run / (name + '.json') for name in ('states', 'trace', 'controls')]
    inputs.update({str(p.resolve()): sha(p) for p in paths})
    env = InitialEnvironment(read(args.settings))
    try:
        arm = np.array(reference['arm_indices'])
        other = np.array([i for i in range(len(env.names)) if i not in arm])
        low, high = np.array(reference['diagnostic_lower_rad']), np.array(reference['diagnostic_upper_rad'])
        controller = JointHoldResidual(env.initial_q[arm], low, high)
        props = env.gym.get_actor_dof_properties(env.env, env.human).copy()
        descriptor = env.gym.acquire_jacobian_tensor(env.sim, 'human')
        shape = (1, len(env.human_bodies) - 1, 6, len(env.names))
        if descriptor is None or descriptor.device != -1 or descriptor.dtype != gymapi.DTYPE_FLOAT32:
            raise ValueError('CPU float32 Jacobian descriptor required')
        if tuple(descriptor.shape) != shape or not descriptor.data_address:
            raise ValueError('fixed-root Jacobian layout or pointer differs')
        pointer = ctypes.cast(descriptor.data_address, ctypes.POINTER(ctypes.c_float))
        buffer = np.ctypeslib.as_array(pointer, shape=shape)
        rows = {side: env.human_bodies.index(prefix + ':palm') - 1 for side, prefix in (('L', 'LH'), ('R', 'RH'))}
        local_com = {}
        native_props = env.gym.get_actor_rigid_body_properties(env.env, env.human)
        for side, row in rows.items():
            com = native_props[row + 1].com
            local_com[side] = np.array([com.x, com.y, com.z])
        offsets = {s: np.array(audit['saved_points'][0]['palms'][s]['local_offset_m']) for s in rows}
        records, states, trace, controls = [], [], [], []
        contracts = True
        interval = env.config['physics_hz'] // env.config['control_hz']
        if env.config['physics_hz'] != 240 or interval != 4:
            raise ValueError('approved 240/60Hz timing differs')
        for step in range(25):
            before = native_state(env)
            target = env.target.copy()
            stale = {s: buffer[0, row].copy() for s, row in rows.items()}
            env.gym.refresh_jacobian_tensors(env.sim)
            refreshed = {s: buffer[0, row].copy() for s, row in rows.items()}
            unchanged = before == native_state(env) and np.array_equal(target, env.target) and np.array_equal(props, env.gym.get_actor_dof_properties(env.env, env.human))
            contracts &= bool(unchanged)
            qvel = np.array([d['vel'] for d in before['human_dof_states']])
            palms = {}
            for side, row in rows.items():
                body = before['human_body_states'][row + 1]
                origin, quat = pose(body)
                v, w = vector(body['vel']['linear']), vector(body['vel']['angular'])
                com = origin + rotate(quat, local_com[side])
                point = origin + rotate(quat, offsets[side])
                candidates = {}
                for label, jac in (('before_refresh', stale[side]), ('refreshed', refreshed[side])):
                    predicted = jac @ qvel
                    source = predicted[:3] + np.cross(predicted[3:], point - com)
                    actual_source = v + np.cross(w, point - com)
                    candidates[label] = {'predicted_COM_linear_mps': predicted[:3].tolist(),
                        'predicted_angular_rad_s': predicted[3:].tolist(),
                        'COM_linear_error_mps': float(np.linalg.norm(predicted[:3] - v)),
                        'angular_error_rad_s': float(np.linalg.norm(predicted[3:] - w)),
                        'source_center_error_mps': float(np.linalg.norm(source - actual_source)),
                        'body_velocity_as_origin_COM_error_mps': float(np.linalg.norm(predicted[:3] - (v + np.cross(w, com - origin))))}
                palms[side] = {'body': env.human_bodies[row + 1], 'row': row,
                    'body_origin_world_m': origin.tolist(), 'COM_world_m': com.tolist(),
                    'source_center_world_m': point.tolist(), 'native_linear_mps': v.tolist(),
                    'native_angular_rad_s': w.tolist(), 'before_refresh_J': stale[side].tolist(),
                    'refreshed_J': refreshed[side].tolist(),
                    'cache_change_max_abs': float(np.abs(refreshed[side] - stale[side]).max()),
                    'velocity_comparisons': candidates}
            records.append({'physics_step': env.steps, 'time_s': env.steps / 240,
                'reads_preserve_states_targets_PD': bool(unchanged), 'palms': palms})
            states.append(before)
            trace.append(snapshot(env))
            if step == 24:
                break
            updated = step % interval == 0
            if updated:
                actual = np.array([d['pos'] for d in before['human_dof_states']])
                command, record = controller.update(actual[arm], 1 / env.config['control_hz'])
                main_offsets = np.zeros(66, dtype=np.float32)
                for index, value in zip(arm, command - env.initial_q[arm]):
                    main_offsets[list(env.main_indices).index(index)] = value
                env.set_main_offsets(main_offsets)
            controls.append(dict(record, physics_step=step + 1, updated_before_step=updated,
                final_arm_targets_rad=env.target[arm].astype(float).tolist()))
            contracts &= bool(np.array_equal(env.target[other], env.initial_q[other]))
            env.step_physics()
        checks = {'queries_preserve_all_states_targets_PD': contracts,
            '25_samples_24_physics_steps': len(records) == 25 and env.steps == 24,
            'current_native_layout_and_initial_targets': env.names == reference['human_joint_names'] and env.initial_q.tolist() == reference['initial_joint_targets_rad'],
            'same_fixed_length_physics_and_guitar_goal': env.rest_length == reference['absolute_rest_length_m'] and env.physics_parameters == reference['physics_parameters'] and env.goal_position.tolist() == reference['guitar_goal_position_m'] and env.goal_quaternion.tolist() == reference['guitar_goal_quaternion_xyzw'],
            'states_prefix_exact': states == read(args.reference_run / 'states.json')[:25],
            'trace_prefix_exact': trace == read(args.reference_run / 'trace.json')[:25],
            'controls_prefix_exact': controls == read(args.reference_run / 'controls.json')[:24],
            'palm_J_finite_and_nonzero': all(np.isfinite(p['refreshed_J']).all() and np.abs(p['refreshed_J']).max() > 1e-12 for r in records for p in r['palms'].values()),
            'consumed_sources_unchanged': all(sha(p) == h for p, h in inputs.items())}
        maxima = {side: {label: {field: max(r['palms'][side]['velocity_comparisons'][label][field] for r in records)
            for field in ('COM_linear_error_mps', 'angular_error_rad_s', 'source_center_error_mps', 'body_velocity_as_origin_COM_error_mps')}
            for label in ('before_refresh', 'refreshed')} for side in rows}
        report = {'scope': 'same approved PI 0.1s native Jacobian/velocity read-only diagnostic; not position control or stability certificate',
            'checks': checks, 'max_velocity_errors': maxima, 'physics_steps': env.steps,
            'query_semantics': 't=0 or completed simulate/fetch; copy acquired CPU buffer, refresh, copy again; no intervening simulate',
            'point_semantics': 'source convex-hull volume center, not a contact or anatomical point; native linear velocity COM interpretation tested against origin interpretation',
            'input_sha256': inputs}
        for name, value in (('report', report), ('queries', records), ('states', states), ('trace', trace), ('controls', controls)):
            (args.out / (name + '.json')).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
        print(json.dumps({'checks': checks, 'max_velocity_errors': maxima}, indent=2))
        if not all(checks.values()):
            raise SystemExit(1)
    finally:
        env.close()


if __name__ == '__main__':
    main()

"""Saved-data CPU audit of necessary source/native/action-range compatibility."""
from pathlib import Path
import hashlib
import json
import math
import sys

import torch

from tab2body.full.postprocessing import _mjcf_control_limits, _apply_fret_hard_limit_profile
from tab2body.full.source_policies import inspect_source_checkpoint_metadata
from tab2body.learning.checkpoint_contract import validate_contract_document
from .playing_target_bridge import PlayingTargetBridge

R = Path(__file__).resolve().parents[1]
A = R / 'stability_adapter_2'
B = R / 'docs/2026-10-12/stability_adapter_2/results'
P = B / 'fixed_strap_source_compatibility_v1'
RUNS = {'held_only': B / 'fixed_strap_middle_relax_v2/native',
        'initial_aligned': B / 'initial_middle3_alignment_v1/native'}
CHECKPOINTS = {
    'fret': R / 'fret/training/runs/20260929_1405_02_Jazz1-200-B_solo/checkpoints/fret_047000.pt',
    'strike': R / 'strike/training/runs/20260920_Jazz1_sync_baseline/checkpoints/strike_010000.pt',
}
CONTRACT = B / 'playing_target_bridge_v1/contract.json'
MJCF = R / 'tab2body/assets/smpl_mpl_hands_body.xml'
PROFILE = R / 'tab2body/assets/fret_human_joint_profile.json'


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def input_paths():
    return [Path(__file__).resolve(), A / 'FIXED_STRAP_SOURCE_COMPATIBILITY_PLAN.md',
            A / 'INITIAL_MIDDLE3_ALIGNMENT_DECISION.md', CONTRACT,
            CONTRACT.parent / 'artifact_inventory.json', MJCF, PROFILE] + list(CHECKPOINTS.values()) + [
                folder / name for folder in RUNS.values()
                for name in ['initial_values.json', 'controls.jsonl', 'report.json']
            ] + [folder.parent / 'artifact_inventory.json' for folder in RUNS.values()]


def main(before):
    assert not (P / 'compatibility.json').exists()
    checks = {}

    def check(name, value):
        assert value, name
        checks[name] = True

    check('all_direct_inputs_in_frozen_closure', all(str(path) in before for path in input_paths()))
    imported = [Path(module.__file__).resolve() for module in list(sys.modules.values())
                if getattr(module, '__file__', None)]
    check('all_imported_project_sources_in_frozen_closure', all(str(path) in before for path in imported if R in path.parents and path.suffix == '.py'))
    legacy = read(CONTRACT)
    inputs = {label: read(folder / 'initial_values.json') for label, folder in RUNS.items()}
    commands = {label: [json.loads(line) for line in (folder / 'controls.jsonl').read_text().splitlines()]
                for label, folder in RUNS.items()}
    names = inputs['held_only']['human_joint_names']
    main_names = inputs['held_only']['main_control_joint_names']
    check('native81_main66_match_saved_bridge', names == legacy['native_names'] and main_names == legacy['main_names'])
    for path in [CONTRACT] + [folder / name for folder in RUNS.values() for name in ['initial_values.json', 'controls.jsonl', 'report.json']]:
        inventory = read(path.parent / 'artifact_inventory.json' if path == CONTRACT else path.parent.parent / 'artifact_inventory.json')
        check('sealed_input_' + str(len(checks)), inventory[str(path)]['sha256'] == before[str(path)] and inventory[str(path)]['size'] == path.stat().st_size)

    sources, source_metadata = {}, {}
    for task, path in CHECKPOINTS.items():
        checkpoint = torch.load(path, map_location='cpu', weights_only=True)
        document = validate_contract_document(checkpoint['checkpoint_contract'])
        qualification, execution = inspect_source_checkpoint_metadata(task, checkpoint, document)
        payload, control = document['payload'], document['payload']['control']
        _, lower, upper = _mjcf_control_limits(MJCF, control['controlled_dof_names'])
        fingerprint = payload['fingerprints']['asset']['manifest']
        check(task + '_authored_asset_fingerprint', next(v['sha256'] for v in fingerprint if v['path'] == 'assets/smpl_mpl_hands_body.xml') == before[str(MJCF)])
        if task == 'fret':
            check('fret_hard_profile_enabled_fingerprint', payload['config']['reward_safety']['human_hard_limits_enabled'] and payload['config']['reward_safety']['human_hard_limit_profile_sha256'] == before[str(PROFILE)])
            _, lower, upper = _apply_fret_hard_limit_profile(PROFILE, control['controlled_dof_names'], lower, upper)
        sources[task] = dict(names=control['controlled_dof_names'], lower=lower.float(), upper=upper.float(), scale=control['action_scale'], alpha=control['action_alpha'])
        old = next(row for row in legacy['sources'] if row['path'] == str(path))
        check(task + '_checkpoint_contract_and_qualification_unchanged', old['sha256'] == before[str(path)] and old['contract_sha256'] == document['sha256'] and old['strict_G0_qualification'] == qualification.to_document())
        source_metadata[task] = dict(checkpoint_path=str(path), checkpoint_sha256=before[str(path)], contract_sha256=document['sha256'], strict_G0_qualification=qualification.to_document(), execution_context=execution)
        del checkpoint

    rows, summaries = [], []
    for label, initial in inputs.items():
        check(label + '_fixed_LA_native_layout', initial['human_joint_names'] == names and initial['main_control_joint_names'] == main_names and initial['absolute_strap_rest_length_m'] == 1.1018469719600776 and initial['PD_properties'] == inputs['held_only']['PD_properties'])
        hold = torch.tensor(initial['preserved_absolute_targets_rad'], dtype=torch.float32)
        native_lo = torch.tensor(initial['PD_properties']['lower'], dtype=torch.float32)
        native_hi = torch.tensor(initial['PD_properties']['upper'], dtype=torch.float32)
        bridge = PlayingTargetBridge(names, main_names, hold, native_lo, native_hi, sources)
        ownership = {}
        for task, config in bridge.sources.items():
            saved = legacy['source_mapping'][task]
            check(label + '_' + task + '_mapping_exact', list(config['names']) == saved['names'] and config['idx'] == saved['native_indices'] and config['mid'].tolist() == saved['mid_rad'] and config['half'].tolist() == saved['half_rad'] and config['scale'] == saved['scale'])
            for local, index in enumerate(config['idx']):
                ownership[index] = (task, local)
        check(label + '_ownership60_Thorax6_held15', len(ownership) == 60 and len(bridge.main) == 66 and len(bridge.held) == 15)
        actual = torch.tensor([initial['actual_initial_angles_rad'][name] for name in names], dtype=torch.float32)
        check(label + '_actual_initial_matches_native_readback', actual.tolist() == [v['pos'] for v in initial['native_initial_state']['human_dof_states']])
        control = commands[label]
        check(label + '_complete1200_ordered_commands', len(control) == 1200 and [c['physics_step'] for c in control] == list(range(1, 1201)))
        targets = torch.tensor([c['final_target_rad'] for c in control], dtype=torch.float32)
        check(label + '_all_submitted_commands_native_bounds', bool((targets >= native_lo).all()) and bool((targets <= native_hi).all()))
        vectors = dict(actual_initial=actual, initial_PD=torch.tensor(initial['initial_PD_target_rad'], dtype=torch.float32), held=hold, command_min=targets.min(dim=0).values, command_max=targets.max(dim=0).values)
        counts = {}
        for kind, vector in vectors.items():
            normalized = bridge.source_history(vector[None])
            local_rows = []
            for j, name in enumerate(names):
                value, lower, upper = float(vector[j]), float(bridge.lower[j]), float(bridge.upper[j])
                nearest = min(upper, max(lower, value))
                task, local = ownership.get(j, (None, None))
                source = sources[task] if task else None
                record = dict(label=label, kind=kind, name=name, task=task, current_rad=value,
                              native_lower_rad=float(native_lo[j]), native_upper_rad=float(native_hi[j]),
                              source_lower_rad=float(source['lower'][local]) if source else None,
                              source_upper_rad=float(source['upper'][local]) if source else None,
                              effective_lower_rad=lower, effective_upper_rad=upper,
                              normalized_history=float(normalized[task][0, local]) if task else None,
                              outside_effective_range=not lower <= value <= upper,
                              nearest_reference_rad=nearest, signed_minimum_change_rad=nearest-value,
                              minimum_change_deg=math.degrees(abs(nearest-value)))
                local_rows.append(record)
            rows.extend(local_rows)
            counts[kind] = dict(outside_count=sum(row['outside_effective_range'] for row in local_rows),
                                outside_names=[row['name'] for row in local_rows if row['outside_effective_range']],
                                max_minimum_change_rad=max(abs(row['signed_minimum_change_rad']) for row in local_rows))
        rejected, reason = False, None
        try:
            bridge.compose({task: torch.zeros(1, 30) for task in sources}, torch.zeros(1, 66), hold[None], torch.zeros(66))
        except ValueError as exc:
            rejected, reason = True, str(exc)
        check(label + '_warmstart_rejection_matches_range', rejected == (counts['held']['outside_count'] > 0))
        summaries.append(dict(label=label, ranges=counts, warmstart_rejected=rejected, rejection_reason=reason))
    check('both_conditions_same1200_absolute_commands', all(a['final_target_rad'] == b['final_target_rad'] and a['command_time_s'] == b['command_time_s'] for a, b in zip(commands['held_only'], commands['initial_aligned'])))
    check('two_conditions810_joint_rows', len(rows) == 810)
    after = {path: sha(path) for path in before}
    check('all_input_SHA_unchanged', before == after)
    (P / 'joint_ranges.jsonl').write_text(''.join(json.dumps(row, allow_nan=False) + '\n' for row in rows))
    result = dict(checks=checks, input_sha256_before=before, input_sha256_after=after, sources=source_metadata,
                  summary=summaries, joint_row_count=len(rows), native_initializations=0, physics_steps=0,
                  actor_inference_calls=0, training_updates=0, torch_version=str(torch.__version__),
                  scope='Necessary native/source/normalized range audit only; nearest values not applied; no task-specific postprocessing, runtime or natural/playing certification')
    (P / 'compatibility.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps(dict(check_count=len(checks), summary=summaries), indent=2))

#!/usr/bin/env python3
"""Render a sealed, saved-data summary for playing_target_bridge_v1."""
import hashlib
import json
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path("/home/ajou/yigyu/3")
A = ROOT / "stability_adapter_2"
P = ROOT / "docs/2026-10-12/stability_adapter_2/results/playing_target_bridge_v1"
OLD = ROOT / "docs/2026-10-12/stability_adapter_2/results/body9_strap_minus2mm_v1/native"
OUT = P / "artifacts"
FONT = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def json_file(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def input_paths(contract, snapshot):
    paths = {Path(path) for path in contract["input_sha256_before"]}
    paths.update({
        A / "make_playing_bridge_artifacts.py",
        P / "contract.json", P / "execution.json", P / "execution.log",
        P / "execution_producer.py", P / "playing_target_bridge.py",
        P / "check_playing_target_bridge.py", P / "PLAYING_TARGET_BRIDGE_PLAN.md",
        OLD / "initial_values.json", OLD / "report.json", OLD / "videos.json",
        OLD / "frames/hands/00000.png", OLD / "hands.mp4", OLD / "whole_body.mp4",
        FONT, OUT / "source_snapshot.json",
    })
    for item in snapshot["files"]:
        paths.add(OUT / item["copy_path"])
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError("missing sealed inputs: " + ", ".join(sorted(missing)))
    return {str(path): sha256(path) for path in sorted(paths)}


def main():
    expected_outputs = (OUT / "playing_bridge_summary.png", OUT / "artifact_manifest.json")
    if any(path.exists() for path in expected_outputs):
        raise SystemExit("refusing to overwrite an existing artifact; use a new versioned output path")
    contract = json_file(P / "contract.json")
    execution = json_file(P / "execution.json")
    snapshot = json_file(OUT / "source_snapshot.json")
    if len(contract["checks"]) != 10 or not all(contract["checks"].values()):
        raise ValueError("contract checks are incomplete")
    if any(contract[key] != 0 for key in ("native_initializations", "physics_steps", "actor_inference_calls", "training_updates")):
        raise ValueError("the recorded CPU bridge execution has nonzero native/actor/training counts")
    if execution["exit_code"] != 0 or any(execution[key] != 0 for key in ("native_initializations", "physics_steps", "actor_inference_calls", "training_updates")):
        raise ValueError("saved bridge execution record does not match the source-only scope")

    source_expected = contract["input_sha256_before"]
    before = input_paths(contract, snapshot)
    for path, digest in source_expected.items():
        if before[path] != digest:
            raise ValueError("contract input hash mismatch: " + path)
    if before[str(A / "make_playing_bridge_artifacts.py")] != snapshot["producer_sha256"]:
        raise ValueError("producer copy SHA does not match producer source")

    sources = {item["label"]: item for item in contract["sources"]}
    fret = [sources[label] for label in ("fret47000", "fret47500")]
    if any(item["evaluation"] is None or item["evaluation"]["checkpoint_file_sha_at_evaluation_available"] for item in fret):
        raise ValueError("unexpected Fret evaluation SHA attestation")
    if any(item["strict_G0_qualification"]["qualified_for_g0"] for item in contract["sources"]):
        raise ValueError("unexpected strict G0 qualification")
    labels = [item["name"] for item in contract["actual_baseline_profile_mismatches"]]
    initial = contract["actual_initial_q_profile_mismatches"]
    if labels != [item["name"] for item in initial] or len(labels) != 6:
        raise ValueError("the two six-joint mismatch groups do not align")

    f1 = [item["evaluation"]["metrics"]["f1_l"] for item in fret]
    changes_baseline = [math.degrees(item["required_min_target_change_rad"]) for item in contract["actual_baseline_profile_mismatches"]]
    changes_initial = [math.degrees(item["required_min_target_change_rad"]) for item in initial]
    producer_before = sha256(A / "make_playing_bridge_artifacts.py")

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 11})
    fig, (ax_f1, ax_delta) = plt.subplots(1, 2, figsize=(14.2, 7.5), gridspec_kw={"width_ratios": [0.9, 1.65]})
    fig.suptitle("Playing source evaluation and Fret profile compatibility", fontsize=15)

    f1_names = ["Fret 47,000 · goal_pair", "Fret 47,500 · goal_pair"]
    f1_colors = ["#3568a8", "#d97728"]
    bars = ax_f1.barh([0, 1], f1, color=f1_colors, height=0.52)
    ax_f1.set_yticks([0, 1], f1_names)
    ax_f1.invert_yaxis()
    ax_f1.set_xlim(0, 0.12)
    ax_f1.set_xlabel("Stored Fret f1_l (dimensionless)")
    ax_f1.set_title("Stored Fret full-song evaluations")
    ax_f1.grid(axis="x", alpha=0.25)
    for bar, value in zip(bars, f1):
        ax_f1.text(value + 0.002, bar.get_y() + bar.get_height() / 2, "{:.6f}".format(value), va="center", ha="left")

    y = list(range(len(labels)))
    height = 0.34
    colors = {"PD target": "#3568a8", "Initial q": "#d97728"}
    bars_pd = ax_delta.barh([v - height / 2 for v in y], changes_baseline, height=height, color=colors["PD target"], label="Actual baseline PD target")
    bars_q = ax_delta.barh([v + height / 2 for v in y], changes_initial, height=height, color=colors["Initial q"], label="Actual initial q")
    ax_delta.set_yticks(y, [name.replace("LH:", "") for name in labels])
    ax_delta.invert_yaxis()
    ax_delta.set_xlim(0, 43)
    ax_delta.set_xlabel("Unsigned required minimum target change (degrees)")
    ax_delta.set_title("Distance to Fret effective profile interval")
    ax_delta.grid(axis="x", alpha=0.25)
    for bars_group, values in ((bars_pd, changes_baseline), (bars_q, changes_initial)):
        for bar, value in zip(bars_group, values):
            ax_delta.text(value + 0.45, bar.get_y() + bar.get_height() / 2, "{:.2f}°".format(value), va="center", ha="left", fontsize=8)

    fig.legend(handles=[bars_pd, bars_q], labels=["Actual baseline PD target", "Actual initial q"], frameon=False,
               loc="upper center", bbox_to_anchor=(0.74, 0.93), ncol=2, fontsize=9)
    fig.text(0.5, 0.025, "The right panel shows unsigned minimum profile corrections, not selected angles or a physical response.", ha="center", fontsize=9)
    fig.tight_layout(rect=(0, 0.07, 1, 0.88), w_pad=3.0)
    fig.savefig(OUT / "playing_bridge_summary.png", dpi=180)
    plt.close(fig)

    after = input_paths(contract, snapshot)
    producer_after = sha256(A / "make_playing_bridge_artifacts.py")
    if before != after or producer_before != producer_after:
        raise RuntimeError("producer or sealed inputs changed during render")
    outputs = {"playing_bridge_summary.png": sha256(OUT / "playing_bridge_summary.png")}
    manifest = {
        "producer": str(A / "make_playing_bridge_artifacts.py"),
        "producer_sha256": producer_before,
        "inputs_sha256_before": before,
        "inputs_sha256_after": after,
        "outputs_sha256": outputs,
        "native_calls": 0,
        "physics_steps": 0,
        "actor_inference_calls": 0,
        "training_updates": 0,
        "figure": "playing_bridge_summary.png",
        "scope": "saved contract/evaluation evidence and prior native capture reference; no bridge execution, native render, actor, or training",
    }
    (OUT / "artifact_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"figure": str(OUT / "playing_bridge_summary.png"), "outputs_sha256": outputs, "sealed_input_count": len(before)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

"""Plot saved hand/neck QP probes and native traces; never runs physics."""
import argparse
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


COLORS = {
    "old reference": "#475569",
    "old-length arm candidate": "#dc2626",
    "p3 route-match": "#2563eb",
    "p08 route-match": "#16a34a",
    "p3 preload 10 N": "#d97706",
    "p3 preload 20 N": "#7c3aed",
}


def read_json(path):
    return json.loads(Path(path).read_text())


def draw_error_panel(ax, axr, row, samples, label, color):
    t = [s["time_s"] for s in samples]
    pos = [s["position_error_m"] * 1000 for s in samples]
    rot = [s["rotation_error_deg"] for s in samples]
    ax.plot(t, pos, color=color, lw=1.8,
            label=f"{label} · max {max(pos):.1f} mm")
    axr.plot(t, rot, color=color, lw=1.35, ls="--",
             label=f"{label} · max {max(rot):.2f}°")


def plot_curves(results_dir, previous_results_dir, rows, output):
    old_ref = next(r for r in rows if r["group"] == "short" and r["name"] == "reference")
    old_arm = next(r for r in rows if r["group"] == "short" and r["name"] == "candidate_01")
    p3 = next(r for r in rows if r["group"] == "coupled_short" and r["name"] == "p3_load00")
    p08 = next(r for r in rows if r["group"] == "coupled_short" and r["name"] == "p08_load00")
    p310 = next(r for r in rows if r["group"] == "coupled_short" and r["name"] == "p3_load10")
    p320 = next(r for r in rows if r["group"] == "coupled_short" and r["name"] == "p3_load20")
    long_rows = [next(r for r in rows if r["group"] == "coupled_hold_05s" and r["name"] == n)
                 for n in ("p3_load00", "p08_load00")]
    previous = read_json(previous_results_dir / "comparison.json")
    old_half = next(r for r in previous["rows"]
                    if r["group"] == "hold_05s" and r["name"] == "reference")

    fig, axes = plt.subplots(2, 1, figsize=(13, 9.5))
    panels = [
        (axes[0], [
            (old_ref, Path(old_ref["run"]) / "trace.json", "old reference · L=1.083374 m", COLORS["old reference"]),
            (old_arm, Path(old_arm["run"]) / "trace.json", "old-length arm candidate · L=1.083374 m", COLORS["old-length arm candidate"]),
            (p3, Path(p3["run"]) / "trace.json", "p3 route-match · L=1.101080 m", COLORS["p3 route-match"]),
            (p08, Path(p08["run"]) / "trace.json", "p08 route-match · L=1.101080 m", COLORS["p08 route-match"]),
            (p310, Path(p310["run"]) / "trace.json", "p3 preload 10 N · L=1.099413 m", COLORS["p3 preload 10 N"]),
            (p320, Path(p320["run"]) / "trace.json", "p3 preload 20 N · L=1.097747 m", COLORS["p3 preload 20 N"]),
        ], "0.1 s paired short traces: old absolute length vs route-matched length"),
        (axes[1], [
            (old_half, Path(old_half["run"]) / "trace.json",
             "previous reference · L=1.083374 m", COLORS["old reference"]),
            (long_rows[0], Path(long_rows[0]["run"]) / "trace.json",
             "p3 route-match · L=1.101080 m", COLORS["p3 route-match"]),
            (long_rows[1], Path(long_rows[1]["run"]) / "trace.json",
             "p08 route-match · L=1.101080 m", COLORS["p08 route-match"]),
        ], "0.5 s hold: prior reference vs p3/p08 route-matched settings"),
    ]
    for ax, series, title in panels:
        axr = ax.twinx()
        for row, trace_path, label, color in series:
            draw_error_panel(ax, axr, row, read_json(trace_path), label, color)
        ax.set_title(title)
        ax.set_ylabel("Position error (mm)")
        axr.set_ylabel("Rotation error (degrees)")
        ax.set_xlabel("Time (s)")
        ax.grid(True, alpha=.24)
        left, ll = ax.get_legend_handles_labels()
        right, rl = axr.get_legend_handles_labels()
        ax.legend(left + right, ll + rl, frameon=False, ncol=2,
                  fontsize=8, loc="upper left")
    fig.suptitle("Nearer initial palm/neck geometry does not maintain hand support", fontsize=13)
    fig.text(.5, .012,
             "Solid: guitar position error to candidate goal; dashed: rotation error. "
             "Short mismatched length starts with 106.236 N recorded tension; no support gate is inferred.",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .04, 1, .96), h_pad=1.5)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=160, bbox_inches="tight")
    plt.close(fig)


def render_snapshot(run, step, row, hand_metrics):
    # Import Gym before MuJoCo; only restores saved body poses into source-shape query data.
    import stability_adapter_2.environment  # noqa: F401
    from stability_adapter_2.plot_physx_contacts import source_surfaces
    from stability_adapter_2.replay_contact_geometry import recorded_probe

    model, data, shapes = recorded_probe(run, step)
    surfaces, _, _, _ = source_surfaces(model, data, shapes)
    trace = read_json(run / "trace.json")
    report = read_json(run / "report.json")
    time_s = step / report["physics_hz"]
    sample = min(trace, key=lambda s: abs(s["time_s"] - time_s))
    hull_field = "initial_palm_neck_hulls" if step == 0 else "final_palm_neck_hulls"
    hulls = row[hull_field]
    return {"surfaces": surfaces, "route": np.asarray(sample["route_points_m"], dtype=float),
            "hand": hand_metrics, "witnesses": np.asarray(hulls["hull_witness_points_m"], dtype=float),
            "distance_m": hulls["source_hull_distance_m"], "step": step, "time_s": time_s}


def _keep_closeup_shape(shape):
    body = shape["body"]
    if shape["actor"] == "guitar":
        return body == "guitar" or body == "G:nut" or body.startswith("G:fret") or body.startswith("G:string")
    return body.startswith("LH:") or body in {"L_Wrist", "L_Elbow"}


def plot_source_comparison(results_dir, rows, output):
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection

    def find(group, name):
        return next(r for r in rows if r["group"] == group and r["name"] == name)

    panels = [
        (find("short", "reference"), 0, "Previous reference · t=0"),
        (find("coupled_short", "p3_load00"), 0, "p3 · t=0"),
        (find("coupled_short", "p08_load00"), 0, "p08 · t=0"),
        (find("coupled_hold_05s", "p08_load00"), 120, "p08 · t=0.5 s"),
    ]
    snapshots, bounds = [], []
    for row, step, label in panels:
        hand_metrics = row["initial_hand"] if step == 0 else row["final_hand"]
        snap = render_snapshot(Path(row["run"]), step, row, hand_metrics)
        snap["label"] = label
        snap["run_name"] = row["name"]
        filtered = [(tri, shape) for tri, shape in snap["surfaces"] if _keep_closeup_shape(shape)]
        snap["surfaces"] = filtered
        bounds.extend([tri.reshape(-1, 3) for tri, _ in filtered])
        bounds.extend([snap["witnesses"], np.asarray(hand_metrics["palm_center_world_m"])[None, :]])
        snapshots.append(snap)

    points = np.concatenate(bounds)
    center = (points.min(0) + points.max(0)) / 2
    half = float(np.ptp(points, axis=0).max()) / 2 + .025
    fig = plt.figure(figsize=(15, 10))
    hand_color = "#16a34a"
    for panel, snap in enumerate(snapshots, start=1):
        ax = fig.add_subplot(2, 2, panel, projection="3d")
        for triangles, shape in snap["surfaces"]:
            color = "#2563eb" if shape["actor"] == "guitar" else hand_color
            ax.add_collection3d(Poly3DCollection(
                triangles, facecolors=color, alpha=.46 if color == "#2563eb" else .60,
                edgecolors="none"))
        palm = np.asarray(snap["hand"]["palm_center_world_m"])
        normal = np.asarray(snap["hand"]["palm_normal_world"])
        ax.scatter(*palm, color=hand_color, s=24, depthshade=False)
        ax.quiver(*palm, *(normal * .06), color="#7c3aed", linewidth=1.6,
                  arrow_length_ratio=.25)
        witness = snap["witnesses"]
        ax.plot(witness[:, 0], witness[:, 1], witness[:, 2], color="#f59e0b",
                marker="o", markersize=3.5, lw=2, label="QP hull witness segment")
        route = snap["route"]
        ax.plot(route[:, 0], route[:, 1], route[:, 2], color="#111827",
                ls="--", lw=1.3, alpha=.8, label="saved strap route (local visible part)")
        ax.set(xlim=(center[0]-half, center[0]+half),
               ylim=(center[1]-half, center[1]+half),
               zlim=(center[2]-half, center[2]+half),
               xlabel="World X (m)", ylabel="World Y (m)", zlabel="World Z (m)")
        ax.set_box_aspect((1, 1, 1))
        ax.view_init(elev=21, azim=116)
        ax.set_title(f"{snap['label']} · unsigned hull distance {snap['distance_m']*1000:.3f} mm")
        if panel == 1:
            ax.legend(loc="upper left", fontsize=7, frameon=False)
    fig.suptitle("Source hand/neck proximity at saved poses — not physical support", fontsize=13)
    fig.text(.5, .012,
             "Blue: guitar neck source shapes | Green: left hand/wrist source shapes | "
             "Purple: palm-normal proxy (sign unverified) | Orange: QP witness points | "
             "dashed: local visible segment of saved strap route. Same world bounds/view; CPU source convex-hull reconstruction.",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .045, 1, .95), h_pad=1.6, w_pad=.7)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=155, bbox_inches="tight")
    plt.close(fig)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def manifest_paths(comparison_path, results_dir, previous_results_dir, rows):
    paths = {Path(__file__).resolve()}
    for name in ("plot_physx_contacts.py", "replay_contact_geometry.py", "initial_overlap.py",
                 "environment.py", "config.json", "control.py", "strap.py", "trial_settings.py",
                 "physics_presets.py"):
        paths.add(Path(__file__).with_name(name).resolve())
    paths.add(comparison_path.resolve())
    for name in ("search_v2/search.json", "search/search.json", "distance_cutoff_probe.json",
                 "coupling_inputs.json", "source/search_hand_support_source.py"):
        candidate = results_dir / name
        if candidate.is_file():
            paths.add(candidate.resolve())
    for row in rows:
        run = Path(row["run"])
        for name in ("trace.json", "report.json", "states.json"):
            candidate = run / name
            if candidate.is_file():
                paths.add(candidate.resolve())
    old_comparison = previous_results_dir / "comparison.json"
    paths.add(old_comparison.resolve())
    previous_row = next(r for r in read_json(old_comparison)["rows"]
                        if r["group"] == "hold_05s" and r["name"] == "reference")
    old_run = Path(previous_row["run"])
    for name in ("trace.json", "report.json", "states.json"):
        paths.add((old_run / name).resolve())
    config = read_json(Path(__file__).with_name("config.json"))
    root = Path(__file__).resolve().parents[1]
    for key in ("humanoid_asset", "guitar_asset", "pose_source"):
        asset = (root / config[key]).resolve()
        if asset.is_file():
            paths.add(asset)
            if asset.suffix == ".xml":
                xml = ET.parse(asset).getroot()
                compiler = xml.find("compiler")
                meshdir = asset.parent / (compiler.get("meshdir", "") if compiler is not None else "")
                for mesh in xml.findall("./asset/mesh"):
                    candidate = (meshdir / mesh.attrib["file"]).resolve()
                    if candidate.is_file():
                        paths.add(candidate)
    return sorted(p for p in paths if p.is_file())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comparison", type=Path, required=True)
    parser.add_argument("--results-dir", type=Path, required=True)
    parser.add_argument("--previous-results-dir", type=Path, required=True)
    parser.add_argument("--curve-output", type=Path, required=True)
    parser.add_argument("--geometry-output", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args()
    for path in (args.curve_output, args.geometry_output, args.manifest):
        if path.exists():
            parser.error(f"refusing to overwrite existing artifact: {path}")
    comparison = read_json(args.comparison)
    rows = comparison["rows"]
    plot_curves(args.results_dir, args.previous_results_dir, rows, args.curve_output)
    plot_source_comparison(args.results_dir, rows, args.geometry_output)
    inputs = manifest_paths(args.comparison, args.results_dir, args.previous_results_dir, rows)
    payload = {
        "purpose": "read-only source-geometry and saved native-trace plots; no new rollout",
        "plot_script": str(Path(__file__).resolve()),
        "input_hashes_sha256": {str(p): sha256(p) for p in inputs},
        "output_hashes_sha256": {str(p.resolve()): sha256(p) for p in
                                 (args.curve_output, args.geometry_output)},
        "native_run_count": len(rows),
        "source_pose_panels": [
            {"run": r["run"], "step": step, "time_s": step / 240,
             "hull_distance_m": (r["initial_palm_neck_hulls"] if step == 0 else
                                 r["final_palm_neck_hulls"])["source_hull_distance_m"]}
            for r, step, _ in [
                (next(x for x in rows if x["group"] == "short" and x["name"] == "reference"), 0, "reference"),
                (next(x for x in rows if x["group"] == "coupled_short" and x["name"] == "p3_load00"), 0, "p3"),
                (next(x for x in rows if x["group"] == "coupled_short" and x["name"] == "p08_load00"), 0, "p08"),
                (next(x for x in rows if x["group"] == "coupled_hold_05s" and x["name"] == "p08_load00"), 120, "p08_0.5s"),
            ]
        ],
    }
    args.manifest.parent.mkdir(parents=True, exist_ok=True)
    args.manifest.write_text(json.dumps(payload, indent=2) + "\n")


if __name__ == "__main__":
    main()

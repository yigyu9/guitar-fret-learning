"""Measure sampled source geometry from saved short trials; no physics steps."""
import json
import argparse
from pathlib import Path
from types import SimpleNamespace

from .thigh_palm_support import PHASE, intersection
from .build_fixed_lower_asset import read, sha
from .replay_contact_geometry import recorded_probe
from .render_best_run_video import set_saved_pose
from .search_hand_support import palm_neck_gap
from .pose_strap_inputs import pose_metrics
from .plot_neck_palm import geometry
from .trial_settings import source_hashes
import mujoco


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--near-touch',action='store_true')
    parser.add_argument('--validated',action='store_true')
    args=parser.parse_args()
    output = PHASE/('comparison_validated.json' if args.validated else 'comparison_near_touch.json' if args.near_touch else 'comparison.json')
    if output.exists():
        raise FileExistsError('preserve comparison')
    inputs = {str(Path(__file__).resolve()):sha(Path(__file__))}
    inputs.update(source_hashes())
    for name in ('thigh_palm_support.py','replay_contact_geometry.py','plot_neck_palm.py',
                 'render_best_run_video.py','search_hand_support.py','pose_strap_inputs.py','plot_joint_hold.py'):
        p=Path(__file__).with_name(name).resolve();inputs[str(p)]=sha(p)
    archived = {str(Path(__file__).with_name('run_thigh_palm_support.py').resolve()):[PHASE/('runner_v'+str(v)+'.py') for v in (1,2,3)],
        str(Path(__file__).with_name('thigh_palm_support.py').resolve()):[PHASE/('search_producer_v'+str(v)+'.py') for v in (2,3)]}
    history = []
    rows = []
    names=('reference','clear_50um','clear_100um','clear_150um','clear_2um') if args.validated else ('clear_2um',) if args.near_touch else ('reference','clear_50um','clear_100um','clear_150um')
    for name in names:
        run = PHASE/'short'/name
        for filename in ('report','states','trace','contacts'):
            p = run/(filename+'.json'); inputs[str(p)] = sha(p)
        report,states = read(run/'report.json'),read(run/'states.json')
        for path,expected in report['source_sha256'].items():
            resolved=Path(path)
            if sha(resolved)!=expected:
                matches=[p for p in archived.get(path,[]) if sha(p)==expected]
                if not matches:
                    raise ValueError('historical run input changed: '+path)
                resolved=matches[0]
                history.append({'run':name,'source_path':path,'snapshot_path':str(resolved),'sha256':expected})
            inputs[str(resolved)]=expected
        model,data,shapes = recorded_probe(run,0)
        samples = []
        for step in (0,1,12,24):
            state = states[step]
            set_saved_pose(model,mujoco,report,state); mujoco.mj_forward(model,data)
            scene = SimpleNamespace(human=0,guitar=1,human_bodies=report['human_body_names'],
                guitar_bodies=report['guitar_body_names'],bodies=lambda actor:state['human_body_states'] if actor==0 else state['guitar_body_states'])
            meshes = {s['geom_id']:geometry(model,data,s) for s in shapes}
            pairs = []
            for a in [s for s in shapes if s['body'].startswith('LH:') or s['body']=='L_Wrist']:
                for b in [s for s in shapes if s['body'].startswith('RH:') or s['body']=='R_Wrist']:
                    radius = intersection(meshes[a['geom_id']],meshes[b['geom_id']])
                    if radius>1e-7:
                        pairs.append({'left':a['body'],'right':b['body'],'common_interior_ball_radius_m':radius})
            samples.append({'physics_step':step,'palm_neck':palm_neck_gap((model,data,shapes)),
                'hand':pose_metrics(scene,(model,data,shapes)),'hand_intersections':pairs})
        rows.append({'name':name,'run':str(run),'max_position_error_mm':1000*report['max_position_error_m'],
            'max_rotation_error_deg':report['max_rotation_error_deg'],'absolute_rest_length_m':report['absolute_rest_length_m'],
            'support_contact_steps':report['support_contact_steps'],'source_samples':samples,
            'native_checks_pass':all(report['checks'].values()) and all(report['support_checks'].values())})
    if not all(sha(Path(p))==h for p,h in inputs.items()):
        raise ValueError('analysis inputs changed')
    output.write_text(json.dumps({'scope':'Saved 0.1s trials; sampled source hull checks, not PhysX cooked clearance or full-time collision certification.',
        'rows':rows,'input_sha256':inputs,'historical_source_snapshots':history,'inputs_verified_before_and_after':True,
        'decision':'Do not adopt as stable support; inspect native contact and sampled hand intersections before any extension.'},indent=2,allow_nan=False)+'\n')
    print(json.dumps([{'name':r['name'],'p_mm':r['max_position_error_mm'],'q_deg':r['max_rotation_error_deg'],
        'palm_gap_mm':[1000*s['palm_neck']['source_hull_distance_m'] for s in r['source_samples']],
        'hand_cross_counts':[len(s['hand_intersections']) for s in r['source_samples']]} for r in rows],indent=2))


if __name__=='__main__':
    main()

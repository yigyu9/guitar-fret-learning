# 같은 네 strap 길이의0.5초 연속 진단

직전 단계는 진행이었다. 절대LA를줄여0.1초 기타p/q는개선됐지만손바닥접촉은
소실됐고10N은종료장력0/비영속도가남았다. 현재최대오차만으로길이를채택하지않는다.

- [x] 1. 기존 runner를보존하고새 long runner에서각기처음부터120steps를실행한다.
  current/taut/initial5N/10N의초기각·기타목표·길이·제어·PD는직전조건과같다.
  첫24step의상태/trace/tasks/controls/contacts6배열이각각이전짧은실행prefix와
  exact여야한다. 길이상수·root하체/몸통9목표·66합성·target cap/rate를유지한다.
- [x] 2. 네조건각1init120steps(총4init480steps)를작은순차batch로실행한다.
  palm-up proxy 위쪽반구밖/상태비유한/제약실패면해당run을중단하고실패원자료를보존한다.
  초기장력외조건변경은없으며지속pose쓰기/강제부착/기타목표힘은없다.
- [x] 3. 최대및종료p/q/속도/장력/몸통편차·palm/허벅지contact와rawlambda·source
  gap·면각·손이탈을읽는다. 0.5초는후기진단이며성공유지시간을확정하는값이아니다.
  양쪽기타오차가줄어드는유망후보는실제Gym camera별도1init120steps로재현한다.
  0/4/…/120step frame을저장해전체0.5초영상도만든다. 더작은초기오차만으로
  최종길이를채택하지않는다. camera/headless raw6exact와render상태불변을확인한다.
- [x] 4. 결과는 docs/2026-10-12/stability_adapter_2/results/palm_side_strap_long_v1에
  저장한다. 원자료분석→확정brief로Luna시각화/영상→Sol확인→독립검수한다.

보존한원래plan/producer/결과는변경하지않는다. 0.1초와이번실행을이어붙이지
않으며새초기화후연속실행으로검증한다. 접촉존재/면정렬/짧은오차개선만으로지지·
연주·작은움직임성공을주장하지않는다. 후속은확인된strap조건의유한시간팔응답교정이다.

## 0.5초 결과와 실제 장면 기록 결정

네조건은120step을완료했고첫24step6raw는각이전조건과exact다. 최대p/q는
current53.538626mm/6.994315°,taut60.944152mm/9.231735°,5N60.592216mm/
9.327781°,10N60.019756mm/9.534431°다. 짧은길이의0.1초개선은0.5초최대오차
개선으로이어지지않았다. 모두palm후기접촉이없다. 새길이를채택하지않는다.

양쪽기타오차를개선한후보가없으므로유망후보촬영대신current를이번0.5초비교의
진단기준으로실제camera재현한다(1init120steps추가,총5init600steps). 초기부터
종료까지0/4/…/120step을저장해팔과기타이탈을영상으로기록한다. 이는전체이력의
최고후보/지지성공영상이라는뜻이아니다. 상체실제drift/목표오차와보정포화를읽고
팔유한시간응답을교정한다. 절대길이의추가장력범위를넓히지는않는다.

current의0.5초손추적점최대오차47.437265mm/source법선gap34.275077mm,
몸통실제각최대편차3.424335°가남았다. L_Shoulder_x는종료actual−target24.218°이며
actual−initial7.029°다. 이수치만으로중력/effort포화/좌표문제를단정하지않는다.
다음은같은current조건의PD목표작은변화에대한0.1초응답을실제로교정한다.
기존firststep응답을후기응답으로대체하지않고startupbias/feedback효과를분리한다.

## 목표 오차의 좌표 해석

위24.218°와7.029°는native DOF 좌표성분차이를rad에서도로환산한값이다.
L_Shoulder 전체방향의SO(3)회전각과동일하다고해석하지않는다. 로컬SDK의
[구면관절예제](/home/ajou/yigyu/3/isaacgym/python/examples/spherical_joint.py:215)는
회전벡터값을state와position target에같이쓰지만예제자산은URDF spherical이다.
이번[모델](/home/ajou/yigyu/3/stability_adapter_2/assets/humanoid_fixed_lower.xml:118)의
동일body내3hinge importer drive변환까지그예제로인증하지않는다. 현재팔mass
readback도기록되지않아중력만으로설명하지않는다. 다음응답교정은native pose를
직접읽어실제손변화를측정하며추측에근거한gain변경을동시에추가하지않는다.

# 오른손 초기 접촉을 위한 작은 distal 각도 비교

2026-10-06. 직전 스트랩12회는 두 기타 오차 동시 개선이 없었다(progress).
현재 candidate_01와 무장력 절대 LA1.1010801317960974m를 진단 기준으로 유지한다.
기존 C02±0.3rad∩모델 초기각 승인의 후속이며 새 제어/gate 승인 요청이 아니다.

- [x] 1. 오른 Elbow/Wrist6만 한 좌표 sweep으로 세밀하게 검사한다.
  각 좌표에서 현재 best 초기각에 ±0.005/±0.01/±0.025rad를 더하되 최종각은
  C02±0.3rad∩모델로 제한한다(최대37 fresh 검사). 초기 unsigned RH:palm/G:body
  nominal1mm 거리 가까움을 soft 선호하고 다양성은0.005rad로 둔다.
  기존 전신 source 음수pair0/LH 위쪽 반구·국소 넥 아래 조건은 유지한다.
  이전 기본 coarse search의3mm/두 sweep/절대C02 offsets 동작은 바꾸지 않는다.
- [x] 2. 같은 기준+source 통과 개선 최대3후보를 각0.1초 native hold OFF로 비교한다.
  기준 raw4는 직전 candidate_01 OFF와 exact여야 한다. 근접 거리는 접촉 인증이 아니다.
  손·어깨 접촉 시점, 기타 p/q, 속도·장력·실제 팔 편차를 분석한다.
- [x] 3. 초기 실제 손 접촉이 빨라지거나 초기 기타 두 오차 개선이 확인되는 후보만
  기존 승인 PI OFF/ON으로0.5초까지 진단한다. 긴 실행 prefix/paired 상태를 확인한다.
  전부 손 접촉0·기타 개선 없음이면 연장하지 않고 다음 방향을 근거로 기록한다.
- [x] 4. Luna에 확정된 수치/판정을 전달해 그림·설명을 누적21절에 추가한다.
  다른 change-reviewer의 코드/원자료/매체/문서 검수를 마친다.

오른 Thorax/Shoulder 초기각·왼팔p08·finger42·torso9·C02 하체/root·기타+5mm
유지 목표·native PD/solver·LA/원본 strap 수식은 유지한다. proximal body/route도 대조한다.
기타 고정/강제부착/실행 중 pose 덮어쓰기/새controller/gain/동적strap/학습은 추가하지 않는다.
위치 controller 제안은 사용자 확인 전이며 실행하지 않는다. 성공 threshold/최종채택을
임의 확정하지 않는다. 구현/입력은stability_adapter_2, 결과는
 docs/2026-10-12/stability_adapter_2/results/right_distal_fine_v1에 보존한다.

## 짧은 결과와 승인 PI 재사용 진단

37개 source 검사에서 RH 간격3.936732→2.200303/2.256704/2.313745mm,
0.1초 최대 기타 오차는 기준6.876050mm/1.519890°와
후보1 6.879917/1.520723, 후보2 6.872016/1.519281, 후보3 6.872551/1.519351이었다.
손/어깨 접촉0으로 근접 배치는 즉시 지지가 되지 않았다. 후보2는 두 오차를
약4µm/0.00061° 줄인 미세 차이이므로 유망 안정화로 해석하지 않는다.
3번의 진단 대상은 후보2 하나로 제한해 같은 기존 PI OFF/ON을0.1/0.5초 비교한다.
새 gain/구조는 없다. 비교 helper의 --half-second-only는 명시된4run을 모두
읽으며 누락 시 실패하고1초 결과가 있다고 가정하지 않는다. 기본6run 수학은 유지한다.

## 0.5초 후속 판정

후보2 OFF/ON의0.5초 최대 오차54.280113mm/7.851534° 및34.975339mm/4.871416°는
이전 배치0N의54.500076/7.900382 및35.847644/5.052139보다 두 항목 모두 감소했다.
ON 첫 thumb3 관측84step(.350초), 이전86step(.358333초)로2physics step 빨랐다.
손접촉 시작/행 수는 힘이나 계속된 지지의 증명이 아니다.
동일 승인 제어·각도·길이 조건의 후속으로1초 OFF/ON 각1회만 추가해 유지 효과를 진단한다.
4run comparison_05s.json을 보존한 뒤 기본6run helper로 comparison.json을 새로 만든다.
이는 최초0.5초 단위의 근거 있는 기간 연장이며 controller/gate/성공 기준 변경이 아니다.

## 1초 결과와 다음 진단 기준

1초 OFF143.674455mm/36.215772°,ON76.099207mm/14.183879°였다.
이전 초기각1초ON121.298052mm/29.759157°보다 줄었지만 자유 기타 유지 성공은 아니다.
ON thumb3 마지막 관측160step(.666667초)은 이전142step(.591667초)보다 늦었으나
161~240step에서 thumb3 관측이 없고 이후 기타 오차가 다시 커진다.
first/last 및69 unique contact samples는 그 사이 연속 지지나 힘의 증명이 아니다.
LH/shoulder 접촉0, 팔 최대편차14.280032°/보정포화212physics samples,
actual scalar joint-limit 위반0.030294°도 남는다.
후보2를 다음 초기각 진단 기준으로만 유지하고 고정/강제부착/pose 보정은 사용하지 않는다.
변경된 두 초기각은 기존c01 대비 Elbow_x+0.01rad/Wrist_x−0.005rad의 nominal 보정이다.
다음에는 이 주변의 Wrist_x 작은 초기각 조합과 접촉 소실 전후 actual 관절/기타 drift를
대조한다. 새 gain/cap/목표/위치 controller는 별도 확인 전 추가하지 않는다.

static 최초 comparison의 source_manifest3항목은 source_manifest_search.json에
원래 SHA와 byte exact로 보존했고, helper 추가 후4항목을 읽은 현재 comparison_v2.json을
별도 생성했다. 최초 자료와4run comparison_05s.json을 삭제/덮어쓰지 않았다.

## 최종 후처리 의존성 검수

최초 도구가 결과폴더의 모든JSON을해시해 산출물 manifest까지포함했고,
comparison_v2의 중간 manifest340b31aa… 버전은 별도로 보관되지 않은 시점 한계가 있다.
원자료/수치 문제는 아니지만 oldv2의 모든 dependency를 현재파일로재검증했다고 주장하지 않는다.
수정 전 helper와comparison/매체를 보존한 채 입력해시를 실제 읽은search·native원자료·
외부reference·source/helper로한정했다. 현재 canonical comparison_v3.json의수학 결과/전역check는
v2와exact이고 명시적해시입력87개는현재모두맞으며 media/comparison출력이 포함되지 않는다.
재생성 이미지의경우 v3를사용한다. 처음verification.json은 당시 스냅샷이며 최종검증은
verification_v2.json으로별도기록한다. 새 native실행이나 결과수정은하지않았다.


최종10run/PI/접촉/문서/매체 독립검수에서 남은 지적은 없었다. 지원 plotting CLI의
두PNG는 pixel exact이고, media 재생성 뒤 v3를 다시 비교해 전체 JSON exact임을 확인했다.
현재검증 verification_v2와 source_final 사본을남긴다. 기존87파일/Aug19 손자료49파일
보존을확인했다. 이 작업단위 완료이며 최종 자유기타/연주 안정화는 아직 검증되지 않았다.

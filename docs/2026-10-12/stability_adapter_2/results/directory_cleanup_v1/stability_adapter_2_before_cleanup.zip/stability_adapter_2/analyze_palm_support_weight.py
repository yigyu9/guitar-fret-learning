"""Verify three saved native alignment-weight trials and compare support observations."""
import json
from pathlib import Path
from scipy.spatial.transform import Rotation
from .run_palm_support_weight import PHASE,PREVIOUS
from .palm_side_feedback import context,np
from .palm_normal_task import prepare,error_from_state
from .build_fixed_lower_asset import read,sha,pose
from .analyze_palm_side_feedback import finite


def main():
    folders=[PHASE/name for name in ('scale_0p08','scale_0p02','scale_0')]
    paths=[Path(__file__).resolve(),Path(__file__).with_name('analyze_palm_side_feedback.py'),PHASE/'execution.json']
    for folder in folders:
        paths += [folder/(name+'.json') for name in ('report','states','trace','normal_tasks','tasks','controls','contacts')]
        paths += [Path(p) for p in read(folder/'report.json')['source_sha256']]
    hashes={str(p):sha(p) for p in paths};ctx=prepare(context());checks={};summaries=[]
    reference=read(PREVIOUS/'cap_0p3/short/states.json')
    for folder,scale in zip(folders,(.08,.02,0)):
        report=read(folder/'report.json');raw={name:read(folder/(name+'.json')) for name in ('states','trace','normal_tasks','tasks','controls','contacts')}
        if report['failure'] is not None or not all(report['checks'].values()):raise AssertionError('trial checks')
        if report['physics_steps']!=24 or report['native_initializations']!=1 or report['orientation_scale_m_per_rad']!=scale:raise AssertionError('trial identity')
        if not finite(raw):raise AssertionError('nonfinite raw')
        if not all(len(raw[n])==25 for n in ('states','trace','normal_tasks','tasks')) or not all(len(raw[n])==24 for n in ('controls','contacts')):raise AssertionError('coverage')
        if not all(r['physics_step']==i+1 for n in ('controls','contacts') for i,r in enumerate(raw[n])):raise AssertionError('step sequence')
        if not all(abs(t['time_s']-i/240)<1e-9 for i,t in enumerate(raw['trace'])):raise AssertionError('time sequence')
        if not all(r['updated_before_step']==(i%4==0) for i,r in enumerate(raw['controls'])):raise AssertionError('control schedule')
        weights=np.r_[np.ones(3),np.full(3,scale/.08)]
        for i,state in enumerate(raw['states']):
            error=error_from_state(state,ctx)
            if state['physics_step']!=i or error.tolist()!=raw['normal_tasks'][i] or (error*weights).tolist()!=raw['tasks'][i]:raise AssertionError('measured task recomputation')
        if any(sha(Path(p))!=h for p,h in report['source_sha256'].items()):raise AssertionError('production inputs changed')
        normal=np.array(raw['normal_tasks']);pairs=[(r['physics_step'],v) for r in raw['contacts'] for v in r['contacts']]
        palms=[(step,v) for step,v in pairs if {v['body0_name'],v['body1_name']}=={'human/LH:palm','guitar/guitar'}]
        end=raw['states'][-1];pp,pq=pose(end['human_body_states'][ctx['palm_index']]);gp,gq=pose(end['guitar_body_states'][0]);gr=Rotation.from_quat(gq)
        delta=pp+Rotation.from_quat(pq).apply(ctx['local_point'])-(gp+gr.apply(ctx['goal_point_G']-ctx['normal_G']*.00005))
        ng=gr.apply(ctx['normal_G']);gap=float(delta@ng)
        summaries.append({'label':folder.name,'orientation_scale_m_per_rad':scale,
            'first_step_point_error_mm':float(np.linalg.norm(normal[1,:3])*1000),
            'max_point_error_mm':float(np.linalg.norm(normal[:,:3],axis=1).max()*1000),
            'max_normal_angle_deg':float(np.linalg.norm(normal[:,3:],axis=1).max()/.08*180/np.pi),
            'end_normal_gap_mm':gap*1000,'end_tangent_distance_mm':float(np.linalg.norm(delta-gap*ng)*1000),
            'max_guitar_position_error_mm':max(t['position_error_m'] for t in raw['trace'])*1000,
            'max_guitar_rotation_error_deg':max(t['rotation_error_deg'] for t in raw['trace']),
            'guitar_body_states_exact_prior':all(s['guitar_body_states']==b['guitar_body_states'] for s,b in zip(raw['states'],reference)),
            'palm_contact_steps':sorted({step for step,v in palms}),'palm_contact_rows':len(palms),
            'positive_raw_palm_lambda_rows':sum(v['lambda']>0 for step,v in palms),
            'positive_raw_self_lambda_rows':sum(v['lambda']>0 and v['body0_name'].startswith('human/') and v['body1_name'].startswith('human/') for step,v in pairs),
            'minimum_source_palm_up_proxy_z':report['minimum_source_palm_up_proxy_z'],
            'max_actual_torso_drift_deg':float(np.abs([t['torso_drift_deg'] for t in raw['trace']]).max()),
            'blocked_counts_at_updates':[sum(r['integral_blocked']) for r in raw['controls'] if r['updated_before_step']]})
        checks[folder.name+'_contracts_coverage_tasks_sha']=True
    inventory=read(PREVIOUS/'artifact_inventory.json')
    checks['previous_phase_preserved']=all(sha(Path(p))==v['sha256'] for p,v in inventory.items())
    execution=read(PHASE/'execution.json')
    checks['three_runs_exit_zero']=len(execution)==3 and all(r['exit_code']==0 for r in execution)
    checks['inputs_unchanged']=all(sha(Path(p))==h for p,h in hashes.items())
    output={'checks':checks,'summary':summaries,'counts':{'native_initializations':3,'physics_steps':72},
        'input_sha256':hashes,'scope':'support observations over 0.1s; no physical success gate; postprocessing 0 native/0 physics'}
    (PHASE/'analysis.json').write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
    if not all(checks.values()):raise AssertionError(checks)
    print(json.dumps(output['summary'],indent=2))


if __name__=='__main__':main()

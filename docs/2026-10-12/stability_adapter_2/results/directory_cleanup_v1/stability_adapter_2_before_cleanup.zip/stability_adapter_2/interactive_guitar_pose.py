"""Native Isaac Gym keyboard pose editor; explicit free-physics recording episodes."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import time

from .capture_isaac_gym_initial import CameraEnvironment
from .environment import ROOT, gymapi, np, vector, quaternion
from .guitar_pose_edit import checked_pose, nudge, pose_delta, Rotation
from .gym_trial_recording import GymTrialRecording, sha
from .strap_trial_recording import StrapTrialRecording
from .run_joint_hold import native_state
from .build_fixed_lower_asset import LOWER_BODIES

BASELINE = ROOT/'docs/2026-10-12/stability_adapter_2/results/initial_middle3_alignment_v1/native/initial_values.json'
OUTPUT = ROOT/'docs/2026-10-12/stability_adapter_2/results/interactive_guitar_pose_sessions'
HELP = '''F1/F2/F3: translate X/Y/Z | F4/F5/F6: rotate X/Y/Z | J/L: -/+
F: fine step | Tab: world/local axes | Z: undo | R: original guitar pose
T: strap ON/OFF | C: whole body/hands camera | G: visual/collision geometry
S: save candidate + native images | Space: record 5s free physics
E: return to selected initial pose in a fresh scene | H: help | Esc: quit
EDIT = stopped time, manual placement; PREVIEW = physics, editing disabled.
After 5s PREVIEW COMPLETE is stopped time, not a claim of equilibrium.'''


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


class StateWriteGuard:
    """Fail closed if any state setter is used during a physical episode."""
    def __init__(self, gym):
        self.gym, self.locked, self.calls, self.blocked = gym, False, 0, 0

    def __getattr__(self, name):
        method = getattr(self.gym, name)
        if name.startswith('set_') and ('state' in name or 'transform' in name):
            def setter(*args, **kwargs):
                if self.locked:
                    self.blocked += 1
                    raise RuntimeError('state write forbidden during PREVIEW: '+name)
                self.calls += 1
                return method(*args, **kwargs)
            return setter
        return method


class Editor:
    def __init__(self, out, candidate=None, strap=True, viewer=True):
        self.out = Path(out).resolve()
        self.out.mkdir(parents=True, exist_ok=False)
        self.baseline = read(BASELINE)
        self.trial = self.baseline['input_trial']
        self.strap, self.want_viewer = strap, viewer
        self.viewer, self.env, self.recorder = None, None, None
        self.mode, self.axis, self.fine, self.local = 'EDIT', 0, False, False
        self.camera, self.collision, self.history = 0, False, []
        self.index, self.preview_index = 0, 0
        try:
            self.initialize(candidate)
        except BaseException:
            self.close_scene()
            raise

    def initialize(self, candidate):
        self.open_scene()
        self.reference = (self.position.copy(), self.quaternion.copy())
        if candidate is not None:
            value = read(candidate)
            if value['baseline_sha256'] != sha(BASELINE):
                raise ValueError('candidate baseline differs')
            if type(value['strap_enabled']) is not bool:
                raise ValueError('strap_enabled must be boolean')
            self.strap = value['strap_enabled']
            self.position, self.quaternion = checked_pose(value['position_W_m'], value['quaternion_xyzw'])
            self.install_pose()
        save(self.out/'session.json', {'baseline': str(BASELINE), 'baseline_sha256': sha(BASELINE),
            'candidate_input': str(Path(candidate).resolve()) if candidate else None,
            'candidate_sha256': sha(candidate) if candidate else None,
            'source_sha256': {str(Path(__file__).with_name(n)): sha(Path(__file__).with_name(n))
                for n in ('interactive_guitar_pose.py', 'guitar_pose_edit.py', 'INTERACTIVE_GUITAR_POSE_PLAN.md')},
            'reference_position_W_m': self.reference[0].tolist(),
            'reference_quaternion_xyzw': self.reference[1].tolist(),
            'scope': 'manual initial placement; constant PD targets during preview; no automatic search/policy/learning'})
        print(HELP, flush=True)
        self.status()

    def open_scene(self):
        self.env = CameraEnvironment(self.trial['initial_settings'], self.trial['guitar_initial_translation_m'])
        env = self.env
        if env.config['physics_hz'] != 240 or len(env.names) != 81 or len(env.main_indices) != 66 or len(env.leg_indices) != 0:
            raise AssertionError('240Hz, fixed lower body and 81/66 DOF layout required')
        env.gym = StateWriteGuard(env.gym)
        props = env.gym.get_actor_dof_properties(env.env, env.human)
        props['stiffness'][env.torso_indices] *= 2
        props['damping'][env.torso_indices] *= np.sqrt(2)
        if not env.gym.set_actor_dof_properties(env.env, env.human, props):
            raise RuntimeError('PD property submission failed')
        env.target = np.array(self.baseline['preserved_absolute_targets_rad'], dtype=np.float32)
        if env.names != self.baseline['human_joint_names']:
            raise AssertionError('baseline joint order changed')
        env._submit_targets()
        self.initial_human = env.bodies(env.human)
        self.template = env.bodies(env.guitar)
        self.position = vector(self.template[0]['pose']['p'])
        self.quaternion = quaternion(self.template[0]['pose']['r'])
        if self.want_viewer:
            props = gymapi.CameraProperties()
            props.width, props.height = 1280, 720
            self.viewer = env.gym.create_viewer(env.sim, props)
            if self.viewer is None:
                raise RuntimeError('native viewer creation failed; run in a graphical desktop terminal')
            keys = ['F1','F2','F3','F4','F5','F6','J','L','F','TAB','Z','R','T','C','G','S','SPACE','E','H','ESCAPE']
            for key in keys:
                env.gym.subscribe_viewer_keyboard_event(self.viewer, getattr(gymapi, 'KEY_'+key), key)
            self.set_camera()

    def set_camera(self):
        p, target = (((.9,1.8,1.15),(-.06,0,.68)) if self.camera == 0 else
                     ((-.05,.72,.89),(-.105,.095,.735)))
        self.env.gym.viewer_camera_look_at(self.viewer, self.env.env, gymapi.Vec3(*p), gymapi.Vec3(*target))

    def install_pose(self):
        if self.mode != 'EDIT':
            raise RuntimeError('manual placement only allowed in EDIT')
        env = self.env
        p, q = checked_pose(self.position, self.quaternion)
        old_p = vector(self.template[0]['pose']['p'])
        old_q = quaternion(self.template[0]['pose']['r'])
        delta = Rotation.from_quat(q)*Rotation.from_quat(old_q).inv()
        states = self.template.copy()
        for state, original in zip(states, self.template):
            bp = p + delta.apply(vector(original['pose']['p'])-old_p)
            bq = (delta*Rotation.from_quat(quaternion(original['pose']['r']))).as_quat()
            for axis, value in zip('xyz', bp): state['pose']['p'][axis] = value
            for axis, value in zip('xyzw', bq): state['pose']['r'][axis] = value
        states['vel']['linear'].fill(0)
        states['vel']['angular'].fill(0)
        if not env.gym.set_actor_rigid_body_states(env.env, env.guitar, states, gymapi.STATE_ALL):
            raise RuntimeError('manual initial pose submission failed')
        actual = env.bodies(env.guitar)[0]
        self.position, self.quaternion = checked_pose(vector(actual['pose']['p']), quaternion(actual['pose']['r']))
        if np.linalg.norm(self.position-p)>1e-6 or abs(self.quaternion@q)<1-1e-6:
            raise AssertionError('native pose readback mismatch')
        if not np.array_equal(self.initial_human, env.bodies(env.human)) or env.steps != 0:
            raise AssertionError('editing changed humanoid state or advanced physics')
        env.goal_position, env.goal_quaternion = self.position.copy(), self.quaternion.copy()
        points, _ = env.route()
        env.initial_route_length = float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum())

    def payload(self):
        env = self.env
        return {'position_W_m': self.position.tolist(), 'quaternion_xyzw': self.quaternion.tolist(),
            'rotation_pivot': 'guitar actor root origin', 'frame': 'world, Z up',
            'baseline_path': str(BASELINE), 'baseline_sha256': sha(BASELINE),
            'delta_from_reference': pose_delta(self.position, self.quaternion, self.reference),
            'strap_enabled': self.strap, 'strap_rest_length_m': env.rest_length,
            'input_trial': self.trial, 'human_joint_names': env.names,
            'actual_initial_angles_rad': env.initial_q.astype(float).tolist(),
            'constant_PD_targets_rad': env.target.astype(float).tolist(),
            'body9_PD_scales': {'kp': 2., 'kd': float(np.sqrt(2))},
            'scope': 'user-selected placement; no collision clearance or stability certification'}

    def make_recorder(self, path):
        return (StrapTrialRecording if self.strap else GymTrialRecording)(self.env, path)

    def save_candidate(self):
        path = self.out/('candidate_%03d' % self.index)
        path.mkdir()
        self.index += 1
        save(path/'pose.json', self.payload())
        self.make_recorder(path/'images').capture()
        print('Saved candidate:', path/'pose.json', flush=True)
        return path

    def start_preview(self):
        if self.mode != 'EDIT': return
        self.preview_path = self.out/('preview_%03d' % self.preview_index)
        self.preview_path.mkdir()
        self.preview_index += 1
        save(self.preview_path/'initial_values.json', dict(self.payload(), native_initial_state=native_state(self.env),
            physics_parameters=self.env.physics_parameters,
            PD_properties={n:self.env.gym.get_actor_dof_properties(self.env.env,self.env.human)[n].tolist()
                           for n in self.env.gym.get_actor_dof_properties(self.env.env,self.env.human).dtype.names}))
        self.recorder = self.make_recorder(self.preview_path)
        self.trace = (self.preview_path/'states.jsonl').open('x')
        self.preview_initial = native_state(self.env)
        self.state_write_calls = self.env.gym.calls
        self.env.gym.locked = True
        self.mode = 'PREVIEW'
        self.record_state()
        self.recorder.capture()
        self.status()

    def record_state(self):
        state = native_state(self.env)
        if not np.isfinite(self.env.bodies(self.env.guitar).view(np.float32)).all():
            raise FloatingPointError('nonfinite guitar state')
        for name in ('Pelvis',)+LOWER_BODIES:
            i = self.env.human_bodies.index(name)
            if state['human_body_states'][i] != self.preview_initial['human_body_states'][i]:
                raise AssertionError('fixed root/lower changed')
        self.trace.write(json.dumps(state, allow_nan=False)+'\n')

    def advance(self):
        if self.mode != 'PREVIEW': return
        for _ in range(self.recorder.interval):
            if self.strap:
                self.env.step_physics()
            else:
                self.env.tension = 0.
                self.env.gym.simulate(self.env.sim)
                self.env.gym.fetch_results(self.env.sim, True)
                self.env.steps += 1
            self.record_state()
        self.recorder.capture()
        if self.env.steps%240 == 0: self.status()
        if self.env.steps >= 1200: self.finish_preview()

    def finish_preview(self, failure=None):
        if self.recorder is None: return
        self.trace.close()
        videos, encoding_error = {}, None
        try:
            videos = self.recorder.encode()
        except BaseException as error:
            encoding_error = repr(error)
            failure = str(failure or '')+'; video encoding failed: '+encoding_error
        completed = self.env.steps == 1200 and len(self.recorder.frames) == 151 and len(videos) == 2 and failure is None
        save(self.preview_path/'report.json', {'completed': completed,
            'failure': failure, 'physics_steps': self.env.steps,
            'simulation_elapsed_s': self.env.steps/240, 'frame_count': len(self.recorder.frames),
            'post_start_state_writes': self.env.gym.calls-self.state_write_calls,
            'blocked_state_writes': self.env.gym.blocked, 'strap_enabled': self.strap,
            'videos': videos, 'scope': 'constant-target preview; no policy, feedback or equilibrium certification'})
        self.recorder = None
        self.mode = 'PREVIEW COMPLETE' if completed else 'PREVIEW STOPPED'
        print('Preview saved:', self.preview_path, flush=True)
        self.status()
        if encoding_error: raise RuntimeError(encoding_error)

    def return_to_edit(self):
        if self.mode == 'PREVIEW': self.finish_preview('user returned before 5s')
        if self.mode == 'EDIT': return
        selected = (self.position.copy(), self.quaternion.copy())
        self.close_scene()
        self.mode = 'EDIT'
        self.open_scene()
        self.position, self.quaternion = selected
        self.install_pose()
        self.status()

    def handle(self, key):
        if key == 'ESCAPE': return False
        if key == 'H': print(HELP, flush=True)
        elif key == 'C':
            self.camera = 1-self.camera
            if self.viewer is not None: self.set_camera()
        elif key == 'G': self.collision = not self.collision
        elif key == 'E': self.return_to_edit()
        elif self.mode == 'EDIT':
            if key in ('F1','F2','F3','F4','F5','F6'): self.axis = int(key[1])-1
            elif key == 'F': self.fine = not self.fine
            elif key == 'TAB': self.local = not self.local
            elif key == 'T': self.strap = not self.strap
            elif key in ('J','L','R','Z'):
                if key == 'Z':
                    if not self.history: return True
                    self.position, self.quaternion = self.history.pop()
                else:
                    self.history.append((self.position.copy(), self.quaternion.copy()))
                    if key == 'R': self.position, self.quaternion = (x.copy() for x in self.reference)
                    else:
                        step = ((.0005 if self.fine else .002) if self.axis<3 else
                                np.radians(.25 if self.fine else 1.))
                        self.position, self.quaternion = nudge(self.position,self.quaternion,
                            self.axis%3, step*(-1 if key=='J' else 1), self.axis>=3, self.local)
                self.install_pose()
            elif key == 'S': self.save_candidate()
            elif key == 'SPACE': self.start_preview()
        self.status()
        return True

    def status(self):
        print('%s | %s %s | %s | %s | strap %s | t=%.3fs | selected p=%s | q(xyzw)=%s' % (
            self.mode, 'move' if self.axis<3 else 'rotate', 'XYZ'[self.axis%3],
            'local' if self.local else 'world', 'fine' if self.fine else 'normal',
            'ON' if self.strap else 'OFF', self.env.steps/240,
            np.round(self.position,6), np.round(self.quaternion,6)), flush=True)

    def draw(self):
        env = self.env
        env.gym.clear_lines(self.viewer)
        state = env.bodies(env.guitar)[0]
        p, q = vector(state['pose']['p']), quaternion(state['pose']['r'])
        directions = np.eye(3)*.07
        if self.local: directions = Rotation.from_quat(q).apply(directions)
        vertices = np.array([[p,p+d] for d in directions],dtype=np.float32)
        env.gym.add_lines(self.viewer,env.env,3,vertices,np.eye(3,dtype=np.float32))
        if self.strap:
            points,_ = env.route()
            vertices = np.stack((points[:-1],points[1:]),axis=1).astype(np.float32)
            env.gym.add_lines(self.viewer,env.env,len(vertices),vertices,
                np.tile(np.array([1.,.61,.12],dtype=np.float32),(len(vertices),1)))
        env.gym.step_graphics(env.sim)
        env.gym.draw_viewer(self.viewer,env.sim,self.collision)

    def close_scene(self):
        if self.viewer is not None:
            self.env.gym.destroy_viewer(self.viewer)
            self.viewer = None
        if self.env is not None:
            self.env.close()
            self.env = None

    def close(self, failure=None):
        try:
            if self.recorder is not None: self.finish_preview(failure or 'window closed or interrupted')
        finally:
            self.close_scene()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=None)
    parser.add_argument('--candidate',type=Path)
    parser.add_argument('--no-strap',action='store_true')
    args = parser.parse_args()
    if not os.environ.get('DISPLAY'):
        parser.error('DISPLAY is unset. Run this tool in a graphical desktop terminal.')
    out = args.out or OUTPUT/datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    editor, failure = None, None
    try:
        editor = Editor(out,args.candidate,not args.no_strap)
        running = True
        while running and not editor.env.gym.query_viewer_has_closed(editor.viewer):
            start = time.monotonic()
            for event in editor.env.gym.query_viewer_action_events(editor.viewer):
                if event.value>0:
                    running = editor.handle(event.action)
                    if not running: break
            if not running: break
            editor.advance()
            editor.draw()
            time.sleep(max(0,1/30-(time.monotonic()-start)))
    except BaseException as error:
        failure = repr(error)
        raise
    finally:
        if editor is not None: editor.close(failure)


if __name__ == '__main__': main()

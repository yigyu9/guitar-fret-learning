# 손바닥보정과함께사용할단일축손가락관절검증

Measured geometry v1에서palm만접근시킨12팔각제안은16배치중fraction0기준4개와t0 quarter만source screening을통과했다. 이후quarter도검지/중지Gsource교차를증가시켰다. 고정G/순간고정finger/기하dq진단이므로실제PD/자유G의결과와같지않지만이방향의ON실험은실행하지않는다. 전체손/palm안정화범위를버리지않고손가락보정과함께방향을설계한다.

두축finger1 map은불명확하다. 단일축인LH:thumb2/3,index2/3,middle2/3 여섯관절을먼저독립검증한다.0/24/120/1200과기존20heldout시점을읽는다. 각관절t0의actual parent–child relativeposition/rotation을한번calibrate하고,actualq_t로joint exp(axis×q_t)×exp(axis×q0)^−1×relative0를계산한다. 각시점actualparentpose를입력해childpose를예측한다. Parent의FK오차를포함한전체손모델이아니라조건부singlehinge관계다. 매시점relative0를다시fit하지않는다.

Axis/parent는공용MJCF를읽고관절한개인body만검사한다. 기존0.1mm/0.001rad gate를그대로사용하며144관측을보고한다. 통과하더라도모든각범위·PD응답·접촉을인증하지않는다. Targetmodel/Aug19/초기offset±0.3 조건은이후보정범위에서적용한다. 신규native/physics0,source·로그·출력은별도경로에보존한다.

- [ ] 여섯singlehinge의4+20 actualparent조건부pose대조
- [ ] 팔12+singlehinge6의측정기하multi-task 설계근거
- [ ] source겹침/정렬·영역제약 후실제5초실행방향판단

최종66연주권한과기타초기p/q복원·유지/후면엄지·전면손가락·옆면손바닥지지의전체목표는유지한다. 기타고정·손부착·지속physicsstateoverwrite는쓰지않는다.

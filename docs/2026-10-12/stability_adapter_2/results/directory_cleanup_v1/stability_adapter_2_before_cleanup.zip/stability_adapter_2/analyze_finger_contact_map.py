"""Map saved native finger origins and SDK features to guitar-local coordinates."""
from pathlib import Path
import ast,hashlib,json
import numpy as np
from scipy.spatial.transform import Rotation
R=Path(__file__).resolve().parents[1];A=R/'stability_adapter_2';B=R/'docs/2026-10-12/stability_adapter_2/results';P=B/'finger_contact_map_v1';BASE=B/'fixed_strap_shoulder_response_v1/plus008'
FINGERS=['thumb','index','middle','ring','pinky'];STEPS=[0,32,56,1200]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def vector(v):return np.array([v[k] for k in 'xyz'])
def pose(b):return vector(b['pose']['p']),Rotation.from_quat([b['pose']['r'][k] for k in 'xyzw'])
def world(b,point):
    p,r=pose(b);return p+r.apply(point)
def local(root,point):
    p,r=pose(root);return r.inv().apply(point-p)
def main():
    assert not (P/'analysis.json').exists() and not (P/'features.jsonl').exists()
    helpers=[A/'analyze_three_face_native_features_v2.py',A/'native_contacts.py',R/'isaacgym/docs/api/python/struct_py.html']
    prop=B/'torso_hold_native_collision_v1/initial_collision/shape_properties.json';proposal=B/'fixed_strap_shoulder_response_v1/proposal.json'
    paths=[Path(__file__).resolve(),A/'FINGER_CONTACT_MAP_PLAN.md',prop,proposal,B/'finger_curl_diagnosis_v1/analysis.json']+helpers+[BASE/n for n in ['initial_values.json','states.jsonl','contacts.jsonl','capture.json','report.json']]
    initial=read(BASE/'initial_values.json');capture=read(BASE/'capture.json');report=read(BASE/'report.json')
    frames={f['physics_step']:f for f in capture['frames']}
    for step in STEPS:
        paths += [Path(p) for p in frames[step]['image_sha256'] if '/hands/' in p]
    before={str(p):sha(p) for p in paths};h_names=initial['human_body_names'];g_names=[r['body'] for r in read(prop)['actors']['guitar']['body_ranges']]
    states=[json.loads(s) for s in (BASE/'states.jsonl').read_text().splitlines()];contacts=[json.loads(s) for s in (BASE/'contacts.jsonl').read_text().splitlines()]
    tree=ast.parse(helpers[0].read_text());fn=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='patch_metrics');scope={'np':np};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(helpers[0]),'exec'),scope);patch_metrics=scope['patch_metrics']
    guides={k:np.array(v) for k,v in read(proposal)['regions_G_m'].items()};guides['front_outer']=guides['front'].copy();guides['front_outer'][:,2]=read(proposal)['front_outer_source_z_G_m'];outward=dict(front=[0,0,1],front_outer=[0,0,1],thumb=[0,0,-1],palm=[1,0,0])
    checks=dict(complete_native_saved=report['completed'] and report['physics_steps']==1200 and len(states)==1201 and len(contacts)==1200,ordered_states_contacts=[s['physics_step'] for s in states]==list(range(1201)) and [s['physics_step'] for s in contacts]==list(range(1,1201)),single_substep=initial['physics_parameters'].get('substeps',1)==1)
    features=[];mapping=True;roundtrip=0.;post_gap=[];pre_gap=[];shifts=[];offsets=[]
    for record in contacts:
        step=record['physics_step'];state=states[step];root=state['guitar_body_states'][0]
        for row,c in enumerate(record['contacts']):
            ns=[c['body0_name'],c['body1_name']]
            if c['lambda']<=0 or not any(n.startswith('guitar/') for n in ns) or not any(n.startswith('human/LH:') for n in ns):continue
            j=next(k for k,n in enumerate(ns) if n.startswith('guitar/'));g_name=ns[j].split('/',1)[1];h_name=ns[1-j].split('/',1)[1];gi=g_names.index(g_name);hi=h_names.index(h_name)
            mapping &= c['body'+str(j)]==len(h_names)+gi and c['body'+str(1-j)]==hi
            gl=vector(c['localPos'+str(j)]);hl=vector(c['localPos'+str(1-j)]);go=vector(c['offset'+str(j)]);ho=vector(c['offset'+str(1-j)])
            gw=world(state['guitar_body_states'][gi],gl);hw=world(state['human_body_states'][hi],hl);point=local(root,gw);normal=pose(root)[1].inv().apply(vector(c['normal'])*(1 if j==0 else -1))
            pre=states[step-1];pg=world(pre['guitar_body_states'][gi],gl);ph=world(pre['human_body_states'][hi],hl)
            pair=float(np.linalg.norm(gw-hw));shift=float(np.linalg.norm(gw-pg));post_gap.append(pair);pre_gap.append(float(np.linalg.norm(pg-ph)));shifts.append(shift);offsets.append([float(np.linalg.norm(go)),float(np.linalg.norm(ho))]);roundtrip=max(roundtrip,float(np.linalg.norm(world(root,point)-gw)))
            face='palm' if h_name=='LH:palm' else 'thumb' if h_name.startswith('LH:thumb') else 'front_outer'
            features.append(dict(physics_step=step,contact_row=row,human_body=h_name,guitar_body=g_name,raw_lambda=c['lambda'],guitar_feature_G_m=point.tolist(),human_feature_G_m=local(root,hw).tolist(),guitar_surface_proxy_G_m=local(root,world(state['guitar_body_states'][gi],gl+go)).tolist(),post_pair_residual_mm=pair*1000,pre_pair_residual_mm=float(np.linalg.norm(pg-ph))*1000,pre_post_guitar_feature_shift_mm=shift*1000,reference_face=face,patch_metrics=patch_metrics(point,normal,guides[face],outward[face])))
    checks.update(all_positive_LH_body_ids_match=bool(mapping),world_G_roundtrip_1e12=roundtrip<=1e-12,post_feature_pair_residual_below_1um=bool(post_gap) and max(post_gap)<=1e-6)
    snapshots=[];lengths={}
    for step in STEPS:
        state=states[step];root=state['guitar_body_states'][0];chains={}
        for finger in FINGERS:
            names=['LH:'+finger+n for n in ['1','2','3','_top']];points=[local(root,pose(state['human_body_states'][h_names.index(n)])[0]).tolist() for n in names]
            chains[finger]=dict(body_names=names,origins_G_m=points);lengths.setdefault(finger,[]).append(float(np.linalg.norm(np.diff(points,axis=0),axis=1).sum()*1000))
        frame=frames[step];checks['frame_'+str(step)+'_exact']=frame['time_s']==step/240 and frame['render_preserves_states'] and all(sha(p)==h for p,h in frame['image_sha256'].items() if '/hands/' in p)
        snapshots.append(dict(physics_step=step,time_s=step/240,chains=chains,frame_path=next(p for p in frame['image_sha256'] if '/hands/' in p),current_positive_features=[r for r in features if r['physics_step']==step]))
    summary=[]
    for finger in FINGERS:
        rows=[r for r in features if r['human_body']=='LH:'+finger+'3'];steps=sorted(set(r['physics_step'] for r in rows));summary.append(dict(finger=finger,positive_steps=len(steps),first_step=min(steps) if steps else None,last_step=max(steps) if steps else None,positive_rows=len(rows),guide_near2mm_rows=sum(r['patch_metrics']['projection_inside'] and abs(r['patch_metrics']['signed_plane_distance_mm'])<=2 for r in rows),chain_origin_length_mm_range=[min(lengths[finger]),max(lengths[finger])]))
    diagnosis=read(B/'finger_curl_diagnosis_v1/analysis.json');checks['distal_positive_counts_match_prior']=all(s['positive_steps']==next(r['positive_raw_lambda_steps'] for r in diagnosis['distal_body_contacts'] if r['body']=='human/LH:'+s['finger']+'3') for s in summary)
    after={str(p):sha(p) for p in paths};checks['inputs_preserved']=before==after
    result=dict(checks=checks,input_sha256_before=before,input_sha256_after=after,summary=summary,snapshots=snapshots,regions_G_m={k:v.tolist() for k,v in guides.items()},coordinates=dict(post_feature_pair_max_mm=max(post_gap)*1000,pre_feature_pair_max_mm=max(pre_gap)*1000,max_pre_post_guitar_feature_shift_mm=max(shifts)*1000,max_world_G_roundtrip_m=roundtrip,max_guitar_offset_m=max(r[0] for r in offsets),max_human_offset_m=max(r[1] for r in offsets)),native_initializations=0,physics_steps=0,actor_inference_calls=0,training_updates=0,scope='post-step body-origin SDK features, not thickness/cooked surface or force; body-origin chains not anatomical pads; finite reference guides, no native depth occlusion claim')
    (P/'features.jsonl').write_text(''.join(json.dumps(r,allow_nan=False)+'\n' for r in features));(P/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(checks=checks,summary=summary,coordinates=result['coordinates'])));assert all(checks.values()),checks
if __name__=='__main__':main()

# 넥 수평·앞판 정면 초기 회전 후보

2026-10-09 사용자 확인: 넥은 바닥과 평행에 가깝고 줄이 있는 앞판은 정면을 향한다. 본 채팅에서 비교한 바디 중심을 유지하고 회전만 새 후보로 계산한다. root 위치를 고정한 회전으로 바디가 이동하는 효과를 피한다. 공용 모델·이전 실행/소스/결과를 수정하지 않는다. 최신 다른 위치영역 시각화도 유지하며 해당 actor-root 중심을 이번 후보로 임의 승계하지 않는다.

- [ ] 순수 회전 helper로 넥 상승각-10/0/+10°, 관객 방위0°, 앞판 법선world+Y의3후보를 계산·검산한다. 선호중심0°는수평이다.
- [ ] 독립 사전 검토 후 static Editor로 native13이 아닌3배치 촬영. 물리0·humanoid body/DOF 동일·입력 SHA 확인. GPU가없으면native실패로그를보존하고렌더를성공으로표현하지않는다.
- [ ] 결과 문서·변경파일실제줄·mainappend·최종검수·root보존감사. 산출물은확정brief에따라Luna가담당한다.

바디 중심은이채팅의직전비교center pose에서R·[0,-0.4,-0.0217]m를더해구한다. +X사람오른쪽/+Y관객쪽/+Z위. 넥local+Y는world[-cos(a),0,sin(a)]로, 앞판local+Z는world[0,1,0]로두고local+X는두벡터의외적이다. 행렬은정규직교·det+1이다. root p=body_center-R·body_center_local. UI의actor-root 회전pivot과다르다.

이번사진에서는팔·손상태를변경하지않으므로수평넥과왼손의높이차이를보여준다. 실제초기화채택은팔/손초기각재배치·관통검사·자유기타검증뒤결정한다. 기타고정/손부착/물리중pose덮어쓰기/PD·스트랩길이·controller/학습변경은없다.

구현: /home/ajou/yigyu/3/stability_adapter_2/horizontal_guitar_pose.py 와 render_horizontal_guitar.py. 결과: /home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/horizontal_neck_initial_v1/.

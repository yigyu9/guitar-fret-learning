"""Read saved target/response windows; no simulator, controller or force inference."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def array(value, shape):
    result = np.asarray(value, dtype=float)
    if result.shape != shape or not np.isfinite(result).all():
        raise ValueError('finite array with shape ' + str(shape) + ' required')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--reference-report', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise FileExistsError('preserve previous analysis')
    comparison = read(args.run/'comparison.json')
    copies = read(args.run/'source_final_manifest.json')
    inputs = dict(comparison['input_sha256'])
    if not all(comparison['checks'].values()) or not all(sha(p)==h for p,h in inputs.items()):
        raise ValueError('saved comparison contracts or consumed sources differ')
    if not all(sha(v['copy_path'])==v['sha256'] for v in copies.values()):
        raise ValueError('previous frozen copies differ')
    reference = read(args.reference_report)
    names = reference['human_joint_names']
    series, summaries = {}, []
    for mode in ('PI', 'RATE_PI', 'PALM_RATE'):
        paths = [args.run/mode/(n+'.json') for n in ('report', 'states', 'controls', 'queries')]
        report, states, controls, queries = [read(p) for p in paths]
        if not all(report['checks'].values()) or report['mode']!=mode:
            raise ValueError('native report differs: '+mode)
        if len(states)!=121 or len(queries)!=121 or len(controls)!=120:
            raise ValueError('121 states/queries and 120 controls required')
        if [s['physics_step'] for s in states]!=list(range(121)) or [q['physics_step'] for q in queries]!=list(range(121)):
            raise ValueError('state/query step alignment differs')
        if [q['time_s'] for q in queries]!=[k/240 for k in range(121)] or [c['physics_step'] for c in controls]!=list(range(1,121)):
            raise ValueError('query time/control step alignment differs')
        if [c['updated_before_step'] for c in controls]!=[k%4==0 for k in range(120)]:
            raise ValueError('30 update schedule differs')
        arm = report['arm_indices']
        if arm!=reference['arm_indices'] or len(arm)!=24 or report['initial_joint_targets_rad']!=reference['initial_joint_targets_rad']:
            raise ValueError('reference arm24 or initial pose differs')
        q = np.array([array([d['pos'] for d in s['human_dof_states']], (len(names),)) for s in states])[:,arm]
        points = np.array([array(v['left_source_world_m'], (3,)) for v in queries])
        goal = array(queries[0]['palm_goal_world_m'], (3,))
        if any(not np.array_equal(array(v['palm_goal_world_m'], (3,)), goal) for v in queries):
            raise ValueError('initial source-point goal changed')
        records = []
        for k in range(0,120,4):
            target = array(controls[k]['final_arm_targets_rad'], (24,))
            if any(not np.array_equal(array(c['final_arm_targets_rad'], (24,)), target) for c in controls[k:k+4]):
                raise ValueError('delivered target was not held for four steps')
            matrix = array(queries[k]['left_position_J_m_per_rad'], (3,12))
            pre_gap, post_gap = target-q[k], target-q[k+4]
            static = matrix @ pre_gap[:12]
            measured = points[k+4]-points[k]
            realized = matrix @ (q[k+4,:12]-q[k,:12])
            error = goal-points[k]
            distance = float(np.linalg.norm(error))
            projection = None if distance<=1e-12 else float(measured @ error/distance*1000)
            record = {'pre_step':k, 'post_step':k+4, 'pre_time_s':k/240, 'post_time_s':(k+4)/240,
                'target_minus_pre_actual_rad':pre_gap.tolist(), 'target_minus_post_actual_rad':post_gap.tolist(),
                'left_max_pre_gap_deg':float(np.abs(pre_gap[:12]).max()*180/np.pi),
                'right_max_pre_gap_deg':float(np.abs(pre_gap[12:]).max()*180/np.pi),
                'left_max_post_gap_deg':float(np.abs(post_gap[:12]).max()*180/np.pi),
                'static_delivered_target_shift_world_m':static.tolist(),
                'static_delivered_target_shift_norm_mm':float(np.linalg.norm(static)*1000),
                'observed_interval_shift_world_m':measured.tolist(),
                'observed_interval_shift_norm_mm':float(np.linalg.norm(measured)*1000),
                'observed_return_direction_projection_mm':projection,
                'actual_arm_coordinate_linear_shift_world_m':realized.tolist(),
                'observed_minus_actual_arm_linear_world_m':(measured-realized).tolist()}
            if mode=='PALM_RATE':
                calculated = array(controls[k]['calculated_arm_targets_rad'], (24,))
                residual = matrix @ (calculated[:12]-q[k,:12])-2*error
                if not np.allclose(residual, array(controls[k]['position_task_residual_m'], (3,)), atol=1e-12, rtol=0):
                    raise ValueError('saved static task residual differs')
                record['calculated_target_task_residual_norm_mm'] = float(np.linalg.norm(residual)*1000)
            records.append(record)
        left = max(records, key=lambda r:r['left_max_pre_gap_deg'])
        right = max(records, key=lambda r:r['right_max_pre_gap_deg'])
        summaries.append({'mode':mode, 'max_left_pre_gap_deg':left['left_max_pre_gap_deg'],
            'left_joint_at_max_gap':names[arm[int(np.abs(left['target_minus_pre_actual_rad'][:12]).argmax())]],
            'max_right_pre_gap_deg':right['right_max_pre_gap_deg'],
            'right_joint_at_max_gap':names[arm[12+int(np.abs(right['target_minus_pre_actual_rad'][12:]).argmax())]],
            'max_left_post_gap_deg':max(r['left_max_post_gap_deg'] for r in records),
            'positive_return_projections':sum(r['observed_return_direction_projection_mm'] is not None and r['observed_return_direction_projection_mm']>0 for r in records),
            'negative_return_projections':sum(r['observed_return_direction_projection_mm'] is not None and r['observed_return_direction_projection_mm']<0 for r in records),
            'undefined_return_projections':sum(r['observed_return_direction_projection_mm'] is None for r in records),
            'last_window':records[-1]})
        series[mode] = records
        inputs.update({str(p.resolve()):sha(p) for p in paths})
    paths = [args.run/'comparison.json', args.run/'source_final_manifest.json', args.reference_report, Path(__file__).resolve()]
    inputs.update({str(p.resolve()):sha(p) for p in paths})
    inputs.update({v['copy_path']:v['sha256'] for v in copies.values()})
    if not all(sha(p)==h for p,h in inputs.items()):
        raise ValueError('consumed sources changed during analysis')
    result = {'scope':'saved 0.5s response audit; native initializations/physics steps 0; no parameter changes',
        'checks':{'saved_contracts_and_sources_current':True, 'previous_frozen_copies_preserved':True,
            'three_aligned_30_window_series':all(len(v)==30 for v in series.values()), 'four_step_delivered_targets_held':True,
            'initial_world_source_goal_held':True, 'PALM_calculated_static_residuals_match':True},
        'series':series, 'summaries':summaries, 'input_sha256':inputs,
        'semantics':'Joint gaps are native scalar coordinate differences, not physical rotation angles or torque. Static linear target shifts have no response time. Observed four-step shifts include all human motion. Linear arm-only remainder has mixed causes. Initial zero-error projection is null.'}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps({'checks':result['checks'], 'summaries':summaries}, indent=2))


if __name__=='__main__':
    main()

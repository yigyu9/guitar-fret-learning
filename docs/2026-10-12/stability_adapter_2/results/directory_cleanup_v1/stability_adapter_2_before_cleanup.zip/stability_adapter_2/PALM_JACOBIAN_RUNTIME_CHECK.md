# 동일 PI 실행의 native Jacobian·속도 계측

2026-10-07. 초기 FK 좌표 대조의 후속 읽기 전용 진단이다.
현재 reference.json, LA1.1010801317960974m, 기타 +5mm 초기 p/q와 승인 팔24 PI를 유지한다.
기존 run_joint_hold의 동일 0.1초 prefix와 비교하며 새 위치 task/gain/rate-limit을 넣지 않는다.

- [x] 1. 매 physics step 후 fetch가 완료된 상태에서 Jacobian CPU buffer를 refresh 전/후
  복사한다. t=0 포함25개 시점, 양쪽 palm row의6×105열을 저장한다.
  전체 native 상태·목표·PD·LA·step이 조회 전후 같은지 검사한다.
- [x] 2. full105 native DOF velocity에 raw Jacobian을 곱해 world COM linear/angular
  velocity와 비교한다. source 중심으로 옮긴 속도 및 body-origin 해석도 구분한다.
  refresh 전/후 cache 차이와 native body velocity 대응 오차를 수치로 기록한다.
  native velocity 좌표가 위치 좌표 미분과 같다고 가정하지 않는다.
- [x] 3. 저장된3초 동일 PI run의 초기 states/trace/controls와0.1초 prefix를 대조한다.
  다른 물리 경로가 생겼다면 결과를 그 차이와 함께 보고하며 비교 성공으로 처리하지 않는다.
- [x] 4. 이미지·설명·실제 명령·입력 SHA·실패 이력·변경 절대경로/줄을 저장하고
  독립 검수한다. 초기 FK 결과를 runtime 전체 정확성으로 확대하지 않는다.

기타 p/q 유지 성공은 아직 아니다. 향후 위치 제어는 계측 후 구체적 비교안을 확인받는다.
main 구현/계획은 stability_adapter_2, 결과는
docs/2026-10-12/stability_adapter_2/results/palm_jacobian_runtime_v1에 둔다.

## 실제 결과

1 native 초기화·24 physics steps·25 query의9개 계약과71개 입력 SHA를 확인했다.
상태/trace/controls prefix는 기존3초 run과 같았고 추가 query는 물리 경로를 바꾸지 않았다.
Cache 대조3개 검사·75개 입력 SHA도 통과했다. t=0 before-refresh buffer는0이었고
post0에는 모두 직전 refreshed 값이었다. 따라서 매 제어 시점에 refresh해야 한다.
Refresh 후 최대COM 속도 오차는LH1.500569mm/s/RH1.371527mm/s,
angular 오차는LH0.001590517rad/s/RH0.004353958rad/s다. Body-origin 속도 해석의
최대COM 오차68.134978/49.273723mm/s보다 COM 해석이 더 잘 대응했다.
오차가0은 아니며 현재 짧은 진단으로 모든 runtime 자세의 정확성을 인증하지 않는다.
다음은 [현재 위치 보정 비교안](PALM_POSITION_COMPARISON.md)의 중요한 제어 변경 확인이다.

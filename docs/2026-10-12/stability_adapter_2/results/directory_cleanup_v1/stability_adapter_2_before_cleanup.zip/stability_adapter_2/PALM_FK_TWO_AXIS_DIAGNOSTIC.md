# 현재손 FK의 두축 회전 합성 진단

Runtime FK v1은palm anchor오차최대0.000157mm/normal오차4.71e-7이나전체body gate는미달했다. Ring1 회전오차가5초0.017248rad로누적돼ring_top 위치오차1.221470mm다. 기존left_fk는모든같은body 관절을basis@q rotation-vector하나로처리한다. 그가정을두DOF finger1에서도쓸수있는지저장actualpose로독립대조한다. 기존source/oldFK/결과를고치지않는다.

1. Native초기t0 joint/body calibration은한번만한다. 세좌표는기존expmap,한좌표는hinge exp를유지한다. 두좌표에대해서만exp(sum),XML순서의rotation product,역순product를비교한다. 매시점actual q와actual parent/child 상대회전으로joint자체오차를평가해상위팔누적오차와구분한다. Axis는공용MJCF의실제joint axis를읽는다.
2. 기존4시점0/24/120/1200에서세가설을비교한다. 추가20heldout시점1/4/8/12/36/48/60/96/144/180/240/300/360/480/600/720/840/960/1080/1192에서동일가설을대조한다. Rest rotation/translation을다시fit하지않고임의tolerance를늘리지않는다. 전체왼팔·손body의0.1mm/0.001rad gate를같이검사한다.
3. 일치하는가설이있으면새FK helper로source point/normal/Jacobian·source geometry를사용할근거를남긴다. 표본밖native importer계약/모든자세/PD접촉응답을인증하지않는다. 일치없으면원인진단을이어간다. 추가native/physics0이며기존실제영상출처를표시한다.

- [ ] 두축3가설의joint상대회전·전체chain4시점대조
- [ ] 정해진20heldout시점·동일rest calibration 검증
- [ ] source기하제어사용범위·그림/문서·다음실행계약판단

R_Thorax_x actualnativebound가step24에서일시위반됐다는관측도그대로기록한다. 목표관절한계와실제물리관절상태를같게표현하지않는다. 미실행제어후보의PD목표경계통과는source겹침/actual한계·물리지지 통과와같지않다. 최종연주66권한/몸통9목표·자유기타·passivestrap·고정root하체를유지한다.

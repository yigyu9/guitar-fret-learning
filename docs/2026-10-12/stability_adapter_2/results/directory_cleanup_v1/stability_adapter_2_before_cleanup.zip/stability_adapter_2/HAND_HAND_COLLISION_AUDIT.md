# 현재 고정 하체 실행의 양손 겹침 검사

사용자 질문: 왼손과 오른손이 충돌하는 것처럼 보이는가?
기존 `lower_body_fixed_v1/full_1s`의 241 상태와 240 contact 기록을 읽는다.
제어·초기 자세·충돌 설정은 이번 검사에서 바꾸지 않는다.

- [x] native contact 행과 실제 새 초기화의 shape collision filter를 확인한다.
  양손 contact0, 전체 humanoid self contact0, 모든 손 shape 쌍은 공통 filter bit를 가진다.
  새 초기화1회, explicit physics step0. 기존 실행/영상은 보존한다.
- [x] 저장 pose에서 source geom 17×17쌍 거리 부호를 조회한다.
  첫 음수 step14, worst step161이다. mesh signed query는 cutoff에 따라 부호가
  달라진 기존 이력이 있으므로 이 결과만으로 실제 교차를 확정하지 않는다.
- [x] 독립 convex-hull halfspace LP로 교차를 검증한다. 대표 5개 시점(0/14/120/161/240)의 모든 쌍을 AABB로
  거르고, 두 hull 안에 공통으로 들어가는 양의 반경 공이 있는지 검사한다.
  mesh hull은 source convex hull, capsule은 기존 source 시각화의 내부 근사다.
  양의 내부 반경은 교차 근거이며 음수 query의 크기를 penetration depth로 쓰지 않는다.
  전체 구간 첫 교차 시간과 교차 상태 개수는 이 대표 시점 검사로 확정하지 않는다.
  전체 LP 스캔은 계산 비용이 커 중단하고 대표 시점 검사로 범위를 줄였다.
- [x] 결과·기존 영상 미리보기 설명을 새 결과 디렉터리와 누적 VISUAL 문서에 남기고
  독립 검토한다. 결과는 `docs/2026-10-12/stability_adapter_2/results/hand_hand_collision_audit_v1/`.

결과: 0/14에서는 strict hull 교차를 확인하지 못했고, 120/161/240에서는 각각
18/15/18쌍을 확인했다. step161 LH:pinky3–RH:palm은 두 hull 내부의 공통 ball 반경
6.642477mm와 feasibility 잔차 8.46e−13m로 교차를 확인했다. 반경은 관통 깊이가 아니다.
step14의 같은 query pair는 cutoff20mm에서 +6.647812mm, cutoff100mm에서 −0.193690mm로
부호가 달라져 false positive였다. 앞선 “0.058초부터 겹침” 설명을 정정했고 onset은 미확정이다.
최종 LP producer는 실제 config/자산/mesh/helper 포함 75개 입력 hash를 실행 전후 검증했다.
Native mask는1/3이며 모든 LH–RH shape 쌍에 공유 bit가 있어 충돌 처리에서 제외된다.
따라서 저장된 양손 contact0과 형상 겹침은 동시에 가능하다. 접촉힘 자체는 계측하지 않았다.

독립 검수 완료. 남은 finding 없음. 원 signed query의 첫 음수와 실제 교차를 구분하며
제어·충돌 설정 변경, onset/침투 깊이/접촉힘 인증은 이번 검사에 포함하지 않는다.

# 손바닥 법선 정렬 제어 비교

이전 소단계는 진행이었다. 저장75pose의 독립 재계산으로 초기 두 면은 거의 평행하지만
tracking0.1초에4.750409°/법선분리40.495078mm임을 확인했다. 평행성만으로 지지가 생기지 않는다.
사용자 자율 진행 지침과 PALM_PLANE_ALIGNMENT_PLAN.md의 후속 비교를 실행한다.

## 비교와 불변 조건

초기각·기타p/q·LA1.1018469719600776m·기존PD·몸통9/오른팔/손가락 목표·root하체
물리 고정·self collision ON·자유 기타/중력/수동strap은 그대로다. Leftarm12의 최종
목표 box는 C02±.3∩native∩새초기각±.15rad다. 66축 연주목표 합성 경로를 유지한다.
초기 source점은 기존distal40%, 목표점은 현재기타blue중앙+50µm이며 간격 목표를 바꾸지 않는다.
새 방향항만 두 면의 outward normal이 마주 보도록 바꾼다. 법선축 twist는 방향항에서
벌점을 주지 않고 연주 PD 목표가 제어한다. 고정/손부착/state 덮어쓰기/인위적 기타힘은 없다.

- [x] 1. 기존 FK14개/response14개 저장pose에서 normal task의6×12 Jacobian과
  첫step 응답을 재계산한다. 초기FK는−task error 미분, PD응답은baseline−changed error다.
  위치3+법선회전2자유도를3-vector로 표현하고 같은orientation scale.08m/rad를 쓴다.
  shortest normal rotation은acos만이 아니라cross/atan2로 방향을 구하며 반대180°의
  모호한 경우를0오차로 처리하지 않는다. heldout와target bounds 및 입력SHA를 검증한다.
- [x] 2. 같은bounds/정규화1e−5에서normal startup bias를 구하고 실제1step 검증한다.
  이 bias는 새 방향 task에 따른 결과이므로 기존 bias와 같다고 가정하지 않는다.
  실제 오차/접촉/기타변화와 예측 차이를 기록한다. 모델 외삽은 성공 인증이 아니다.
- [x] 3. Full-relative/tracking 기준과normal/tracking을 각0.1초로 비교한다.
  startup bias와feedback 방향항이 task에 따라 바뀌는 비교다. 같은gain KP2/KI4,
  damped inverse.01, residual±.15/1rad/s, control60Hz/physics240Hz를 쓴다.
  Full 기준은 이전tracking25states/24contacts/24controls/25tasks/25trace를 재현해야 한다.
  두 면각·법선간격·접선이탈·실제palm contact/rawlambda·기타p/q·몸통/보정포화를 읽는다.
  평행성·접촉 존재·기타변화는 관측값이며 green 계약의 필수 성공조건으로 삼지 않는다.
- [x] 4. 실제 source-normal/palm-up proxy 관측과 이전phase 보존을 확인하고 결과/그림을
  기록하며 독립 검수한다. 미지원이면 후기연장·손가락닫기를 추가하지 않고 다음방향을 정한다.

면 정렬은부드러운목표다. 현재시험은기존안전한초기영역의짧은진단이며 collision/palm-up의
미래 제약 우선순위 전체를 구현했다고 주장하지 않는다. sourcefacet 법선과해부학적 방향,
cooked충돌면·압력·지지력을 구별한다. 실제유효하중/지속지지가 생긴뒤손가락제어를 결합한다.
코드/계획은stability_adapter_2, raw/로그/그림/결과는
`docs/2026-10-12/stability_adapter_2/results/palm_normal_control_v1/`에 새로 저장한다.

## ±.15 결과와 후속 범위 진단

저장 FK/PD 교정과 normal bias 실제1step 계약이 통과했다. Full0.1초는 이전tracking의
raw5배열을exact재현했다. Normal0.1초 point최대오차48.284051mm(Full48.323668mm),
법선각4.800777°(Full4.750409°), 기타5.107730mm/.969008°이며두조건첫4접촉rawlambda0,
이후접촉없음이다. 방향 task교체만으로 유지가 개선됐다고 채택하지 않는다.

사용자 자율진행 지침과 PALM_SIDE_FEEDBACK_PLAN.md의 미실행 범위진단을 이어서 수행한다.
초기q/C02초기box/기타p/q/LA/PD/나머지목표는 유지한다. runtime 최종leftarm target만
initial±.3rad, ±.5rad∩native로 각각 확대해 같은normal 응답행렬에서bias를 재계산한다.
이는 초기각 탐색box를 변경하는 것이 아니다. startup bias만 실제1step을 검증하고,
실제오차/접촉/기타변화/정상성을 읽은뒤각각0.1초 여부를 결정한다. source gap50µm와
controller residual±.15/1rad/s는유지한다. 범위변경과orientation 비교를분리해보고한다.
과거 ±.15 producer/원자료는 byte사본으로보존한다. 이짧은진단을성공기준으로정의하지않는다.

## 결과와 다음 작은 단위

Runtime±.3/.5의첫step 실제point오차는0.085002/0.100337mm였다. 작은±.03 응답의
선형예측은0.000044/0.000026mm로 실제와 차이가 커 stationary/전범위 모델로 인증하지 않는다.
0.1초의point최대오차는±.3에서12.186877mm/법선각1.280689°, ±.5에서11.963341mm/
1.434722°다. 종료source 법선간격은11.864499/11.336725mm, 접선이탈은2.989581/
3.966279mm다. 모두step1~2의7palm rows/rawlambda0이고이후접촉은없다.
네조건기타body states는exact이며최대5.107730mm/.969008°다. 유지/연주성공이아니다.
±.3은범위가작고면각/접선이탈이작아다음진단의기준으로남긴다. ±.5의point-only
차이0.223536mm를두오차동시개선으로해석하지않는다. 기존finger/초기후보는보존한다.
실제Gym camera의±.3 초기/0.1초재현은headless의raw6배열과exact다.
이번실행8nativeinit/123physicsstep이고저장자료교정/후처리는각0/0다.

초기와첫step에서는가까운데0.1초에법선분리가자라므로다음에는기준±.3 startupbias
주변의작은PD목표probe를같은0.1초까지실행해유한시간응답을측정한다. 초기q/기타/
strap/PD/관절box는유지한다. 목표보정의첫step행렬을장기응답으로가정하지않고,
작은bias보정후실제첫step과0.1초를각각검증한다. 기존normalfeedback와합성효과를
분리하며contact/rawlambda/기타p/q/관절·몸통drift를같이읽는다. 먼저source법선분리를
줄이는것을확인하고손가락/후기연장/학습을한꺼번에추가하지않는다.
절대strap도새초기route1.080474113m에비해약21.373mm slack이남아초기길이후속
비교가필요하다. 이번control비교에서는LA를고정했고이후길이후보는별도소단계로측정한다.

## 사용자 정정: 평행성보다 실제 지지를 우선

손바닥과 파란 넥 면은 반드시 평행할 필요가 없다. 평행에 가까운 방향은 넥을
지지하기 위한 부드러운 선호이며, 접촉을 유지하고 기타의 초기 위치·회전 이탈을
줄이는 것이 목적이다. 지지에 도움이 되는 기울기를 허용한다. 각도 오차가 작다는
이유만으로 후보를 채택하거나, 더 기울었다는 이유만으로 지지 후보를 탈락시키지 않는다.

다음 비교에서는 실제 손바닥 접촉의 지속·하중 전달 여부와 기타 이동·회전을 먼저
읽고, 면각·source gap·목표 영역 내 위치는 보조 진단으로 읽는다. 한 프레임의 접촉
행이나 source 면의 평행성만으로 유효 지지를 판정하지 않는다. 관통 방지·관절 한계·
왼손 palm-up 조건은 유지한다.

현재 normal task는 .08m/rad 가중 오차를 줄이는 방식이며 정확한 평행을 강제하는
hard constraint는 없다. 다만 접촉·기타 안정화를 방향항보다 우선하는 제어 구조가
이미 구현됐다고 주장하지 않는다. 다음 구현에서는 위치 접근을 방해하는 방향 보정의
비중을 낮추는 별도 비교를 계획하고, 고정된 허용각이나 새 가중치는 측정 전에 확정하지
않는다. 같은 초기각·strap 조건에서 실제 지지가 좋아지는지 검증한 뒤 정한다.
이번 정정은 설계 우선순위의 명시이며 기존 controller 수치·원자료·그림은 변경하지 않았다.

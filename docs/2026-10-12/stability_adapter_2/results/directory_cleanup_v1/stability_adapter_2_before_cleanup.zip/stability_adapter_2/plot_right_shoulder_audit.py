"""Plot saved right-shoulder source audit and contacts; does not run native physics."""
import argparse
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def read_json(path):
    return json.loads(path.read_text())


def plot_distances(audit, alignment, reference_contacts, candidate_contacts, output):
    steps = (0, 2, 3, 4, 24)
    colors = {"reference": "#475569", "candidate_01": "#dc2626"}
    fig, axes = plt.subplots(2, 1, figsize=(11.5, 8.2), gridspec_kw={"height_ratios": [1, 1.1]})
    for name in colors:
        rows = [r for r in audit["rows"] if r["name"] == name and
                r["human_body"] == "R_Shoulder" and r["guitar_body"] == "G:body"]
        rows.sort(key=lambda r: r["physics_step"])
        if tuple(r["physics_step"] for r in rows) != steps:
            raise ValueError(f"expected five saved states for {name}")
        axes[0].plot([r["time_s"] for r in rows],
                     [r["closest"]["source_hull_distance_m"] * 1000 for r in rows],
                     color=colors[name], marker="o", lw=1.8, label=name)
    axes[0].set(title="R_Shoulder–G:body source-hull distance at five saved states",
                ylabel="Unsigned source-hull distance (mm)", xlabel="Saved state time (s)")
    axes[0].grid(True, alpha=.25)
    axes[0].legend(frameon=False)

    rows = alignment["rows"]
    x = np.array([r["contact_step"] for r in rows], dtype=float)
    native = np.array([r["native_initialOverlap_m"] for r in rows]) * 1000
    previous = np.array([r["source_previous_signed_gap_m"] for r in rows]) * 1000
    same = np.array([r["source_same_step_signed_gap_m"] for r in rows]) * 1000
    axes[1].plot(x, native, "o", markerfacecolor="none", markeredgecolor="#b91c1c",
                 mew=1.7, ms=9, linestyle="none", zorder=5,
                 label="Native initialOverlap raw field (2 rows)")
    axes[1].plot(x, previous, "D", color="#0284c7", label="Source signed gap at preceding saved state")
    axes[1].plot(x, same, "s", color="#7c3aed", label="Source signed gap at same-numbered saved state")
    for i, row in enumerate(rows):
        axes[1].annotate(f"step {row['contact_step']}", (x[i], native[i]), xytext=(5, 7),
                         textcoords="offset points", fontsize=8)
    axes[1].axhline(0, color="#111827", lw=.8)
    axes[1].set(title="Only two observed shoulder contact rows; source/native field alignment",
                xlabel="Native contact physics step", ylabel="Signed values (mm; field semantics differ)")
    axes[1].grid(True, alpha=.25)
    axes[1].legend(frameon=False, fontsize=8, loc="best")
    fig.suptitle("Recorded right-shoulder audit — sampled source geometry and observed rows", fontsize=13)
    fig.text(.5, .012,
             "Top: five discrete saved states, not a continuous trace. Bottom: native initialOverlap is a raw contact field; "
             "source signed gap is a source-query value. Matching is shown only for the two specified samples; "
             "no general cooked-geometry or penetration-depth claim.", ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .055, 1, .95), h_pad=1.3)
    if output.exists():
        raise FileExistsError(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=165, bbox_inches="tight")
    plt.close(fig)


def _focus(shape):
    if shape["actor"] == "guitar":
        return shape["body"] in {"G:body", "guitar"}
    return shape["body"] in {"R_Shoulder", "RH:palm", "R_Elbow", "R_Wrist"}


def plot_initial_geometry(rows, output):
    import stability_adapter_2.environment  # Gym before MuJoCo
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection
    from stability_adapter_2.plot_physx_contacts import source_surfaces
    from stability_adapter_2.replay_contact_geometry import recorded_probe

    panels = []
    bound_points = []
    for name in ("reference", "candidate_01"):
        audit_row_shoulder = next(r for r in rows if r["name"] == name and r["physics_step"] == 0 and
                                  r["human_body"] == "R_Shoulder" and r["guitar_body"] == "G:body")
        audit_row_palm = next(r for r in rows if r["name"] == name and r["physics_step"] == 0 and
                              r["human_body"] == "RH:palm" and r["guitar_body"] == "G:body")
        run = Path(audit_row_shoulder["run"])
        model, data, shapes = recorded_probe(run, 0)
        surfaces, _, _, _ = source_surfaces(model, data, shapes)
        focused = [(triangles, shape) for triangles, shape in surfaces if _focus(shape)]
        witnesses = [np.asarray(audit_row_shoulder["closest"]["hull_witness_points_m"]),
                     np.asarray(audit_row_palm["closest"]["hull_witness_points_m"])]
        panels.append((name, focused, witnesses, audit_row_shoulder, audit_row_palm))
        bound_points.extend([tri.reshape(-1, 3) for tri, _ in focused])
        bound_points.extend(witnesses)
    all_points = np.concatenate(bound_points)
    center = (all_points.min(0) + all_points.max(0)) / 2
    half = max(float(np.ptp(all_points, axis=0).max()) / 2 + .025, .06)
    fig = plt.figure(figsize=(13.2, 6.6))
    for i, (name, surfaces, witnesses, shoulder, palm) in enumerate(panels, 1):
        ax = fig.add_subplot(1, 2, i, projection="3d")
        for triangles, shape in surfaces:
            if shape["actor"] == "guitar":
                color = "#2563eb"
            elif shape["body"] == "R_Shoulder":
                color = "#f97316"
            elif shape["body"] == "RH:palm":
                color = "#16a34a"
            else:
                color = "#a8b0bb"
            ax.add_collection3d(Poly3DCollection(triangles, facecolors=color, alpha=.62, edgecolors="none"))
        labels = (("R_Shoulder / G:body", "#f97316"), ("RH:palm / G:body", "#16a34a"))
        for witness, (label, color) in zip(witnesses, labels):
            ax.plot(witness[:, 0], witness[:, 1], witness[:, 2], color=color, marker="o", ms=4, lw=2,
                    label=f"{label} witness")
        ax.set(xlim=(center[0]-half, center[0]+half), ylim=(center[1]-half, center[1]+half),
               zlim=(center[2]-half, center[2]+half), xlabel="World X (m)",
               ylabel="World Y (m)", zlabel="World Z (m)")
        ax.set_box_aspect((1, 1, 1))
        ax.view_init(elev=20, azim=116)
        ax.set_title(f"{name} initial source geometry\nShoulder/G:body {shoulder['closest']['source_hull_distance_m']*1000:.3f} mm; "
                     f"RH palm/G:body {palm['closest']['source_hull_distance_m']*1000:.3f} mm")
        if i == 1:
            ax.legend(loc="upper left", fontsize=7, frameon=False)
    fig.suptitle("Reference and candidate initial source-shape reconstruction", fontsize=13)
    fig.text(.5, .014,
             "Orange: R_Shoulder | green: RH palm | blue: guitar body/neck | gray: nearby right arm. "
             "Same bounds and view; reconstructed from source collision shapes, not native renderer or a clearance certificate.",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .05, 1, .94), w_pad=.7)
    if output.exists():
        raise FileExistsError(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=155, bbox_inches="tight")
    plt.close(fig)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def geometry_assets():
    root = Path(__file__).resolve().parents[1]
    config_path = Path(__file__).with_name("config.json").resolve()
    config = read_json(config_path)
    paths = {config_path}
    for key in ("humanoid_asset", "guitar_asset"):
        xml = (root / config[key]).resolve()
        paths.add(xml)
        compiler = ET.parse(xml).getroot().find("compiler")
        mesh_dir = xml.parent / (compiler.get("meshdir", "") if compiler is not None else "")
        for mesh in ET.parse(xml).getroot().findall("./asset/mesh"):
            paths.add((mesh_dir / mesh.attrib["file"]).resolve())
    return sorted(p for p in paths if p.is_file())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    images = args.out_dir / "images"
    manifest = args.out_dir / "plot_manifest.json"
    if images.exists() or manifest.exists():
        raise FileExistsError(f"preserve existing outputs: {images}, {manifest}")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    audit_path = args.results_dir / "audit_v2.json"
    align_path = args.results_dir / "contact_alignment.json"
    audit = read_json(audit_path)
    if len(audit["rows"]) != 100 or not all(audit["checks"].values()):
        raise ValueError("audit_v2 must contain 100 rows with all checks passing")
    ref = args.results_dir.parent / "right_support_v1/short/reference"
    candidate = args.results_dir.parent / "right_support_v1/short/candidate_01"
    alignment = read_json(align_path)
    plot_distances(audit, alignment, read_json(ref / "contacts.json"),
                   read_json(candidate / "contacts.json"), images / "right_shoulder_audit_samples.png")
    plot_initial_geometry(audit["rows"], images / "right_shoulder_audit_initial_geometry.png")
    run_inputs = [p / fname for p in (ref, candidate) for fname in
                  ("report.json", "trace.json", "states.json", "contacts.json")]
    raw_inputs = [audit_path, align_path, args.results_dir / "audit.json"] + run_inputs
    helper_names = ("plot_right_shoulder_audit.py", "audit_right_shoulder.py", "search_hand_support.py",
                    "replay_contact_geometry.py", "plot_physx_contacts.py", "initial_overlap.py", "environment.py",
                    "trial_settings.py")
    helpers = [Path(__file__).with_name(n).resolve() for n in helper_names]
    manifest_payload = {
        "purpose": "read-only figures from source-query audit and already-saved native runs; no native execution",
        "input_sha256": {str(p.resolve()): sha256(p) for p in raw_inputs if p.is_file()},
        "helper_sha256": {str(p): sha256(p) for p in helpers if p.is_file()},
        "geometry_assets_sha256": {str(p): sha256(p) for p in geometry_assets()},
        "geometry_asset_count_including_config": len(geometry_assets()),
        "outputs_sha256": {str(p.resolve()): sha256(p) for p in sorted(images.glob("*.png"))},
    }
    manifest.write_text(json.dumps(manifest_payload, indent=2) + "\n")


if __name__ == "__main__":
    main()

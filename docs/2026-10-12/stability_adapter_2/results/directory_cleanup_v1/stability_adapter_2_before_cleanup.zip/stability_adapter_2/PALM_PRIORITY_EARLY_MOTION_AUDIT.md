# 초기source근접과actual옆면지지미달의 첫프레임 분리계측

새actual5초는최대26.091583mm/7.937143°로직전25.779645mm/7.800837°보다악화했다. Sourcepalm patch gap.421670mm에도native양λpalmfeature는요청patch에서23.270465~23.724753mm멀고근접행0이었다. 반면thumb후면근접793고유step/last1200, middle전면1052/last1200은생겼다. Source평면근접만으로지지성공을선언하거나다시무작위각검색을늘리지않는다.

저장자료만읽어steps0/1/4/8/12/24/60/120/240/1200의palm sourceanchor/world·G 좌표/finitepatch거리구간과실제bodyorientation/up을계측한다. anchor변위는Chest자세변화의기여와Chest기준팔chain변화의기여로vector를정확히분해한다. 두vector합=actualworld변위를검사하고norm의합을전체변위로설명하지않는다. G자체의이동/회전은별도로기록한다. actual q−oldPDtarget와nativepalmcontact최초step도대조한다.

Source초기간격이첫step부터커지는지,몸통/팔의실제변위와source/cooked접촉차이중어떤증거가있는지에따라유지제어/초기설정의다음변경을선택한다. 새로운bodygain/controller를측정전에임의추가하지않는다. Cooked geometry표면을조회한것이아니므로지지/관통인증을하지않는다. runtimeG좌표와고정worldgoal을구분한다.

- [ ] 저장nativepoint/거리interval·정확vector분해/SDKearly시점
- [ ] 실제영상/곡선·설명과다음유지제어단계

새physics0, 원source/actual결과를보존한다. 구현은stability_adapter_2, 결과는既存의아직봉인하지않은palm_patch_priority_diagnostic_v1새파일에저장한다. Native video에는기존StrapTrialRecording이연결됐고기타free/root하체fixed/몸통9oldtarget/최종66권한을유지한다.

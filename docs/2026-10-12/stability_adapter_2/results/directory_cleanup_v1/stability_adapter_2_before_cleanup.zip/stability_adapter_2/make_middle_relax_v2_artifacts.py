"""Plot three frozen native joint series and 1-second maxima; no simulation calls."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import shutil

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / 'docs/2026-10-12/stability_adapter_2/results/fixed_strap_middle_relax_v2'
A = ROOT / 'stability_adapter_2'
NATIVE = P / 'native'
LABELS = ['baseline', 'middle3_minus005', 'middle3_minus015']
DISPLAY = {
    'baseline': 'Baseline',
    'middle3_minus005': 'Middle3 −0.05 rad',
    'middle3_minus015': 'Middle3 −0.15 rad',
}
COLORS = {'baseline': '#4C78A8', 'middle3_minus005': '#F58518', 'middle3_minus015': '#54A24B'}
DECISION = A / 'FIXED_STRAP_MIDDLE_RELAX_V2_DECISION.md'
PLAN = A / 'FIXED_STRAP_MIDDLE_RELAX_V2_PLAN.md'
ANALYZER = A / 'analyze_fixed_strap_middle_relax_v2.py'
MEDIA = [
    NATIVE / 'frames/hands/00000.png', NATIVE / 'frames/hands/00150.png',
    NATIVE / 'hands.mp4', NATIVE / 'whole_body.mp4',
]
EXTRA_FILES = [
    P / 'analysis.json', P / 'joint_series.jsonl', P / 'windows.jsonl',
    P / 'analysis_execution.json', P / 'native_execution.json', P / 'native.log',
    P / 'native/videos.json', P / 'native/attempt.json', P / 'native/tasks.jsonl',
    DECISION, PLAN, ANALYZER,
    Path('/tmp/run_fixed_strap_middle_analysis_v2.py'),
    A / 'run_fixed_strap_middle_relax_v2_phase.py',
] + MEDIA


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read_rows(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()]


def archive_path(path, destination):
    path = Path(path).resolve()
    try:
        rel = path.relative_to(ROOT)
        return destination / 'repo' / rel
    except ValueError:
        return destination / 'external' / Path(*path.parts[1:])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out-dir', required=True)
    args = parser.parse_args()
    out = Path(args.out_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    figure = out / 'middle_relax_v2_native_summary.png'
    manifest_path = out / 'artifact_manifest.json'
    snapshot_path = out / 'source_snapshot.json'
    wrapper = out / 'run_producer.sh'
    if any(p.exists() for p in (figure, manifest_path, snapshot_path, out / 'source_snapshot', out / 'producer_execution.json')):
        raise SystemExit('refusing to overwrite prior artifact evidence')

    analysis = json.loads((P / 'analysis.json').read_text())
    checks = analysis.get('checks', {})
    if len(checks) != 31 or not all(checks.values()):
        raise RuntimeError('expected exactly 31 passing analysis checks')
    if analysis.get('input_sha256_before') != analysis.get('input_sha256_after'):
        raise RuntimeError('analysis input hashes differ before/after')
    expected_sources = analysis['input_sha256_before']
    if len(expected_sources) != 39:
        raise RuntimeError('expected exactly 39 analysis input hashes')
    summary = {row['label']: row for row in analysis['summary']}
    if list(summary) != LABELS:
        raise RuntimeError('unexpected condition order in analysis summary')

    paths = {Path(p) for p in expected_sources}
    paths.update(EXTRA_FILES)
    paths.update([Path(__file__).resolve(), wrapper])
    paths = sorted((p.resolve() for p in paths), key=str)
    before = {str(path): sha(path) for path in paths}
    for path, expected_sha in expected_sources.items():
        if before.get(path) != expected_sha:
            raise RuntimeError('current source differs from analysis SHA: ' + path)

    snapshot_root = out / 'source_snapshot'
    records = []
    for path in paths:
        copied = archive_path(path, snapshot_root)
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, copied)
        digest = sha(path)
        if sha(copied) != digest:
            raise RuntimeError('source archive SHA mismatch: ' + str(path))
        records.append({'original_path': str(path), 'copy_path': str(copied), 'sha256': digest})
    snapshot_path.write_text(json.dumps({'files': records}, indent=2) + '\n')

    joint_rows = read_rows(P / 'joint_series.jsonl')
    window_rows = read_rows(P / 'windows.jsonl')
    if len(joint_rows) != 3 * 1201 or len(window_rows) != 3 * 121:
        raise RuntimeError('unexpected three-condition series/window counts')
    series = {}
    windows_by_label = {}
    for label in LABELS:
        rows = [row for row in joint_rows if row['label'] == label]
        if len(rows) != 1201 or [row['physics_step'] for row in rows] != list(range(1201)):
            raise RuntimeError('joint series incomplete or unordered: ' + label)
        if any(not math.isclose(row['time_s'], row['physics_step'] / 240.0, rel_tol=0.0, abs_tol=1e-12) for row in rows):
            raise RuntimeError('joint-series clock mismatch: ' + label)
        goal = float(summary[label]['middle3_goal_deg'])
        if any(not math.isclose(row['middle3_held_goal_deg'], goal, rel_tol=0.0, abs_tol=1e-9) for row in rows):
            raise RuntimeError('held target mismatch: ' + label)
        if not math.isclose(rows[-1]['middle3_actual_deg'], summary[label]['middle3_actual_samples_deg']['5.0'], rel_tol=0.0, abs_tol=1e-9):
            raise RuntimeError('5-second actual angle differs from summary: ' + label)
        series[label] = rows
        local_windows = [row for row in window_rows if row['label'] == label]
        if len(local_windows) != 121:
            raise RuntimeError('unexpected rolling window count: ' + label)
        pass_count = sum(bool(row['within_provisional_limits']) for row in local_windows)
        if pass_count != summary[label]['windows_within_provisional_limits']:
            raise RuntimeError('window pass count differs from summary: ' + label)
        max_position = max(row['max_position_change_mm'] for row in local_windows)
        max_rotation = max(row['max_rotation_change_deg'] for row in local_windows)
        if not math.isclose(max_position, summary[label]['max_1s_position_change_mm'], rel_tol=0.0, abs_tol=1e-12):
            raise RuntimeError('window position maximum differs from summary: ' + label)
        if not math.isclose(max_rotation, summary[label]['max_1s_rotation_change_deg'], rel_tol=0.0, abs_tol=1e-12):
            raise RuntimeError('window rotation maximum differs from summary: ' + label)
        windows_by_label[label] = local_windows

    fig, (ax_series, ax_bars) = plt.subplots(1, 2, figsize=(14.4, 6.8), gridspec_kw={'width_ratios': [1.25, 1.0]})
    for label in LABELS:
        rows = series[label]
        times = np.asarray([row['time_s'] for row in rows])
        actual = np.asarray([row['middle3_actual_deg'] for row in rows])
        goal = float(summary[label]['middle3_goal_deg'])
        color = COLORS[label]
        ax_series.plot(times, actual, color=color, linewidth=1.7, label=DISPLAY[label])
        ax_series.axhline(goal, color=color, linestyle='--', linewidth=1.2, alpha=0.78)
    ax_series.set_xlim(0.0, 5.0)
    ax_series.set_xticks(np.arange(0.0, 5.01, 1.0))
    ax_series.set_xlabel('simulation time (s)')
    ax_series.set_ylabel('middle3 scalar joint angle (deg)')
    ax_series.set_title('Middle3 actual angle and held goals', loc='left', fontweight='bold')
    ax_series.grid(alpha=0.22)
    ax_series.legend(loc='center right', fontsize=8, frameon=True, title='actual')

    entries = [
        ('position', 'baseline', 'max_1s_position_change_mm', 5.0, 'mm'),
        ('position', 'middle3_minus005', 'max_1s_position_change_mm', 5.0, 'mm'),
        ('position', 'middle3_minus015', 'max_1s_position_change_mm', 5.0, 'mm'),
        ('rotation', 'baseline', 'max_1s_rotation_change_deg', 1.0, '°'),
        ('rotation', 'middle3_minus005', 'max_1s_rotation_change_deg', 1.0, '°'),
        ('rotation', 'middle3_minus015', 'max_1s_rotation_change_deg', 1.0, '°'),
    ]
    y_positions = [5.0, 4.1, 3.2, 1.7, 0.8, -0.1]
    fractions = []
    for (_, label, key, limit, unit), y in zip(entries, y_positions):
        value = float(summary[label][key])
        fraction = value / limit
        fractions.append(fraction)
        ax_bars.barh(y, fraction, height=0.58, color=COLORS[label])
        ax_bars.text(fraction + 0.025, y, '{:.3f} {}'.format(value, unit), va='center', fontsize=8)
    ax_bars.axvline(1.0, color='#333333', linestyle='--', linewidth=1.2)
    ax_bars.axhline(2.45, color='#999999', linewidth=0.8)
    ax_bars.set_yticks(y_positions, [DISPLAY[label] for _, label, _, _, _ in entries])
    ax_bars.set_xlim(0.0, max(1.1, max(fractions) + 0.18))
    ax_bars.set_ylim(-0.65, 6.0)
    ax_bars.set_xlabel('fraction of provisional limit')
    ax_bars.set_title('Rolling 1 s maximum change', loc='left', fontweight='bold')
    ax_bars.grid(axis='x', alpha=0.22)
    ax_bars.set_axisbelow(True)
    ax_bars.text(0.02, 5.56, 'Position · limit 5 mm', fontsize=8)
    ax_bars.text(0.02, 2.12, 'Rotation · limit 1°', fontsize=8)

    fig.suptitle('Fixed-strap middle3 target response · three saved native conditions', fontsize=14, y=0.98)
    fig.text(0.5, 0.055, 'Left solid curves = actual middle3 angle; dashed lines = held targets. Right dashed line = provisional threshold.', ha='center', fontsize=9)
    fig.text(0.5, 0.032, '1 s windows: 241 samples, starts 2.000–4.000 s at 60 Hz (121 starts per condition).', ha='center', fontsize=9)
    fig.text(0.5, 0.009, 'Saved observations against provisional limits; no naturalness or playing-success certification.', ha='center', fontsize=9)
    fig.tight_layout(rect=(0.02, 0.105, 0.98, 0.93), w_pad=2.0)
    fig.savefig(figure, dpi=220, bbox_inches='tight')
    plt.close(fig)

    after = {str(path): sha(path) for path in paths}
    if before != after:
        raise RuntimeError('input SHA changed during artifact generation')
    outputs = {figure.name: sha(figure)}
    manifest = {
        'producer_sha256_before': before[str(Path(__file__).resolve())],
        'producer_sha256_after': after[str(Path(__file__).resolve())],
        'inputs_sha256_before': before,
        'inputs_sha256_after': after,
        'outputs_sha256': outputs,
        'native_initializations_during_artifact': 0,
        'physics_steps_during_artifact': 0,
        'actor_inference_calls_during_artifact': 0,
        'training_updates_during_artifact': 0,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'figure': str(figure), 'sha256': outputs[figure.name], 'input_count': len(before), 'series_rows': len(joint_rows), 'window_rows': len(window_rows)}))


if __name__ == '__main__':
    main()

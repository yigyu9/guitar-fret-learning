# 파란 넥 측면의 왼손 손바닥 지지

2026-10-07 사용자 정정: 왼손 손바닥이
`docs/2026-10-12/visualizations/grip_proposal/front.png`의 파란 영역에 닿아야 한다.
이는 넥의 아래쪽 측면이며 녹색 정면의 손가락 접촉과 구별한다.
이전 1초 실행은 LH:palm–기타 접촉 0으로 이 조건을 충족하지 못했다.
엄지 추가보다 손바닥 지지 확보를 먼저 진행한다.

## 조건과 제어권

root·하체 물리 고정, Torso/Spine/Chest 9 초기 목표·PD, 주요 상지 66 구조,
humanoid 내부 충돌, 자유 기타·중력·수동 strap을 유지한다. 기타 초기 p/q는
이전 +5mm 및 near2µm 생성 이동까지 포함한 기준을 그대로 쓴다.
첫 배치 비교에서는 손가락을 편 `curl_0` 자세와 절대 LA 1.1018469719600776m를
유지해 손바닥 위치 문제부터 분리한다. 기존 finger seed/실행/문서는 보존한다.
양팔의 초기각 탐색 범위는 모델 hard limit ∩ C02 기준 ±0.3rad로 시작한다.
왼쪽 12 arm을 먼저 사용하며 오른팔·몸통·손가락 초기각은 바꾸지 않는다.
모델 한계와 최소 palm-up 반구 조건을 유지한다. 상태 강제 부착/덮어쓰기는 없다.

## 작은 실행 단위

1. 초기화-only 감사: 사용자 그림의 `geometry.json`에 있는 `regions_G_m.palm`
   다각형을 현재 native 기타 body frame으로 변환한다. 손바닥 source convex hull의
   중심·palmar 방향 proxy·표면점과 목표 영역까지의 거리/방향을 측정한다.
   링크 원점과 형상 표면을 구별하고 원본·source·native frame 대응을 기록한다.
2. Native 초기 자세에서 얻은 calibrated arm spherical FK로 제한된 초기각 후보를
   구한다. palmar 표면점의 파란 측면 접근과 방향을 같이 평가한다.
   source human–guitar 및 양손 교차 후보는 거절하고 fresh native FK로 대조한다.
   정적 source gap을 실제 PhysX 접촉/관통 깊이로 인정하지 않는다.
3. fresh native/source 검사를 통과한 소수 후보만 0.1초 물리 시험한다.
   LH:palm contact body pair·양의 raw lambda·기타 p/q 오차·팔/몸통 drift와
   명령의 state 불변성을 확인한다. 지지 없는 후보를 안정 자세로 채택하지 않는다.
   이후 손바닥 접촉을 유지하는 bounded 목표 보정과 손가락 grip을 단계적으로 결합한다.
4. 실제 Gym camera 이미지와 측면 목표 overlay를 결과에 저장한다.
   Overlay는 목표 표시이며 실제 접촉 증거는 native contact 기록으로 구분한다.

실험·로그·미디어·결과는 `docs/2026-10-12/stability_adapter_2/results/palm_neck_side_v1/`에,
구현과 설정은 `stability_adapter_2/`에 저장한다. 이전 goal turn은 접촉 0과 사용자
파란 측면 좌표를 확인해 다음 목표를 바꾼 증거 획득 단계였다. 정지 안정화 목표는
미완성이므로 active goal을 유지한다. 중단/성공 기준을 새로 확정하지 않는다.

- [x] 초기 surface/target 감사
- [x] 제한된 FK 후보와 fresh native 확인
- [x] 짧은 실제 손바닥 접촉 비교
- [x] 이미지·문서·독립 검수

초기 감사: 손바닥 source hull과 파란 영역 최소 거리는77.049519mm이고,
중앙 palmar ray 표면점의 목표 중앙 이동은약136.66mm다. 기존 손바닥은
G y≈−.079m, 파란 영역 중앙은y≈+.064m로 다른 넥 구간이다.
FK4후보는 목표 표면점/방향을 맞췄지만 기존 all-vertex proxy에서는 교차로 거절됐다.

후속 진단 결정: neck1/neck2 OBJ는전체12vertex 배열이같지만 face에서쓴8점은
넥과헤드로서로다르다. 기존geometry helper는사용하지않는점까지hull에넣는다.
이를원본/과거기록에서고치거나지우지않고별도의face-referenced source geometry
측정을추가한다. 사용된면기준clear도PhysX cooked-clear로인증하지않는다.
SDK공개API에cooked rigid convex vertices 조회가없다는설치본조사결과를기록하고,
실제native초기FK/접촉/첫step변화를대조해구분한다. 무관통초기화채택은보류한다.
실제계산helperSHA누락은과거raw/producer보존뒤helper chain을추가한새audit로
해결한다. 이전생산시점에없었던SHA를소급해서증명했다고표현하지않는다.

Face-referenced 감사에서 clear1/3mm는실제사용면proxy에도palm교차가남아제외했다.
clear6/10mm는human–guitar/양손source교차0,파란영역최소gap2.7824/6.7823mm다.
초기ray중앙clearance와가장가까운hullgap은다르다. 두후보freshnativeFK는
현재기타p/q와몸통/손가락/오른팔초기각·PD를유지한채일치했다.

Thorax이동후auto-rest-length는같은LA가아니므로null을유지하지않고새settings
사본에절대LA1.1018469719600776m를명시했다. 첫freshprobe는LA계약에서0step
거절됐고다음JSON numpybool 기록실패도0step이었다. 로그/producer/실패metadata를
보존했으며실패때보존되지않은rawstate를소급해서복원했다고주장하지않는다.
두실패뒤fresh_native_v3는모든초기화계약을통과했다.

다음1step진단:두face-clear후보만같은자세/LA에서물리1step을실행해
LH:palm contact의존재·signed min_dist field·기타변화·passivestrap상태를읽는다.
공개SDK에cookedvertexquery가없어이는실제접촉대조이지시작무관통인증은아니다.
첫step에큰guitar변화/깊은접촉후보가나오면24step연장을하지않고
private cleaned-mesh 또는목표접근방식의필요성을분리검토한다.

파란면과 palm의 넓은 palmar convex facet(772.75mm²)을 정렬하는 source 탐색을
추가했다. 200/50/10µm 양의 gap은 palm에는 교차가 없지만 L_Wrist–neck source
교차 공통구 반경 약1.09~1.17mm가 있어 실제 물리 시험으로 넘기지 않았다.
다음에는 파란면 중앙/50µm gap과 palmar normal을 유지하고 normal 주위 ±0.15,
±0.3rad twist만 비교한다. 기존 C02 arm12 box, 기타/몸통/오른팔/손가락/LA는 유지한다.
Wrist 교차를 없애는 방향 자유도를 사용하며 허용 box는 확장하지 않는다.

겹침 LP가 분리된 hull에서 infeasible을 HiGHS unknown으로 반환했다. 원본 helper는
보존하고 새 helper만 overlap-AABB 중심의 mm 단위, coplanar 중복planes 제거,
signed 공통구 radius(음수 해를 최종0으로 clip)로 계산했다. 실패3버전과 진단로그를
보존했다. 알려진 cube 겹침/분리/접선/10µm overlap 및 큰 평행이동10case와
기존 well-conditioned LP3case 대조가 통과했다. 이는 source 형상 수치 검증이다.

normal 주위 twist만으로는 wrist 교차가 남는다. 파란 영역의 중앙에 접하는 palm
점은 palmar facet 중앙일 필요가 없다. 같은 facet 내부에서 wrist 반대 방향의
vertex까지 선분의40% 지점을 새 접촉 목표점으로 사용한다. convex facet 내부점이며
손가락 대신 손바닥 면을 사용한다. 기타 목표/파란영역/50µm gap/normal/관절box는
유지하고 접촉할 palm 위치만 바꾼다. 실제 겹침 gate를 통과하기 전 물리를 진행하지 않는다.

Distal40% 후보는 source human–guitar/양손 교차0, fresh native FK 최대 위치오차
0.000151mm/회전오차4.11e−7rad, 기타/비대상 초기각/PD/절대LA 계약을 통과했다.
첫1step에서 LH:palm–guitar native manifold4점이 관측됐으나 raw lambda는 모두0이다.
첫 기타 변화는0.016300mm/0.003208°로 작다. source gap은fresh에서0.049807mm.
실제 contact point 중 파란patch 범위에 있는 점을 별도로 표시하며 lambda0을
하중 지지로 표현하지 않는다. SDKinitialOverlap/minDist를 관통 깊이로 단정하지 않는다.
같은 고정 목표/PD/LA 후보를24step(0.1초)까지만 연장해 유효 접촉 지속을 읽는다.
새 PI/preload/finger controller는 이 단계에서 추가하지 않는다.

## 이번 소단계 검증 결과와 다음 제어

- [x] 초기 surface/target 감사 — 기존 손바닥 source gap77.049519mm
- [x] 제한된 FK 후보와 fresh native 확인 — distal40% 내부점 후보, source교차0
- [x] 짧은 실제 손바닥 접촉 비교 — 첫step4manifold/lambda0, step2~24접촉0
- [x] 이미지·문서·독립 검수 — 실제 Gym 비교 이미지·13검사 통과, 독립검수 미해결 지적 없음

같은 fresh24step 시험은 첫1step의 state/trace/contact prefix를 정확히 재현했다.
0.1초 최대 기타 이탈5.107730mm/0.969008°이며 접촉 유지에 실패했다.
별도0step baseline camera를 포함한 이번 phase는 native초기화11회/물리27step이다.
Source-only 계산 실패3버전과 LP진단 중단/CLI인수실패는0native/0physics로 구별한다.
모든 fresh 계약은 통과했지만 cooked 무관통 인증·하중지지·기타 정지안정 성공이 아니다.

다음 소단계는 이 새 초기각에 맞는 실제 native arm FK Jacobian을 먼저 측정하고,
연주 목표와 합성되는 bounded 목표각 보정으로 palm의 파란면 이탈을 줄이는 것이다.
이전 자세의 preload/Jacobian을 그대로 재사용하지 않는다. 그 다음 손가락 grip을
결합한다. 이번 단계에서는 새 제어/gain/strap 길이를 적용하지 않았다.
원본 모델·stability_adapter·이전 산출물은 보존한다.

"""Plot saved hip-drive fixture traces; does not run the simulator."""
import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt


DRIVE_LABELS = {"position": "Position", "off": "Drive off", "effort": "Effort"}
DRIVE_COLORS = {"position": "#d97706", "off": "#2563a6", "effort": "#16803c"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="hip_drive_probe_v4/report.json")
    parser.add_argument("--output", type=Path, required=True, help="PNG output path")
    args = parser.parse_args()
    report = json.loads(args.input.read_text())
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.8), sharey=True)

    for ax, wide in zip(axes, (False, True)):
        for drive in ("position", "off", "effort"):
            row = next(r for r in report["rows"]
                       if r["dof_count"] == 3 and r["initial_x_deg"] == -90.0
                       and r["wide_limits"] is wide and r["drive"] == drive)
            y_index = row["joint_names"].index("L_Hip_y")
            target = row["initial_targets_rad"][y_index]
            times = [sample["physics_step"] / report["physics_hz"] for sample in row["trace"]]
            delta_deg = [(sample["dofs"][y_index]["pos"] - target) * 180 / 3.141592653589793
                         for sample in row["trace"]]
            ax.plot(times, delta_deg, color=DRIVE_COLORS[drive], lw=1.8,
                    label=f"{DRIVE_LABELS[drive]} (3-axis max {row['max_raw_target_deviation_deg']:.6f}°)")
        ax.axhline(0, color="#222", lw=.8)
        ax.set_title("Wide ±180° bounds" if wide else "Authored bounds")
        ax.set_xlabel("Time (s)")
        ax.grid(True, alpha=.25)
        ax.legend(fontsize=8)
    axes[0].set_ylabel("L_Hip_y actual − target (deg, raw/unwrapped)")
    fig.suptitle("Three-hinge hip fixture at initial L_Hip_x = −90° — recorded trace")
    fig.text(.5, .012,
             "Isolated fixture, 240 Hz × 24 steps. Source report data only; not the humanoid body renderer or main environment.",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .06, 1, .90))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=170, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()

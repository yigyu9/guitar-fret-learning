#!/usr/bin/env python3
"""Build saved-data curves and camera sheet for the Seed 2 response probes."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Dict, List

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.family"] = "NanumGothic"
matplotlib.rcParams["axes.unicode_minus"] = False

ROOT = Path(__file__).resolve().parents[1]
PHASE = ROOT / "docs/2026-10-12/stability_adapter_2/results/seed2_guitar_response_v1"
FONT = Path("/usr/share/fonts/truetype/nanum/NanumGothic.ttf")
PROBE_LABELS = ["base", "shoulder_x", "shoulder_y", "shoulder_z", "wrist_x", "wrist_y", "wrist_z"]
CAMERA_LABELS = ["base", "wrist_z", "heldout"]
DISPLAY = {
    "base": "Base",
    "shoulder_x": "Shoulder X",
    "shoulder_y": "Shoulder Y",
    "shoulder_z": "Shoulder Z",
    "wrist_x": "Wrist X",
    "wrist_y": "Wrist Y",
    "wrist_z": "Wrist Z",
    "heldout": "Heldout",
}
COLORS = {
    "base": "#242424",
    "shoulder_x": "#1f77b4",
    "shoulder_y": "#2ca02c",
    "shoulder_z": "#9467bd",
    "wrist_x": "#17becf",
    "wrist_y": "#bcbd22",
    "wrist_z": "#ff7f0e",
    "heldout": "#d62728",
}


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def finite_series(values, label: str) -> np.ndarray:
    data = np.asarray(values, dtype=float)
    if data.ndim != 1 or not np.isfinite(data).all():
        raise ValueError(f"{label} must be a finite one-dimensional array")
    return data


def input_paths() -> List[Path]:
    paths = [
        Path(__file__).resolve(), FONT,
        PHASE / "artifact_brief.json",
        PHASE / "probe_analysis.json",
        PHASE / "heldout_analysis.json",
        PHASE / "heldout_selection.json",
    ]
    for label in PROBE_LABELS + ["heldout"]:
        run = PHASE / "native" / label
        paths.extend([run / "report.json", run / "initial_values.json"])
    for label in CAMERA_LABELS:
        run = PHASE / "native" / label
        paths.append(run / "capture.json")
        for frame in (0, 150):
            paths.append(run / "frames" / "hands" / f"{frame:05d}.png")
    return paths


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    out = args.out_dir.resolve()
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f"refusing nonempty output directory: {out}")
    out.mkdir(parents=True, exist_ok=True)

    inputs = input_paths()
    missing = [str(path) for path in inputs if not path.is_file()]
    if missing:
        raise SystemExit("missing inputs: " + ", ".join(missing))
    before = {str(path): sha(path) for path in inputs}

    brief = load_json(PHASE / "artifact_brief.json")
    probe = load_json(PHASE / "probe_analysis.json")
    heldout = load_json(PHASE / "heldout_analysis.json")
    selection = load_json(PHASE / "heldout_selection.json")
    if brief["counts"] != {
        "heldout_native_initializations": 1,
        "heldout_physics_steps": 1200,
        "phase_native_initializations": 8,
        "phase_physics_steps": 9600,
    }:
        raise ValueError("unexpected phase initialization/step counts")
    for name, analysis, expected_counts in (
        ("probe", probe, {"native_initializations": 7, "physics_steps": 8400}),
        ("heldout", heldout, {
            "heldout_native_initializations": 1,
            "heldout_physics_steps": 1200,
            "phase_native_initializations": 8,
            "phase_physics_steps": 9600,
        }),
    ):
        if not analysis.get("checks") or not all(analysis["checks"].values()):
            raise ValueError(f"{name} analysis checks failed")
        if analysis.get("counts") != expected_counts:
            raise ValueError(f"unexpected {name} count contract")
    if list(probe["curves"]) != PROBE_LABELS or not all(
        key in heldout["curves"] for key in ("time_s", "guitar_position_error_mm", "guitar_rotation_error_deg")
    ):
        raise ValueError("unexpected analysis labels")
    if not isinstance(probe.get("baseline_full5s_five_arrays_exact"), bool):
        raise ValueError("missing baseline reproducibility observation")
    if not selection.get("checks") or not all(selection["checks"].values()):
        raise ValueError("heldout selection checks failed")

    all_curves: Dict[str, dict] = {key: probe["curves"][key] for key in PROBE_LABELS}
    all_curves["heldout"] = heldout["curves"]
    figure, axes = plt.subplots(2, 1, figsize=(12.8, 8.2), sharex=False, constrained_layout=True)
    for axis, field, title, ylabel in (
        (axes[0], "guitar_position_error_mm", "Guitar position error", "Error (mm)"),
        (axes[1], "guitar_rotation_error_deg", "Guitar rotation error", "SO(3) error (degrees)"),
    ):
        for label in PROBE_LABELS + ["heldout"]:
            curve = all_curves[label]
            x = finite_series(curve["time_s"], f"{label}.time_s")
            y = finite_series(curve[field], f"{label}.{field}")
            if len(x) != 1201 or len(y) != 1201 or not np.all(np.diff(x) > 0):
                raise ValueError(f"unexpected sample count or time ordering for {label}.{field}")
            if not np.isclose(x[0], 0.0) or not np.isclose(x[-1], 5.0):
                raise ValueError(f"unexpected time coverage for {label}.{field}")
            axis.plot(x, y, color=COLORS[label], linewidth=1.5,
                      linestyle="--" if label == "heldout" else "-", label=DISPLAY[label])
        axis.set_title(title)
        axis.set_ylabel(ylabel)
        axis.grid(True, alpha=.25)
        axis.set_xlim(0.0, 5.0)
        axis.legend(loc="best", ncol=2, fontsize=8)
    axes[1].set_xlabel("Time (s)")
    figure.suptitle("Saved Seed 2 single-axis probes and heldout response", fontsize=13)
    curve_path = out / "seed2_guitar_response_curves.png"
    figure.savefig(curve_path, dpi=170)
    plt.close(figure)

    figure, axes = plt.subplots(2, 3, figsize=(12.6, 5.4), constrained_layout=True)
    camera_meta = {}
    for col, label in enumerate(CAMERA_LABELS):
        run = PHASE / "native" / label
        capture = load_json(run / "capture.json")
        frames = capture.get("frames", [])
        if capture.get("fps") != 30 or len(frames) != 151:
            raise ValueError(f"unexpected capture metadata for {label}")
        camera_meta[label] = {"fps": 30, "frame_count": 151, "displayed_steps": [0, 1200]}
        for row, (step, frame_index) in enumerate(((0, 0), (1200, 150))):
            frame = next((item for item in frames if item.get("physics_step") == step), None)
            if frame is None or frame.get("render_preserves_states") is not True:
                raise ValueError(f"missing state-preserving frame for {label} step {step}")
            if not np.isclose(float(frame.get("time_s", -1)), step / 240.0):
                raise ValueError(f"frame time mismatch for {label} step {step}")
            image_path = (run / "frames" / "hands" / f"{frame_index:05d}.png").resolve()
            recorded = frame.get("image_sha256", {})
            matching = next((path for path in recorded if Path(path).resolve() == image_path), None)
            if matching is None or sha(image_path) != recorded[matching]:
                raise ValueError(f"camera PNG SHA mismatch: {image_path}")
            axis = axes[row, col]
            axis.imshow(plt.imread(image_path))
            axis.set_axis_off()
            if row == 0:
                axis.set_title(DISPLAY[label], fontsize=10)
            axis.text(.02, .03, f"t={step / 240:.1f} s | step {step}", transform=axis.transAxes,
                      color="white", fontsize=8, va="bottom",
                      bbox={"facecolor": "black", "alpha": .65, "pad": 3})
    figure.suptitle("Recorded Isaac Gym hands-camera frames", fontsize=13)
    camera_path = out / "seed2_guitar_response_hands_camera.png"
    figure.savefig(camera_path, dpi=150)
    plt.close(figure)

    after = {str(path): sha(path) for path in inputs}
    if before != after:
        raise RuntimeError("input SHA changed during artifact generation")
    manifest = {
        "producer": str(Path(__file__).resolve()),
        "producer_sha256": sha(Path(__file__).resolve()),
        "input_count": len(inputs),
        "inputs_sha256_before": before,
        "inputs_sha256_after": after,
        "phase_counts": brief["counts"],
        "probe_counts": probe["counts"],
        "heldout_counts": heldout["counts"],
        "probe_analysis_checks": probe["checks"],
        "heldout_analysis_checks": heldout["checks"],
        "baseline_full5s_raw_match_observation": probe["baseline_full5s_five_arrays_exact"],
        "heldout_requested_target_residual_rad": selection["requested_residual_rad"],
        "heldout_actual_float32_target_difference_rad": selection["actual_float32_submitted_target_difference_rad"],
        "camera_frames": camera_meta,
        "outputs_sha256": {str(path): sha(path) for path in (curve_path, camera_path)},
        "physical_trials_or_native_calls_by_producer": 0,
    }
    manifest_path = out / "artifact_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
                             encoding="utf-8")
    print(curve_path)
    print(camera_path)
    print(manifest_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Plot saved source-geometry screening results for coupled support proposals."""
import argparse
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PHASE = ROOT / 'docs/2026-10-12/stability_adapter_2/results/coupled_support_source_v1'
MODEL = PHASE / 'model.json'
SEARCH = PHASE / 'search_v3.json'
EXECUTION = PHASE / 'search_execution_v3.json'
EXECUTION_SOURCE = PHASE / 'search_execution_producer_v3.py'
SAVED_SOURCE = PHASE / 'search_source_v3.py'
SEARCH_SOURCE = ROOT / 'stability_adapter_2/search_coupled_support_source_v3.py'
PLAN = ROOT / 'stability_adapter_2/PLAYING_RESIDUAL_EVALUATION.md'
OUTPUT_NAME = 'coupled_support_palm_gap_by_fraction.png'
FRACTIONS = (0.0, 1.0, 0.5, 0.25)
TIMES = (0.0, 0.1, 0.5, 5.0)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load_json(path):
    with Path(path).open('r') as stream:
        return json.load(stream)


def verify_declared_inputs(hashes, expected):
    for path, digest in expected.items():
        resolved = str(Path(path).resolve())
        if resolved not in hashes or hashes[resolved] != digest:
            raise RuntimeError('missing or changed sealed dependency: ' + resolved)


def validate(model, search, execution):
    if not all(model.get('checks', {}).values()) or len(model.get('checks', {})) != 5:
        raise ValueError('model validation checks are incomplete or failed')
    validation = model.get('validation', [])
    if len(validation) != 264 or not all(row.get('passed') is True for row in validation):
        raise ValueError('expected 264 passed held-out pose predictions')
    if model.get('native_initializations') != 0 or model.get('physics_steps') != 0:
        raise ValueError('model validation unexpectedly used native physics')
    if len(model.get('samples', [])) != 4 or len(model.get('selected_names', [])) != 18:
        raise ValueError('expected four saved samples and 18 temporary proposal coordinates')
    if not all(search.get('checks', {}).values()) or len(search.get('checks', {})) != 7:
        raise ValueError('v3 source screen checks are incomplete or failed')
    if len(search.get('rows', [])) != 16:
        raise ValueError('expected all 16 source placements')
    if execution.get('exit_code') != 0 or execution.get('native_initializations') != 0 or execution.get('physics_steps') != 0:
        raise ValueError('v3 source search execution record is incomplete')
    if execution.get('source_sha256_before') != execution.get('source_sha256_after'):
        raise ValueError('v3 search source changed during its recorded execution')

    keyed = {}
    for row in search['rows']:
        key = (float(row['time_s']), float(row['fraction']))
        if key in keyed:
            raise ValueError('duplicate time/fraction placement')
        intervals = row.get('patch_distance_intervals', {}).get('LH:palm', [])
        if not intervals:
            raise ValueError('missing saved palm patch distance interval')
        values = [float(item['distance_m']) for item in intervals]
        if not all(math.isfinite(value) and value >= 0 for value in values):
            raise ValueError('invalid palm source distance upper bound')
        if row.get('same_left_nonadjacent_pair_count') != 110:
            raise ValueError('same-left nonadjacent pair screen differs from approved v3')
        keyed[key] = row
    expected = {(time_s, fraction) for time_s in TIMES for fraction in FRACTIONS}
    if set(keyed) != expected:
        raise ValueError('v3 time/fraction coverage differs from the approved 4x4 design')
    passed = [(float(row['time_s']), float(row['fraction'])) for row in search['rows']
              if row['source_direction_screen_passed'] is True]
    if passed != [(0.5, 0.25)]:
        raise ValueError('v3 source screen pass differs from approved data')
    return keyed


def find_plot_font():
    import matplotlib
    matplotlib.use('Agg')
    from matplotlib import font_manager
    return Path(font_manager.findfont(font_manager.FontProperties())).resolve()


def draw_figure(path, keyed, font_path):
    import matplotlib
    matplotlib.use('Agg')
    from matplotlib import font_manager
    matplotlib.rcParams['font.family'] = font_manager.FontProperties(fname=str(font_path)).get_name()
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    colors = {0.0: '#6b7280', 1.0: '#c2413b', 0.5: '#2878a8', 0.25: '#39834a'}
    markers = {0.0: 'o', 1.0: 's', 0.5: 'D', 0.25: '^'}
    offsets = {0.0: -0.24, 1.0: -0.08, 0.5: 0.08, 0.25: 0.24}
    x_by_time = {time_s: i for i, time_s in enumerate(TIMES)}
    fig, ax = plt.subplots(figsize=(10.0, 6.0))

    for fraction in FRACTIONS:
        xs, ys = [], []
        for time_s in TIMES:
            row = keyed[(time_s, fraction)]
            gap_mm = min(float(item['distance_m'])
                         for item in row['patch_distance_intervals']['LH:palm']) * 1000.0
            xs.append(x_by_time[time_s] + offsets[fraction])
            ys.append(gap_mm)
        ax.scatter(xs, ys, s=74, marker=markers[fraction], color=colors[fraction],
                   edgecolors='black', linewidths=.55, zorder=3)

    passed_row = keyed[(0.5, 0.25)]
    passed_y = min(float(item['distance_m'])
                   for item in passed_row['patch_distance_intervals']['LH:palm']) * 1000.0
    passed_x = x_by_time[0.5] + offsets[0.25]
    ax.scatter([passed_x], [passed_y], s=170, marker='*', facecolors='none',
               edgecolors='black', linewidths=1.1, zorder=4)
    ax.annotate('Only source-screen pass', xy=(passed_x, passed_y), xytext=(2.35, 8.45),
                textcoords='data', fontsize=9, ha='left', va='center',
                arrowprops={'arrowstyle': '->', 'color': '#222222', 'lw': .9})

    ax.set_xlim(-0.5, len(TIMES) - 0.5)
    all_gaps = [min(float(item['distance_m']) for item in keyed[(time_s, fraction)]['patch_distance_intervals']['LH:palm']) * 1000.0
                for time_s in TIMES for fraction in FRACTIONS]
    ax.set_ylim(0.17, max(all_gaps) + 0.55)
    ax.set_xticks(range(len(TIMES)), [f'{time_s:g}' for time_s in TIMES])
    ax.set_xlabel('Saved Isaac-state sample time (s; discrete snapshots)')
    ax.set_ylabel('Minimum LH:palm finite-patch distance upper bound (mm)')
    ax.set_title('Coupled support proposals — CPU source geometry only')
    ax.grid(axis='y', alpha=.28, zorder=0)
    ax.legend(handles=[Line2D([0], [0], linestyle='None', marker=markers[fraction],
                              markerfacecolor=colors[fraction], markeredgecolor='black',
                              markersize=8, label=f'Proposal fraction {fraction:g}')
                       for fraction in FRACTIONS],
              title='Fraction of 18D proposal', loc='upper left', frameon=True, fontsize=8)
    fig.text(.5, .015,
             '16 placements shown; points are unconnected snapshots. Source common-radius screening is not cooked-geometry clearance or a physical PD outcome.',
             ha='center', va='bottom', fontsize=8)
    fig.tight_layout(rect=(0.0, .07, 1.0, .98))
    fig.savefig(path, dpi=180, bbox_inches='tight')
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out-dir', type=Path, default=PHASE / 'artifacts')
    args = parser.parse_args()
    out_dir = args.out_dir.resolve()
    output = out_dir / OUTPUT_NAME
    manifest_path = out_dir / 'artifact_manifest.json'
    if out_dir.exists() and any(out_dir.iterdir()):
        raise FileExistsError('refusing to overwrite a nonempty artifact directory')

    producer = Path(__file__).resolve()
    direct = (producer, MODEL.resolve(), SEARCH.resolve(), EXECUTION.resolve(),
              EXECUTION_SOURCE.resolve(), SAVED_SOURCE.resolve(), SEARCH_SOURCE.resolve(), PLAN.resolve(),
              (PHASE / 'search_v3.log').resolve(), (PHASE / 'model_execution.json').resolve())
    if any(not path.is_file() for path in direct):
        raise FileNotFoundError('a declared v3 input or source record is missing')
    before = {str(path): sha256(path) for path in direct}
    if sha256(SAVED_SOURCE) != sha256(SEARCH_SOURCE):
        raise RuntimeError('saved v3 source snapshot differs from current executed source')

    model = load_json(MODEL)
    search = load_json(SEARCH)
    execution = load_json(EXECUTION)
    model_execution = load_json(PHASE / 'model_execution.json')
    dependency_hashes = {}
    for mapping in (model['input_sha256'], model_execution.get('input_sha256', {}),
                    search['input_sha256']):
        for path, digest in mapping.items():
            if path in dependency_hashes and dependency_hashes[path] != digest:
                raise RuntimeError('conflicting dependency SHA records: ' + path)
            dependency_hashes[path] = digest
    for path, digest in dependency_hashes.items():
        resolved = str(Path(path).resolve())
        current = sha256(resolved)
        if current != digest:
            raise RuntimeError('sealed dependency changed: ' + resolved)
        before[resolved] = current
    verify_declared_inputs(before, dependency_hashes)
    if model_execution.get('observed_exit_code') != 0:
        raise RuntimeError('recorded model-validation execution did not exit successfully')
    if sha256(PHASE / 'search_v3.log') != execution.get('log_sha256'):
        raise RuntimeError('v3 search log hash differs from its execution record')
    if before[str(SEARCH_SOURCE)] != execution['source_sha256_before']:
        raise RuntimeError('executed v3 search source SHA mismatch')
    keyed = validate(model, search, execution)

    font_path = find_plot_font()
    before[str(font_path)] = sha256(font_path)
    out_dir.mkdir(parents=True, exist_ok=True)
    draw_figure(output, keyed, font_path)
    after = {path: sha256(path) for path in before}
    if before != after:
        raise RuntimeError('an input changed during artifact generation')

    outputs = {str(output.resolve()): sha256(output)}
    manifest = {
        'producer_sha256': sha256(producer),
        'inputs_sha256_before': dict(sorted(before.items())),
        'inputs_sha256_after': dict(sorted(after.items())),
        'outputs_sha256': outputs,
        'native_calls': 0,
        'native_initializations': 0,
        'physics_steps': 0,
        'model_inference_calls': 0,
        'training_updates': 0,
        'placement_count': len(keyed),
        'source_screen_pass_count': sum(bool(row['source_direction_screen_passed']) for row in search['rows']),
        'sample_times_s': list(TIMES),
        'proposal_fractions': list(FRACTIONS),
        'source_geometry_only': True,
    }
    with manifest_path.open('w') as stream:
        json.dump(manifest, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'outputs_sha256': outputs, 'manifest': str(manifest_path.resolve()),
                      'input_count': len(before), 'native_calls': 0}, sort_keys=True))


if __name__ == '__main__':
    main()

"""Summarize saved runtime Jacobian cache timing without another native run."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--measurements', type=Path, required=True)
    parser.add_argument('--initial-jacobian', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise FileExistsError('preserve previous cache analysis')
    report_path, query_path = (args.measurements / name for name in ('report.json', 'queries.json'))
    report, queries, initial = (json.loads(p.read_text()) for p in (report_path, query_path, args.initial_jacobian))
    if not all(report['checks'].values()) or not all(sha(p) == h for p, h in report['input_sha256'].items()):
        raise ValueError('runtime query contracts or source SHA differ')
    sides = {}
    for side in ('L', 'R'):
        palms = [q['palms'][side] for q in queries]
        first = palms[0]
        saved_initial = np.array(initial['values'])[0, initial['palm_rows'][side]]
        sides[side] = {'initial_before_refresh_zero': bool(np.abs(first['before_refresh_J']).max() == 0),
            'initial_refreshed_matches_prior_tensor': bool(np.array_equal(first['refreshed_J'], saved_initial)),
            'all_post0_cached_equals_previous_refreshed': all(np.array_equal(b['before_refresh_J'], a['refreshed_J']) for a, b in zip(palms, palms[1:])),
            'post0_cache_change_max_abs': max(p['cache_change_max_abs'] for p in palms[1:]),
            'max_native_linear_speed_mps': max(float(np.linalg.norm(p['native_linear_mps'])) for p in palms),
            'max_native_angular_speed_rad_s': max(float(np.linalg.norm(p['native_angular_rad_s'])) for p in palms),
            'max_velocity_errors': report['max_velocity_errors'][side]}
    paths = [report_path, query_path, args.initial_jacobian, Path(__file__).resolve()]
    hashes = dict(report['input_sha256'])
    hashes.update({str(p.resolve()): sha(p) for p in paths})
    result = {'scope': 'saved runtime cache timing and velocity residuals; not exact identity, future runtime range or guitar stability certificate',
        'checks': {'runtime_contracts': all(report['checks'].values()),
            '25_contiguous_completed_samples': len(queries) == 25 and [q['physics_step'] for q in queries] == list(range(25)),
            'initial_refresh_matches_prior_and_post0_cache_is_previous': all(s['initial_before_refresh_zero'] and s['initial_refreshed_matches_prior_tensor'] and s['all_post0_cached_equals_previous_refreshed'] for s in sides.values())},
        'sides': sides, 'input_sha256': hashes}
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'checks': result['checks'], 'input_hashes': len(hashes)}, indent=2))
    if not all(result['checks'].values()):
        raise SystemExit(1)


if __name__ == '__main__':
    main()

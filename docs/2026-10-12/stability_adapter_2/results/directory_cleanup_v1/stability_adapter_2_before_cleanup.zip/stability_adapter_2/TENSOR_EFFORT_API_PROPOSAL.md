# Force tensor의 CPU drive-mode 응답 검증 제안

2026-10-07. 사용자 “응 진행해줘” 승인으로 아래 6조건 진단을 진행한다.

원본 base.py의 POS/stiffness0/force tensor 조합과 설치 공식 문서의 EFFORT
요구 사이 정적 차이가 확인됐다. 현재 humanoid의 actuator를 바꾸기 전에 같은
CPU PhysX에서 이 API가 실제 움직임에 반영되는지 분리해 확인하려 한다.
이 검사는 기타 안정화 성공이나 원본 GPU 실행의 오류 판정이 아니다.

## 한 소단계의 조건

- [x] 사용자 승인 후 별도 runner를 구현하고 change-reviewer 사전 검수한다.
- [x] 새 fixture 6환경, 각24step(0.1초)을 실행하고 원자료를 비교한다.
- [x] 설명 이미지·표·실행/검수 기록을 결과 디렉토리에 저장한다.

`tab2body/assets/smpl_mpl_hands_body.xml`의 L_Shoulder_x joint 및 해당 body geom을
읽어 고정된 작은 base와 회전1축 fixture를 새 결과 디렉토리에 생성한다. 공용 자산은
변경하지 않는다. 이 fixture에는 기타·스트랩·ground·접촉 상대가 없으며 중력은0이다.
기존 main scene의 root·자세·LA·PD·하체와 자유 기타 조건은 그대로 둔다.

초기 q/velocity는0, authored limit 안임을 확인한다. CPU 240Hz/1substep,
기존 solver type1/position4/velocity2를 사용한다. Fixture properties는 stiffness0,
damping50, effort150으로 두고 driveMode만 POS 또는 EFFORT로 비교한다.
각 mode에서 tensor torque0, +1, −1 Nm를 매step 제출하여 총6fresh/144step이다.
한 환경 안에서 mode를 전환하거나 상태를 재주입하지 않는다.

`gymapi.Tensor`에 CPU contiguous float32 NumPy buffer의 device−1/dtype/shape/address와
`own_data=False`를 설정해 Python이 유지하는 메모리의 소유권을 넘기지 않는다. 구조는
설치 `isaacgym/python/isaacgym/gymtorch.py:97`의 descriptor 구조를
따르며 buffer·descriptor를 simulation 종료까지 유지한다. Torch/Ninja는 사용하지 않는다.
API 거절·descriptor 계약 실패·초기/step 비유한값·fixture 접촉이면 해당 실패를 보존하고
중단한다. 임의의 다른 API·모드·gain·GPU로 자동 대체하지 않는다.

## 확인할 증거와 해석

모든 run의 source/fixture SHA, 초기1개+완료24개 상태, native properties readback,
step별 제출 torque와 API 반환값, runtime solver/gravity, 접촉 행을 저장한다.
같은 mode의0 Nm 기준과 ±1 Nm q/velocity 차이를 원자료 float32 기준으로 비교한다.
EFFORT의 양방향 응답을 positive control로 먼저 확인한다. 정확히 같으면 관측 해상도에서
차이가 없었다고 기록하며, 1축 CPU 결과로 전 모델/API/백엔드의 무시를 단정하지 않는다.
POS에서 차이가 발견되면 공식 문서와 다른 응답으로 기록하고 추가 진단 범위를 먼저
검토한다. Total DOF force를 actuator torque의 참값으로 사용하지 않는다.

결과는 `docs/2026-10-12/stability_adapter_2/results/tensor_effort_api_v1/`에 둔다.
이 단계 뒤 humanoid arm24의 구동 모드 변경·SO(3) torque 제어·연주 목표와 안정화 보정의
구현은 별도 설계/확인이 필요하다. 이번 제안은 그 변경을 승인하거나 적용하지 않는다.

## 실제 결과

6fresh/144step이 완료됐으며 각9계약·총144회 API 제출이 통과했다. EFFORT ±1Nm의
종료 q는+0.001976419706/−0.001976419473rad(약±0.11324°), POS ±1Nm는25개
q/velocity 상태가0Nm와exact였다. 이1축 CPU에서 POS tensor torque의 움직임 영향은
관측되지 않았고 EFFORT 양방향 응답을 확인했다. 원본 GPU/전신에는 확대하지 않는다.
Source XML±90°는 native hasLimits=false/lower=upper0으로 읽혔다. Native 제한 활성화
시험은 아니며 source range와 실제저장 q 범위는 별도 대조했다.
마지막 EFFORT +1Nm 구간의 Δq/Δt는약0.01976548rad/s, SDK 완료-step velocity는
약0.000237588rad/s다. 구간 평균과 완료시점 속도는 다른 측정이며 차이의 원인은
미확정이다. 이후 torque-PD 감쇠·velocity feedback 설계 전에 별도 검증해야 한다.
현재 main scene의 drive mode·gain·controller·초기각·LA는 변경하지 않았다.

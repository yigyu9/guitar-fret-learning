# 두축 quaternion tangent-plane 가설의 추가 대조

저장24시점에서exp(sum)/XML순서product/역순product는모두기존0.1mm/0.001rad gate에미달했다. XMLproduct의최대0.835770mm/0.010405rad도오차가남았다. 아직runtime제어를시작하지않는다.

새네번째가설은두coordinate를theta라할때quaternion의벡터부를basis@tan(theta/2),scalar부를1로두고정규화하는순수수학map이다. 이를PhysX의확정된계약으로주장하지않고동일t0calibration·동일24시점·기존세가설·동일gate로검사한다. 추가fit이나미지restframe변수/tolerance변경은없다. 기존source/result/wrapper/log/입력을expectedSHA로보존하고새v2 helper/analyzer/output에서비교한다. 추가native/physics0이다.

통과여부와관계없이4가설의joint-relative·전체body오차를보고한다. 이관측밖모든자세/PD/접촉matrix/면별지지/기타복원으로인증범위를확장하지않는다. 기하회전map이맞아도팔목표보정의native5초는다음별도실행계약이다.

"""Plot saved arm-initial-trial traces; never runs native physics."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def row(rows, group, name):
    return next(r for r in rows if (r["group"], r["name"], r["mode"]) == (group, name, "on"))


def plot(rows, output):
    fig, axes = plt.subplots(2, 2, figsize=(12, 8.5), sharex=False)
    colors = {"reference": "#374151", "x_minus0025": "#2563a6", "y_plus0050": "#d97706", "z_plus0050": "#7c3aed"}
    for name, color in colors.items():
        trace = load(Path(row(rows, "hold_05s", name)["run"]) / "trace.json")
        t = [s["time_s"] for s in trace]
        axes[0, 0].plot(t, [s["position_error_m"] * 1000 for s in trace], color=color, label=name)
        axes[0, 1].plot(t, [s["rotation_error_deg"] for s in trace], color=color, label=name)
    for name, color in (("reference", colors["reference"]), ("y_plus0050", colors["y_plus0050"])):
        trace = load(Path(row(rows, "hold_1s", name)["run"]) / "trace.json")
        t = [s["time_s"] for s in trace]
        axes[1, 0].plot(t, [s["position_error_m"] * 1000 for s in trace], color=color, label=name)
        axes[1, 1].plot(t, [s["rotation_error_deg"] for s in trace], color=color, label=name)
    for ax, title, unit, xmax in ((axes[0, 0], "0.5 s ON · position", "mm", .5),
                                  (axes[0, 1], "0.5 s ON · rotation", "degrees", .5),
                                  (axes[1, 0], "1.0 s ON · position", "mm", 1.),
                                  (axes[1, 1], "1.0 s ON · rotation", "degrees", 1.)):
        ax.set(title=title, xlabel="Time (s)", ylabel=unit, xlim=(0, xmax))
        ax.grid(True, alpha=.25)
        ax.legend(fontsize=8, frameon=False)
    fig.suptitle("Saved CPU PhysX guitar-error traces — initial elbow-angle comparison")
    fig.tight_layout()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError(output)
    fig.savefig(output, dpi=160, bbox_inches="tight")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--results-dir", type=Path, required=True)
    ap.add_argument("--out-dir", type=Path, required=True)
    args = ap.parse_args()
    if args.out_dir.exists() and any(args.out_dir.iterdir()):
        raise FileExistsError(f"preserve existing outputs: {args.out_dir}")
    comparison_path = args.results_dir / "comparison.json"
    comparison = load(comparison_path)
    rows = comparison["rows"]
    if len(rows) != 10 or not all(comparison["checks"].values()) or not all(
            all(r["checks"].values()) for r in rows):
        raise ValueError("expected ten fully checked saved runs")
    for name, expected in comparison["input_sha256"].items():
        path = Path(name)
        if sha(path) != expected:
            raise ValueError(f"embedded input SHA mismatch: {path}")
    output = args.out_dir / "right_elbow_retention_v1.png"
    plot(rows, output)
    manifest = {"purpose": "read-only saved traces; no native execution",
                "inputs_sha256": {str(comparison_path.resolve()): sha(comparison_path), **comparison["input_sha256"]},
                "embedded_source_sha256": comparison["input_sha256"],
                "plotter_sha256": {str(Path(__file__).resolve()): sha(Path(__file__))},
                "outputs_sha256": {str(output.resolve()): sha(output)}}
    (args.out_dir / "plot_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()

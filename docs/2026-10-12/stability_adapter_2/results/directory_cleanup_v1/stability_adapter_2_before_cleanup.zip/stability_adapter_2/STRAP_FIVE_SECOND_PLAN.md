# 현재 초기 자세에서 스트랩 초기 길이의 5초 비교

이번 stiffness-only 비교에서 왼팔 kp 증가가 기타 오차를 크게 키웠다.
kp/kd는 기준1배로 유지하고, 실제 초기 설정인 절대 strap rest length를 다시 비교한다.
초기 자세와 기타 생성 p/q, 상수 목표 보정은 palm_stiffness_only_v1/kp_1과 같다.
이전 palm_side_strap_v1의 짧은 결과는 다른 제어 조건이므로 이번5초 결과를 대신하지 않는다.

## 다음 작은 실행 단위

- [ ] 기준 입력의 실제 초기 route 길이1.0804741130331008m를 확인하고 세 trial을 준비한다.
- [ ] current LA1.1018469719600776m, taut LA1.0804741130331008m,
  초기 law5N LA1.0796407796997676m를 각각5초 비교한다. 3init/3600step이며
  같은 run의 실제 초기값·전신/손 영상·연속 로그를 저장한다.
- [ ] 첫0.1초와 전체5초 기타 최대/종료 p·q 오차, 손 추적점/source gap·실제 접촉,
  몸통 실제 이동, strap 길이·직전 step에 적용된 장력을 함께 확인한다.
- [ ] 원자료를 분석하고 산출물/독립 검수 후 초기 관절각 변경 방향을 결정한다.

LA 후보는 저장 native route와 원본 stiffness6000N/m로 결정했다.
taut는 초기 law0N,5N 조건은 route에서5/6000m를 뺀 값이다.
각 LA는 실행 중 고정되고 장력은 실제 route/속도에 따른 기존 수동 law로 변한다.
초기 law5N이 모든 시각의 장력5N을 뜻하지 않는다. 강한 preload는 이번 범위에 추가하지 않는다.

root/하체 물리 고정, 몸통9 초기 목표, 양쪽Thorax부터 손가락66 제어 경로,
왼팔/오른팔/손가락 기본PD, self-collision ON과 기타 자유 상태를 유지한다.
기타 고정·강제 손 부착·지속 pose 덮어쓰기를 사용하지 않는다.
손바닥 위쪽 반구 proxy와 법선 간격은 기록하며 cooked clearance/해부학 인증과 구별한다.
normal gap 음수를 유한 기타 넥의 실제 관통으로 단정하지 않는다.

실행은 run_recorded_trial을 재사용하고 trial은 stability_adapter_2/trials/strap_five_second_v1,
결과는 docs/2026-10-12/stability_adapter_2/results/strap_five_second_v1에 저장한다.
완료 체크는 봉인된 이 계획 대신 메인PLAN.md에 갱신한다. 아직 실행하지 않았다.

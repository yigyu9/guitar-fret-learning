#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
runtime_dir=/home/ajou/miniconda3/envs/rl38
export PYTHONPATH="$project_dir/isaacgym/python:$project_dir${PYTHONPATH:+:$PYTHONPATH}"
export LD_LIBRARY_PATH="$runtime_dir/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MUJOCO_GL=disable MPLBACKEND=Agg
cd "$project_dir"
exec "$runtime_dir/bin/python" -m stability_adapter_2.guitar_pose_static "$@"

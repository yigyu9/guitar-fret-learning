"""Render saved trace and source-shape snapshots for a quiescent diagnostic; no physics."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

from stability_adapter_2.plot_joint_hold import geometry_asset_paths, geometry_snapshot


def read_json(path):
    return json.loads(path.read_text())


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_inputs(results_dir):
    comparison_path = results_dir / "comparison.json"
    comparison = read_json(comparison_path)
    rows = comparison["rows"]
    if not all(comparison["checks"].values()) or len(rows) != 1 or not all(
            all(row["checks"].values()) for row in rows):
        raise ValueError("quiescent comparison checks did not pass")
    for source, expected in comparison["input_sha256"].items():
        path = Path(source)
        if not path.is_file() or sha256(path) != expected:
            raise ValueError(f"embedded source SHA mismatch: {path}")
    run = Path(rows[0]["run"])
    if run.resolve() != (results_dir / "on").resolve() or rows[0]["mode"] != "on":
        raise ValueError("comparison does not reference the expected saved ON run")
    raw = [run / name for name in ("report.json", "states.json", "trace.json")]
    if not all(path.is_file() for path in raw):
        raise FileNotFoundError("saved report/states/trace input missing")
    return comparison_path, comparison, run, raw


def plot_geometry(run, output):
    trace = read_json(run / "trace.json")
    snapshots = []
    extents = []
    for step in (0, 240, 720):
        surfaces, palms = geometry_snapshot(run, step)
        sample = trace[step]
        route = np.asarray(sample["route_points_m"], dtype=float)
        for triangles, _shape in surfaces:
            extents.append(np.asarray(triangles).reshape(-1, 3))
        extents.extend((route, *(center[None, :] for center, _normal in palms.values())))
        snapshots.append((step, surfaces, palms, route, sample))

    points = np.concatenate(extents)
    low, high = points.min(axis=0), points.max(axis=0)
    center = (low + high) / 2
    half = float(np.ptp(points, axis=0).max()) / 2 + .06

    fig = plt.figure(figsize=(16, 6.4))
    for index, (step, surfaces, palms, route, sample) in enumerate(snapshots, 1):
        ax = fig.add_subplot(1, 3, index, projection="3d")
        for triangles, shape in surfaces:
            body = shape["body"]
            if shape["actor"] == "guitar":
                color, alpha = "#2563eb", .82
            elif body.startswith("LH:"):
                color, alpha = "#16a34a", .90
            elif body.startswith("RH:"):
                color, alpha = "#c026d3", .86
            else:
                color, alpha = "#9ca3af", .25
            ax.add_collection3d(Poly3DCollection(
                triangles, facecolors=color, alpha=alpha, edgecolors="none"))
        ax.plot(route[:, 0], route[:, 1], route[:, 2], color="#111827", ls="--",
                lw=1.5, marker=".", ms=2, label="saved strap route")
        for side, (palm, normal) in palms.items():
            color = "#16a34a" if side == "L" else "#c026d3"
            ax.scatter(*palm, color=color, s=22, depthshade=False)
            ax.quiver(*palm, *(normal * .06), color=color, linewidth=1.4,
                      arrow_length_ratio=.25)
        ax.set(xlim=(center[0] - half, center[0] + half),
               ylim=(center[1] - half, center[1] + half),
               zlim=(center[2] - half, center[2] + half),
               xlabel="World X (m)", ylabel="World Y (m)", zlabel="World Z (m)")
        ax.set_box_aspect((1, 1, 1))
        ax.view_init(elev=18, azim=110)
        ax.set_title(f"t={sample['time_s']:.1f} s · step {step}\n"
                     f"goal error {sample['position_error_m'] * 1000:.1f} mm / "
                     f"{sample['rotation_error_deg']:.1f}°")
    fig.suptitle("Saved native poses reconstructed from source collision shapes", y=.98)
    fig.text(.5, .012,
             "Blue: guitar | green/magenta: left/right hand | gray: remaining humanoid | "
             "dashed: saved strap route | arrows: palm-normal landmark proxies (anatomical sign unverified). "
             "Same world bounds/camera; not native renderer, cooked clearance, contact or support certification.",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .055, 1, .94), w_pad=.2)
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError(f"preserve existing output: {output}")
    fig.savefig(output, dpi=145, bbox_inches="tight")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    output = args.out_dir / "quiescent_3s_source_geometry.png"
    manifest_path = args.out_dir / "plot_manifest.json"
    if args.out_dir.exists() and any(args.out_dir.iterdir()):
        raise FileExistsError(f"preserve existing plot outputs: {args.out_dir}")
    comparison_path, comparison, run, raw = validate_inputs(args.results_dir)
    assets = geometry_asset_paths()
    helpers = [Path(__file__).resolve(), Path(__file__).with_name("plot_joint_hold.py"),
               Path(__file__).with_name("replay_contact_geometry.py"),
               Path(__file__).with_name("plot_physx_contacts.py"),
               Path(__file__).with_name("plot_neck_palm.py"),
               Path(__file__).with_name("initial_overlap.py"),
               Path(__file__).with_name("environment.py"),
               Path(__file__).with_name("config.json")]
    plot_geometry(run, output)
    manifest = {
        "purpose": "read-only source-shape reconstruction from three saved native poses; no physics",
        "comparison_sha256": {str(comparison_path.resolve()): sha256(comparison_path)},
        "recorded_run_inputs_sha256": {str(path.resolve()): sha256(path) for path in raw},
        "plot_sources_sha256": {str(path.resolve()): sha256(path) for path in helpers},
        "source_geometry_assets_sha256": {
            str(path.resolve()): sha256(path) for path in assets},
        "embedded_source_hashes": comparison["input_sha256"],
        "output_sha256": {str(output.resolve()): sha256(output)},
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()

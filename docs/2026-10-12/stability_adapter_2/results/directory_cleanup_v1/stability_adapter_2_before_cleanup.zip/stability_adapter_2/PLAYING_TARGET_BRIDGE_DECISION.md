# 연주 source 후보와 현재 초기 자세의 호환성 결정

## 검증 완료와 적용 범위

`playing_target_bridge_v1`의 CPU 계약10검사를 통과했다. source30+30과 Thorax6의
residual을 이름으로 합성해 하나의81D float32 목표와 최종 목표의 source history를 계산한다.
원 Base.apply_actions AST의80step×17batch와 residual0을 비교한 최대 차이는
2.384185791015625e−7rad다. Float32 역변환 차이이며 bitwise exact라고 주장하지 않는다.
최종 clipped target의 history 재복원 오차는1.1920928955078125e−7rad다.

66개 잔차 경로의 gradient0.5, held15 exact, native/source 이름순서 permutation,
포화 표시와 유효 범위,9개 잘못된 계약 거절을 확인했다. 물리 동작을 검증한 것이 아니다.
Module 입력은 **source 단계별 후처리를 마친 normalized action**이다.
후처리·420/303 전체 관측·정규화·clock·actor·actuator 연결은 아직 미구현이며
현재 초기 자세를 runtime에 그대로 채택하지 않는다. 새 native/physics/actor추론/학습은0이다.

## 체크포인트 후보 결정

| 후보 | 보존된 평가 근거 | 이번 판단 |
|---|---|---|
| Fret47,500 | full-song F1 0.073485598, sustain1/35 | 앞선 ABI 예시일 뿐, 개선된 연주 prior로 선정하지 않음 |
| Fret47,000 | 조건 수정 전체곡 F1 0.100098126, sustain1/35; event34 검지/string index3/fret4 압현 frame비율15/19 | 좁은 진단 후보. 전체곡·독립 초기화 단일 이벤트 성공 자격 미확인 |
| Strike10,708 | 중단 저장본, 직접 연결된 전체곡 평가 미확인 | 앞선 ABI 예시를 연주 후보로 자동 승계하지 않음 |
| Strike10,000 | 현재 파일 SHA와 직접 연결된64episode single-pick F1 1.0, timing p95 5.628202915ms | 기존 fixed-guitar single-pick의 근거 있는 후보로 우선 보존; 자유 기타 성능은 미확인 |

Fret 두 평가에는 경로와 contract SHA가 연결되지만 평가 시점 checkpoint 파일 SHA가 없다.
현재 checkpoint 파일 SHA만으로 과거 평가 파일 무결성을 새로 증명하지 않는다.
Fret47,000의 조건 수정에는 task/reward 코드 변경이 포함되고 curriculum은 goal_pair/stalled다.
분모는 target-frame이며 독립 시도 수가 아니다. Event34는 순차 전체곡 상태에서의 기록이다.
Strike64episode 평가와42event 영상의 timing p95는 서로 다른 표본이다.
Single-pick 평가를 strum 성공으로 확장하지 않는다.

네 파일 모두 기존 strict G0 loader 자격은false다. Fret stage/기존stalled 및
sealed qualification 부재 등을 그대로 기록했다. Strike의 검증된 외부 평가를 이유로
원본 checkpoint에 자격 필드를 몰래 추가하거나 기존 loader를 우회하지 않는다.
Free-guitar 진단의 자격/후처리 계약은 별도로 명시한 뒤 연결한다.

## 현재 자세와 source 범위의 충돌

현재 LA−2mm 초기 배치의 초기 실제각과 유지 PD목표는 같은 왼손6관절이 Fret
human hard-limit profile/source action 표현 범위를 벗어난다. 아래는 범위까지의 최소
각도 차이이며, 안정한 보정량이나 실제 물리 반응의 예측이 아니다.

| 관절 | 초기 실제각의 최소 변경 rad | 유지 목표의 최소 변경 rad |
|---|---:|---:|
| LH:thumb1_x | 0.167204916 | 0.094772160 |
| LH:thumb1_y | 0.661268771 | 0.617647946 |
| LH:thumb3 | 0.601041615 | 0.503798783 |
| LH:index1_x | 0.168908358 | 0.204711854 |
| LH:middle3 | 0.082816899 | 0.092215002 |
| LH:ring1_x | 0.141499698 | 0.206355035 |

**현재 유지 target을 source history로 조용히 clip해서 붙이지 않는다.**
CPU bridge는 이 시작값을 거절한다. 팔 ±0.3rad 또는 작은 wrist 시험의 결과만으로
위 손가락 변경이 안전하다고 가정하지 않는다. 기존 안정화 배치는 비교 기준으로 보존한다.

## 다음 작은 물리 단위

[Source profile 호환 초기 자세 계획](/home/ajou/yigyu/3/stability_adapter_2/SOURCE_PROFILE_INITIAL_POSE_PLAN.md:1)을 따른다.
손6관절의 초기각과 유지 목표를 source/native 교집합 안에서 다시 정하고 실제 초기
겹침/손바닥 방향과 자유 기타0~5초 유지를 검증한다. 현재 PD/gain/몸통목표/LA−2mm,
root/하체/기타 초기p/q 및 양팔 초기각은 유지한다. 이는 새 초기 자세 시험이지
기타/손 pose의 지속 덮어쓰기나 actor 실행 전 필수 WAIT 단계가 아니다.

그 후 task 후처리/관측/history 연결과 좁은 무학습 연주 baseline을 검증한다.
Fret 원래 실패를 자유 기타 전이 오차와 분리해 평가하며, 공동 residual 학습은
연주 정확도와 초기 world 기타 p/q 유지의 동시 개선을 목표로 한다.

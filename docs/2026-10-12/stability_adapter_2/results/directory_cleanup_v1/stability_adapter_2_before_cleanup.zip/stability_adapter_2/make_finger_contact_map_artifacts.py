#!/usr/bin/env python3
"""Render saved finger body-origin chains and current SDK features in guitar-local coordinates."""
import hashlib
import json
import shutil
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from mpl_toolkits.mplot3d.art3d import Poly3DCollection


ROOT = Path("/home/ajou/yigyu/3")
A = ROOT / "stability_adapter_2"
P = ROOT / "docs/2026-10-12/stability_adapter_2/results/finger_contact_map_v1"
OUT = P / "artifacts"
SNAPSHOT = OUT / "source_snapshot"
PRODUCER = A / "make_finger_contact_map_artifacts.py"
WRAPPER = OUT / "run_finger_contact_map_artifacts.sh"
FIGURE = OUT / "finger_contact_map_snapshots.png"
MANIFEST = OUT / "artifact_manifest.json"
FONT = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
STEPS = (0, 32, 56, 1200)
FINGERS = ("thumb", "index", "middle", "ring", "pinky")
COLORS = {
    "thumb": "#d1495b",
    "index": "#2867a5",
    "middle": "#e08b26",
    "ring": "#7951a8",
    "pinky": "#27856f",
}

# Native and analysis source/wrapper files are copied before rendering. External
# /tmp sources are preserved under source_snapshot/external/ with their full
# original_path retained in the manifest.
SOURCE_FILES = [
    PRODUCER,
    WRAPPER,
    A / "analyze_finger_contact_map.py",
    A / "FINGER_CONTACT_MAP_PLAN.md",
    A / "FINGER_CONTACT_MAP_DECISION.md",
    A / "analyze_three_face_native_features_v2.py",
    A / "native_contacts.py",
    A / "verify_finger_map_configuration.py",
    A / "run_small_wrist_recorded_diagnostic.py",
    A / "environment.py",
    A / "physics_presets.py",
    A / "fixed_lower_environment.py",
    A / "self_collision_environment.py",
    A / "capture_isaac_gym_initial.py",
    ROOT / "isaacgym/docs/api/python/struct_py.html",
    ROOT / "docs/2026-08-19/정리.txt",
    ROOT / "docs/2026-08-19/fret_joint_limits/joint_limit_ranges.json",
    Path("/tmp/run_finger_contact_map.py"),
    Path("/tmp/run_finger_map_configuration.py"),
]


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line]


def relative_source_path(path):
    path = Path(path)
    try:
        return path.resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return "external" + path.as_posix().replace(":", "_")


def archive_sources():
    SNAPSHOT.mkdir(parents=True, exist_ok=False)
    files = []
    expected = {}
    for manifest_path in (P / "source_before_manifest.json", P / "configuration_source_before_manifest.json"):
        manifest = read_json(manifest_path)
        for original, row in manifest.items():
            if original in expected and expected[original] != row["sha256"]:
                raise ValueError("source manifests disagree for " + original)
            expected[original] = row["sha256"]
    for source in SOURCE_FILES:
        if not source.is_file():
            raise FileNotFoundError("missing source to archive: " + str(source))
        original = str(source)
        digest = sha256(source)
        if original in expected and digest != expected[original]:
            raise ValueError("source SHA differs from preserved manifest: " + original)
        copy_path = SNAPSHOT / relative_source_path(source)
        copy_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, copy_path)
        if sha256(copy_path) != digest:
            raise RuntimeError("source copy SHA mismatch: " + original)
        files.append({"original_path": original, "copy_path": str(copy_path), "sha256": digest})
    record = {"producer_sha256": sha256(PRODUCER), "wrapper_sha256": sha256(WRAPPER), "files": files}
    (OUT / "source_snapshot.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    return record


def input_hashes(analysis, config, snapshot):
    paths = {Path(path) for path in analysis["input_sha256_before"]}
    paths.update(Path(path) for path in config["input_sha256_before"])
    paths.update(SOURCE_FILES)
    paths.update({
        P / "analysis.json", P / "features.jsonl", P / "analysis.log", P / "analysis_execution.json",
        P / "source_before_manifest.json", P / "configuration_clarification.json",
        P / "decision_inputs.json",
        ROOT / "docs/2026-08-19/정리.txt",
        ROOT / "docs/2026-08-19/fret_joint_limits/joint_limit_ranges.json",
        P / "configuration.log", P / "configuration_execution.json",
        P / "configuration_source_before_manifest.json", FONT,
        PRODUCER, WRAPPER, OUT / "source_snapshot.json",
    })
    for row in snapshot["files"]:
        paths.add(Path(row["copy_path"]))
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError("missing sealed inputs: " + ", ".join(sorted(missing)))
    return {str(path): sha256(path) for path in sorted(paths)}


def verify_analysis(analysis, config, feature_rows):
    checks = analysis["checks"]
    # The earlier single_substep check used a default for a missing saved key.
    # The separate clarification record supersedes it; runtime SimParams readback
    # was not performed, so do not turn source configuration into native proof.
    remaining = [value for name, value in checks.items() if name != "single_substep"]
    if len(checks) != 12 or not all(remaining):
        raise ValueError("analysis checks other than the superseded substep check must pass")
    if len(config["checks"]) != 5 or not all(config["checks"].values()):
        raise ValueError("configuration clarification checks must all pass")
    if config["supersedes_analysis_check"] != "single_substep":
        raise ValueError("expected configuration clarification to supersede single_substep")
    if config["configured_substeps_from_consumed_source"] != 1:
        raise ValueError("consumed source does not assign one configured substep")
    if config["native_SimParams_readback_performed"] or config["saved_physics_parameters_contains_substeps"]:
        raise ValueError("unexpected native substep readback evidence")
    if len(analysis["input_sha256_before"]) != 17 or len(feature_rows) != 1198:
        raise ValueError("unexpected analysis input or feature row count")
    snapshots = {row["physics_step"]: row for row in analysis["snapshots"]}
    if set(snapshots) != set(STEPS):
        raise ValueError("expected snapshots at steps 0, 32, 56, and 1200")
    expected_counts = {0: 0, 32: 2, 56: 0, 1200: 1}
    by_step = {}
    for row in feature_rows:
        by_step.setdefault(row["physics_step"], []).append(row)
    for step in STEPS:
        current = snapshots[step]["current_positive_features"]
        if len(current) != expected_counts[step] or len(by_step.get(step, [])) != expected_counts[step]:
            raise ValueError("current positive feature count mismatch at step " + str(step))
        embedded = sorted((x["human_body"], x["guitar_body"], x["contact_row"]) for x in current)
        raw = sorted((x["human_body"], x["guitar_body"], x["contact_row"]) for x in by_step.get(step, []))
        if embedded != raw:
            raise ValueError("snapshot/raw feature rows mismatch at step " + str(step))


def mm(points):
    return [[float(coord) * 1000.0 for coord in point] for point in points]


def draw_region(ax, vertices, label, facecolor, alpha, linestyle="-"):
    points = mm(vertices)
    patch = Poly3DCollection([points], facecolor=facecolor, edgecolor=facecolor,
                             linewidth=0.8, alpha=alpha, linestyles=linestyle)
    ax.add_collection3d(patch)
    # Draw a second thin outline so the patch remains legible when transparent.
    closed = points + [points[0]]
    ax.plot([p[0] for p in closed], [p[1] for p in closed], [p[2] for p in closed],
            color=facecolor, linewidth=0.75, alpha=0.9, linestyle=linestyle)


def render(analysis, feature_rows):
    snapshots = {row["physics_step"]: row for row in analysis["snapshots"]}
    feature_by_step = {}
    for row in feature_rows:
        feature_by_step.setdefault(row["physics_step"], []).append(row)
    regions = analysis["regions_G_m"]
    all_xyz = []
    for snapshot in snapshots.values():
        for chain in snapshot["chains"].values():
            all_xyz.extend(mm(chain["origins_G_m"]))
    for polygon in regions.values():
        all_xyz.extend(mm(polygon))
    for rows in feature_by_step.values():
        all_xyz.extend(mm([row["guitar_feature_G_m"] for row in rows]))
    mins = [min(point[i] for point in all_xyz) for i in range(3)]
    maxs = [max(point[i] for point in all_xyz) for i in range(3)]
    padding = [max(8.0, (maxs[i] - mins[i]) * 0.055) for i in range(3)]
    limits = [(mins[i] - padding[i], maxs[i] + padding[i]) for i in range(3)]

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 10.5})
    fig = plt.figure(figsize=(17.5, 15.0))
    fig.suptitle("Saved +0.008 rad native run: finger body-origin chains and current SDK features in G",
                 fontsize=15, y=0.965)
    legend_handles = [
        Line2D([0], [0], color=COLORS[finger], linewidth=2, label=finger.title() + " body origins")
        for finger in FINGERS
    ]
    legend_handles.extend([
        Line2D([0], [0], marker="^", linestyle="None", markerfacecolor="none",
               markeredgecolor="#333333", label="*_top body origin"),
        Line2D([0], [0], marker="o", linestyle="None", markerfacecolor="#777777",
               markeredgecolor="black", markersize=6, label="Current λ>0 SDK feature point"),
        Patch(facecolor="#9bb6c8", edgecolor="#476b84", alpha=0.18, label="Front guide (9.3 mm)"),
        Patch(facecolor="#b9c5cf", edgecolor="#738493", alpha=0.14, label="Front outer guide (11.230006 mm)"),
        Patch(facecolor="#a891c4", edgecolor="#674b86", alpha=0.16, label="Thumb-back guide (−8 mm)"),
        Patch(facecolor="#a7c5a0", edgecolor="#64875c", alpha=0.16, label="Palm-side guide"),
    ])

    for panel_index, step in enumerate(STEPS, start=1):
        snapshot = snapshots[step]
        ax = fig.add_subplot(2, 2, panel_index, projection="3d")
        draw_region(ax, regions["front"], "front", "#9bb6c8", 0.13)
        draw_region(ax, regions["front_outer"], "front outer", "#b9c5cf", 0.10, "--")
        draw_region(ax, regions["thumb"], "thumb back", "#a891c4", 0.14)
        draw_region(ax, regions["palm"], "palm side", "#a7c5a0", 0.14)

        for finger in FINGERS:
            chain = snapshot["chains"][finger]
            points = mm(chain["origins_G_m"])
            color = COLORS[finger]
            ax.plot([p[0] for p in points], [p[1] for p in points], [p[2] for p in points],
                    color=color, linewidth=2.0, alpha=0.95)
            ax.scatter([p[0] for p in points[:3]], [p[1] for p in points[:3]], [p[2] for p in points[:3]],
                       color=color, s=22, depthshade=False)
            top = points[3]
            ax.scatter([top[0]], [top[1]], [top[2]], marker="^", s=52,
                       facecolors="none", edgecolors=color, linewidths=1.4, depthshade=False)
            ax.text(top[0], top[1], top[2], finger,
                    color=color, fontsize=8.5, ha="left", va="bottom")

        current = feature_by_step.get(step, [])
        for feature in current:
            finger_name = feature["human_body"].split(":", 1)[1].replace("3", "")
            if finger_name not in COLORS:
                raise ValueError("unrecognized feature finger body " + feature["human_body"])
            point = mm([feature["guitar_feature_G_m"]])[0]
            ax.scatter([point[0]], [point[1]], [point[2]], s=48, marker="o",
                       color=COLORS[finger_name], edgecolors="black", linewidths=0.7, depthshade=False)

        ax.set_title("Step {} · t = {:.3f} s · current λ>0 SDK feature points: {}".format(
            step, snapshot["time_s"], len(current)), pad=8)
        ax.set_xlabel("X_G (mm)", labelpad=3)
        ax.set_ylabel("Y_G (mm)", labelpad=3)
        ax.set_zlabel("Z_G (mm)", labelpad=3)
        ax.set_xlim(*limits[0])
        ax.set_ylim(*limits[1])
        ax.set_zlim(*limits[2])
        ax.set_box_aspect([high - low for low, high in limits])
        ax.set_proj_type("ortho")
        ax.view_init(elev=23, azim=-57)
        ax.grid(True, alpha=0.2)

    fig.legend(handles=legend_handles, loc="lower center", ncol=5, frameon=False,
               bbox_to_anchor=(0.5, 0.055), fontsize=8.2)
    fig.text(0.5, 0.018,
             "Body-origin chains are not anatomical pads. Hollow triangles mark *_top origins; dots show current positive SDK feature rows only. Reference patches are finite guides, not contact constraints or cooked geometry.",
             ha="center", fontsize=8)
    fig.subplots_adjust(left=0.04, right=0.97, top=0.92, bottom=0.13, wspace=0.06, hspace=0.12)
    fig.savefig(FIGURE, dpi=190)
    plt.close(fig)


def main():
    if FIGURE.exists() or MANIFEST.exists() or (OUT / "source_snapshot.json").exists():
        raise SystemExit("refusing to overwrite; use a new artifact path")
    allowed = {WRAPPER.name}
    if OUT.exists() and {path.name for path in OUT.iterdir()} != allowed:
        raise SystemExit("artifact folder must contain only the pre-run invocation wrapper")
    analysis = read_json(P / "analysis.json")
    config = read_json(P / "configuration_clarification.json")
    feature_rows = read_jsonl(P / "features.jsonl")
    verify_analysis(analysis, config, feature_rows)

    source_snapshot = archive_sources()
    before = input_hashes(analysis, config, source_snapshot)
    for path, expected in analysis["input_sha256_before"].items():
        if before[path] != expected:
            raise ValueError("analysis input SHA mismatch: " + path)
    for path, expected in config["input_sha256_before"].items():
        if before[path] != expected:
            raise ValueError("configuration input SHA mismatch: " + path)
    if before[str(PRODUCER)] != source_snapshot["producer_sha256"]:
        raise ValueError("producer differs from pre-run source snapshot")
    if before[str(WRAPPER)] != source_snapshot["wrapper_sha256"]:
        raise ValueError("wrapper differs from pre-run source snapshot")

    render(analysis, feature_rows)

    after = input_hashes(analysis, config, source_snapshot)
    producer_after = sha256(PRODUCER)
    wrapper_after = sha256(WRAPPER)
    if before != after or source_snapshot["producer_sha256"] != producer_after or source_snapshot["wrapper_sha256"] != wrapper_after:
        raise RuntimeError("producer, wrapper or sealed inputs changed during render")
    manifest = {
        "producer": str(PRODUCER),
        "producer_sha256_before": source_snapshot["producer_sha256"],
        "producer_sha256_after": producer_after,
        "wrapper": str(WRAPPER),
        "wrapper_sha256_before": source_snapshot["wrapper_sha256"],
        "wrapper_sha256_after": wrapper_after,
        "inputs_sha256_before": before,
        "inputs_sha256_after": after,
        "outputs_sha256": {FIGURE.name: sha256(FIGURE)},
        "native_calls": 0,
        "physics_steps": 0,
        "actor_inference_calls": 0,
        "training_updates": 0,
        "figure": FIGURE.name,
        "scope": "saved native G-local body-origin chains and current positive SDK feature points; configuration correction included; no simulator/model run",
        "configuration_correction": {
            "supersedes_analysis_check": config["supersedes_analysis_check"],
            "configured_substeps_from_consumed_source": config["configured_substeps_from_consumed_source"],
            "native_SimParams_readback_performed": config["native_SimParams_readback_performed"],
        },
    }
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"figure": str(FIGURE), "sha256": manifest["outputs_sha256"],
                      "sealed_input_count": len(before), "snapshot_counts": [0, 2, 0, 1]}, ensure_ascii=False))


if __name__ == "__main__":
    main()

# Strike 관측 schema 메타데이터 보완

독립 검수에서 audit_playing_prior_contracts.py의 Strike observation_schema가 null인
표시 오류를 발견했다. Strike 계약은 Fret과 달리 config.strike.observation_contract에
schema를 저장한다. 원본 CPU audit/출력/계획은 소비된 증거로 보존한다.

새 audit_playing_prior_contracts_v2.py는 이 field를 공식 loader와 같은 위치에서 읽고
task별 예상 observation schema까지 assert한다. 나머지 입력/예시 checkpoint는 동일하다.
이번 body9_strap_minus4mm_v1/contract_correction에 새 결과를 저장한다.
이 보완은 checkpoint 선정, 모델추론, 학습, 새 물리실행을 추가하지 않는다.
이전 action30/관측420·303/이름60+Thorax6 결론은 유지한다.

# 허벅지·왼손 접근 자세에서 손가락 지지 제어

사용자 요청: 기존 두 지지점 접근 자세에서 손가락으로 기타를 잡는 추가 제어를
진행한다. 이전 near2µm는 source 손바닥–넥 간격 약2µm였으나 native 왼손 접촉0이다.
오른쪽 허벅지 contact는 이전24/24 step에 있었다. 두 지지가 이미 성공했다고 전제하지 않는다.
root·하체 고정, 몸통9 PD hold, self-collision ON, 자유 기타+기존 passive strap을 유지한다.
초기 기타 p/q·절대 LA 1.1018469719600776m와 양팔24 PI/PD를 첫 비교에서 유지한다.

제어권: 현재 연주 기준은 H0다. 66관절 최종 목표는 H0+양팔24 hold 보정+
왼손 손가락 grip 보정으로 합치며 모델 한계 안에서 제한한다. 손목/팔 목표는 기존
PI 범위, 손가락은 별도 제한된 목표 보정만 받는다. 상태 덮어쓰기·기타 고정·손 부착·
전체 손 제어권 영구 박탈은 없다. 연주 명령과 접촉 상태를 함께 조율하는 최종 학습은
이번 지지 진단 이후 결정한다. 오른손은 먼저 기존 목표를 유지해 변수를 줄인다.

1. 왼쪽 index/middle/ring/pinky의 (1_x,2,3)12각을 원 자세 대비
   (.7,1,.6)*a로 조정한 a=0/.15/.3/.6rad 초기화-only FK를 확인한다.
   손바닥·팔·기타 배치가 유지되는지, finger–neck unsigned convex 거리와
   source hull 교차를 측정한다. 초기화 진단은 runtime 제어와 구분한다.
   source 거리를 native 접촉 또는 cooked collider 인증으로 해석하지 않는다.
2. H0에서 시작하는 목표각 ramp를 60Hz로 적용한다. a 최대 .3/.6rad,
   a 변화율 최대6rad/s이며 spread1_z·엄지는 처음 유지한다. 같은 초기 상태의
   기준/약한 grip/강한 grip/접촉 감지 grip을 각0.1초 비교한다.
   접촉 감지형은 직전 native contact cache에서 양의 lambda가 있는 digit의
   추가 굽힘을 멈추고 목표를 유지한다. 다른 사람 링크와 접촉해도 추가 굽힘을
   멈춘다. lambda의 크기를 뉴턴이나 grip force 목표로 쓰지 않는다.
3. 왼손 실제 접촉과 기타 p/q 오차가 개선된 경우만0.5초로 연장한다.
   접촉이 없거나 손가락 응답이 늦으면 FK/실제각/접촉 기록을 보고 다음 소단계를
   먼저 기록한다. 초기 grip 각도 후보는 교차 없는 경우에만 별도 시험한다.
   기준 재현, 하체 모든 state 고정, command가 state를 바꾸지 않음,
   finger 목표각/변화율, 비finger 목표 유지, PD/LA/모델/입력 불변을 검증한다.
4. 실제 Isaac Gym camera로 선택 실행의 초기/종료 장면과 짧은 영상을 촬영한다.
   raw·로그·이미지 설명은 docs/2026-10-12/stability_adapter_2/results/finger_grip_hold_v1/,
   구현·trial 설정은 stability_adapter_2/에 저장하고 별도 검토한다.

8월19일 자료: joint_limit_ranges.json은 hard-limit 렌더 기록이며 2% reset inset
초기각을 포함한다. 정리.txt의 왼손 p01~p99는 한 연주자 데이터의 참고 분포다.
오른손 제한에 복사하거나 새 과제의 필수 범위로 강제하지 않는다. 새 관절 제한·gain·
strap 조정을 첫 단계에 함께 도입하지 않는다. 양손/몸통 충돌 정책도 유지한다.

- [x] 굽힘 방향·초기 source 겹침 확인
- [x] 같은 H0의 bounded finger target 비교
- [x] 결과에 따른 후속 소단계 및 native 이미지/영상
- [x] 검증·문서·독립 검토 — Critical/Warning/Suggestion 없음

첫 초기화-only 결과: a=.6에서도 가장 가까운 fingertip source 거리는47.092mm다.
굽힘 방향은 넥을 향하지만 아직 감싸지 못한다. sameH0 기준과 강한 ramp .6만
먼저0.1초 확인하고 중복인 약한/접촉감지 비교는 보류한다. 초기 grip seed는
a=.9/1.1/1.3rad를 추가 검사한다. MCP는 index .75rad/다른 digit .85rad로 제한해
8월 후보 범위를 부드럽게 선호한다(PIP/DIP는 현재 native한계 안). 초기 사람–기타
교차나 양손 source 교차가 있으면 seed로 쓰지 않는다. 기존 초기 probe/producer
및 baseline 실행 당시 producer 사본을 보존한다.

같은 H0 강한 ramp .6rad의0.1초: index PIP 실제+.118658rad, 목표+.6rad이며
왼손 contact0이다. 기타4.037516mm/.639890°로 기준4.035079mm/.639349°보다
조금 나쁘다. deep seed .9는clear(closest fingertip21.706mm),1.1은
LH:pinky2–RH:thumb3 source 교차,1.3은 기타/fret source 교차라 제외한다.
다음 초기 seed는 index/middle/ring a=1.16/1.20/1.24와 pinky=.9 조합3개다.
MCP cap은 유지하고 source-clear 후보만 같은 기타 p/q·LA에서 native0.1초
초기 grip 유지 vs 추가 contact-aware cap .15rad를 비교한다. finger2/3 한계와
source 조건은 사용 모델 범위 내이며 초기 본체/손바닥 위치를 유지한다.

source-clear seed120의0.1초 유지/접촉감지 .15: LH 중지/약지 contact41/39행,
position30.589555/33.165716mm, rotation4.264491/4.597716°로 크게 악화된다.
후기 연장하지 않는다. 현재 L_Shoulder_x 첫step+.003477rad/0.1초+5.97°이고
팔/몸통 drift가 손가락의 넥 밀기와 함께 관찰됐다(단독 원인 인증 아님).
다음 소단계: 같은 seed120에서 양팔24 PD 목표각을 각±.03rad만 변화시킨
첫1 physics-step 응답24열을 계측한다. 처음 free 결과와의 차이로 국소 선형
응답을 만들고 초기 실제 arm각 변화 최소화 보정을 bounded least squares로
구한다. 보정은 기존 C02±.3rad∩model 및 초기각±.15rad 안에 둔다. gain/torso/
finger/strap/initial pose 변경은 없다. 기존 PI는 실제 초기각을 유지하려는
오차를 사용하고 상수 보정+PI가 최종 목표 한계 안에 있도록 PI 허용범위를
같이 조정한다. 고정 힘/상태 덮어쓰기가 아니라 native PD 목표 preload다.
국소1-step 추정은 중력 토크 인증이나 후기 안정 보증이 아니며0.1초로 직접
검증한다. 보정 전후와 finger contact .15 조건을 비교하고 개선 시만 연장한다.
실행 settings는 검증된 probe/각도/SHA/source_clear와 연결해 검사하고 실패한
rollout은 누적 states·controls·contacts와 failure.json을 보존한다.

1-step preload±.15의 실제0.1초 유지/접촉감지:17.854665mm/2.629745° 및
21.180441mm/3.044325°로 seed의 악화는 줄었으나 openH0 기준보다 여전히 나쁘다.
LH:palm은 약30mm 아래로 이동했고 실제 손가락 contact는 계속 짧다. 소단계 추가:
이미 측정한 response를 사용해 (재측정 없이) target preload 한계를 native∩초기각±.3rad로
넓혀 재적합한다. C02±.3은 초기 pose 탐색 범위로 보존하지만, 실제 초기각을 유지하기
위한 최종 PD 목표 bias는 그 box와 별도로 둔다. torso target·PD gain·cap·strap·초기각은
유지하고 팔 실제 자세/손가락 contact/기타오차를0.1초 직접 확인한다. PI도 같은 최종
target box로 anti-windup하며 몸통/하체/손가락 초기 pose는 변경하지 않는다.

±.3 preload0.1초 hold/contact .15 결과5.076611mm/1.056306° 및
9.247243mm/1.560001°다. LH contact는 hold11개step에 있으나 팔 실제 자세는
LH:palm 약17.5mm 하강을 허용한다. 기준4.035079mm/.639349°보다 아직 나빠
장기 연장은 보류한다. 같은 응답으로 초기 pose±.5rad∩native의 PD target
preload를 추가 적합/0.1초 검증한다. 이것은 초기 관절 자세 변경이 아니며 body/
finger/torso/PD effort cap과 기타 p/q/LA는 동일하다. 몸통·손·기타 state를
덮어쓰지 않으며 실제 자세 drift와 최소 제약을 별도로 판정한다.

±.5 preload + 초기 grip 유지0.1초는3.526166mm/.638752°로 openH0 기준의
4.035079mm/.639349°보다 위치오차가 줄었고 회전도 악화되지 않았다. 추가 contact
closure .15는4.527704mm/.969836°라 보류한다. hold만0.5초로 연장하며 현재
selfcollision ON의 openH0 baseline도 같은 길이로 비교한다. 후기 유지 판정은
짧은 contact 행 수만으로 하지 않는다. 마지막구간 contact 유지/기타 p/q/
팔·torso 실제 drift/손바닥 위쪽 반구 proxy를 기록한다. 0.5초 이후1초 진단은
오차와 접촉 추세가 개선된 경우만 한다. 이 단계의 정지 유지 참고 목표는
position 최대10mm·rotation 최대2°/0.5초와 마지막0.1초 지속적인 손 지지다.
값을 충족하지 못하면 안정화 성공으로 채택하지 않는다.

0.5초 실제 결과: grip+preload는26.522614mm/3.497190°로 openH0
18.740199mm/2.842119°보다 악화했다. 손 접촉은step59 이후 사라졌고
LH:palm world 위치가 초기에서44.612mm 내려갔다. 초기 몸통 목표를 유지해도
실제 torso가 약2~3° 움직이므로 joint-H0 hold만으로 world 손 지지가 유지되지 않는다.
1초 연장은 보류하고 다음 소단계를 진행한다.

다음 제어권 소단계: 초기 seed120의 양손 native 링크 원점 위치/회전이 양팔24
각에 반응하는 FK Jacobian을 각+.001rad(한계 가까우면−.001) 초기화-only24열로
계측한다. 이는 정적 미분 측정이며 겹침 없는 새 초기자세 채택이 아니다.
초기 양손 world pose 유지 오차에 기타 goal−actual 위치/회전 오차를 더해
손 목표를 최대10mm·.05rad만 이동시킨다. 위치/회전 비중 .08m/rad,
damping .01의 역행렬로 arm 보정을 계산하며 Kp2·Ki4/s,
각±.15rad·최대1rad/s로 제한한다. 최종 arm target은 기존 preload+PI+
새 palm 보정이며 전체 초기각±.5rad∩native 유지, PI antiwindup은
palm 보정이 차지한 target 여유를 반영한다. 몸통/손가락/PD/strap은 그대로다.
첫0.1초 계약 검증 후0.5초를 확인한다. 접촉을 유지하면서 기타 p/q가 개선되는지
직접 평가하며 제한을 통과한 계산만으로 안정성을 주장하지 않는다.

World-palm feedback0.1초는3.150733mm/.658176°이고0.5초는
16.170221mm/2.379811°다. 초기 openH0보다0.5초 두 오차가 작고 마지막step120에
손가락 접촉이 남아 동일0.5초 재검증 후1초로 연장한다. 중간 접촉gap은 남고
0.5초 참고목표10mm/2°는 실패라 안정성공은 아니다. Damping단위는m/rad다.
독립검수에서 palm 성분 단독 antiwindup이 최종 합성 제한을 놓친다고 지적했다.
최종 전달 목표와 clipping 전 PI+preload+palm 합성값을 대조해 포화방향의
palm 적분을 rollback했다. 새v2 0.5초의 실제state/contact/trace는기존과같다.
개선추세와 마지막접촉을 확인했으므로 v2와openH0 각1초 비교를 진행한다.
PD/초기각/LA/constraint는 유지하고 이 비교에서gain/범위를넓히지 않는다.

1초 world-feedback:16.170221mm/2.517144°로 baseline20.341143mm/5.282789°보다
작지만 손가락 contact는step131 이후소실한다. 아직 지속grip은아니다. 다음소단계는
같은조건에 contact-aware 추가굽힘 cap .05rad만결합해0.1초 비교한다.
이전feedback없는 .15 closure가악화해더작은범위로제한한다. 접촉양의lambda면
해당digit추가굽힘을멈추고소실시남은범위안에서만닫는다. 기준보다악화하면
연장하지않고world-feedbackhold의실제native영상으로현상과다음계획을남긴다.

작은 추가굽힘 .05rad의0.1초는3.048302mm/.733724°로 위치만개선/회전악화라
연장하지않는다. 손가락actual각은1초seed목표에가깝지만LH:palm은31.053mm
하강한다. 새 world-feedback의Elbow 계열 한축이−.15rad에포화해다음소단계는
palm보정한계만±.3rad로넓혀같은.5초직접검증한다. 변화율1rad/s,최종
preload+PI+palm 전체±.5rad/native와antiwindup,PD/초기자세/LA는동일하다.
이것은초기pose범위확장이아니며상체·손위치오차를줄이는runtime목표범위다.
0.5초에서두기타오차와후기접촉이개선되는경우만1초로연장한다.

Cap .3의0.5초는 states/trace/contacts가cap .15와exact다. .5초말보정최댓값
.132rad로이구간에서는기존.15cap이활성화되지않았다. 따라서개선도악화도아니며
cap활성구간(이전1초−.15포화)이있는1초를한번직접비교한다. 같은자료를
새성능개선으로세지않는다. 이진단후현재조건의전체native영상을기록한다.

이번 소단계 결론: 초기 12 finger seed + 양팔 24 preload/PI + world-palm/guitar 오차
feedback의 1초 최대 기타 오차는 20.341143mm/5.282789°에서 16.170221mm/2.517144°로
줄었다. 초기 finger와 runtime 제어를 함께 바꾼 조합 비교이며 finger 단독 효과는 아니다.
LH 중지/약지3의 양의 raw lambda는 최종 step130까지, 접촉 행은 131까지 있으며
이후 소실한다. LH:palm 접촉은 없어 엄지·손바닥의 opposing grip 완성은 아니다.
참고 목표 10mm/2°와 마지막 0.1초 손 지지는 실패해 학습·연주 정책으로 채택하지 않는다.
Palm cap 0.3은 최대 오차/접촉 유지가 같고 종료 값만 약 0.082mm/0.034° 개선돼
작은 0.15를 다음 진단 기준으로 유지한다. 반복 통계와 물리 지터 범위는 아직 인증하지 않았다.
현재 연주 기준 H0에서 arm24 + LH finger12만 추가 보정했으며 주요 66 action 구조와
양손 모든 자유도를 사용할 최종 연주 목표는 유지한다. 이번 제어는 진단 기준이며,
최종 연주 손가락 제어권을 영구 점유하는 설계가 아니다.

실제 Isaac Gym camera로 위 0.15 조건을 0..1초 61시점 × 2뷰 촬영했고
states/trace/contacts/controls/leg_torques 5 raw가 headless 실행과 exact다.
Render는 물리 state를 변경하지 않으며 root/lower 모든 state 고정, 기타 free,
passive strap, 몸통9 H0 목표 hold를 유지했다. 현재 phase 총 79 native 초기화/1872 steps다.
최종 raw 검증은 `verification.json`을 따른다. 구형 baseline controls에 없는 0 bias와
empty palm field를 정규화해 prefix를 대조했으며 첫 검증 실패 기록도 보존했다.

다음 소단계 계획:

1. 현재 seed의 엄지1xyz/2/3와 넥 형상 상대 위치를 native FK/source로 대조하고,
   엄지가 중지·약지 접촉의 반대쪽에서 받칠 수 있는 초기각 후보를 하드 한계 안에서
   소수 검사한다. 모든 finger–기타/양손 초기 교차를 거절하며 엄지 강제 부착은 없다.
2. Source-clear 후보만 기존 0.15 feedback 조건의 0.1초, 개선 시 0.5초를 검증해
   접촉 방향·유지와 기타 오차를 분리 평가한다. 손바닥 지지 부재와 torso 실제 약 3.9°
   drift도 측정하되 PD/strap 변경을 같은 시험에 섞지 않는다.
3. 새 학습 구조는 양손 연주 기준과 안정화 보정의 권한·포화·접촉 상태 관계를 검증한 후 결정한다.

최종 검증·검토: 새 구현9개 문법 검사, 22개 raw/provenance/보존 검증을 통과했다.
별도 검수에서 seed 연결·실패 자료 보존·최종 목표 antiwindup·촬영 실패 cleanup
경고4건을 해결했으며, 현재 남은 Critical/Warning/Suggestion은 없다.
검수는 저장 원자료의 3×60 제어 update를 독립 재계산해 목표각 차이 최대
6.61e−8rad, 실제 영상 decode와 SHA·원본 보존을 확인했다. 물리 안정화 성공과
코드·증거 검증 통과는 구별한다. 상세 기록은 결과 phase의 `review.md`를 따른다.

# 반복 초기 배치 검사의 첫 구현 단위

작성일: 2026-10-06. 목적: 관절각/초기 스트랩 설정을 바꾸는 반복 실험에서 시작 관통을
먼저 찾고, 이후 기타 움직임과 구분해서 기록한다. 기존 실험·공용 자산은 변경하지 않는다.

## 기존 도구와 필요한 범위

공용 `GuitarPenetrationMonitor`와 strike의 `RightGuitarPenetrationMonitor`는 양쪽 팔/손의
점 샘플과 근사 기타 solid로 깊이·초기 관통·swept 관통을 기록한다. 전신 충돌 형상 검사와
첫 자유 step 전 판정은 별도 작업이다. contact force=0이나 샘플 점 관통=0만으로 시작 겹침 없음이라 하지 않는다.

첫 구현은 CPU 초기 상태의 native rigid-body pose와 원본 XML 충돌 형상으로 **정적 거리 검사**를 한다.
MuJoCo 3.2.3의 geometry query를 보조 진단으로 사용하며 dynamics는 실행하지 않는다.
PhysX의 실제 cooked mesh/접촉 skin과 완전히 같은 query라는 보장은 없으므로 runtime contact와
교차 검증할 때까지 자동 시작 허용·거부 기준으로 적용하지 않는다. 검사 결과가 오류/미지원이면 통과로 표시하지 않는다.

## 이번 계획·검증

- [x] 활성 humanoid–guitar 형상 쌍·부위 이름·signed gap·가까운 점 기록 → 합성 box의 분리/접촉/관통 검사
- [x] 실제 첫 step 전 장면 검사 → native pose 보존·원본 자산 hash·양손/전신 형상 범위 확인
- [x] CPU 형상 진단 이미지·설명·로그 저장 → 실제 장면 렌더와 구별
- [x] 별도 change-reviewer 검수 → CPU 정적 보조 진단 범위, Critical/Warning/Suggestion 없음

## 다음 반복 실험 흐름

관절 초기값/스트랩 길이를 run별 설정 파일에 기록 → 초기 상태 생성 → 첫 step 전
geometry·손바닥 방향·관절 한계 검사 → 적합한 후보만 rollout → 기타 p/q 오차·속도·관통을 기록한다.
초기 관통 후보는 physics가 밀어내서 해소한 뒤 좋은 초기 자세라고 판단하지 않는다.
현재 도구는 공용 H0를 먼저 진단한다. run별 관절각/길이 입력 연결은 그다음 작은 구현 단위다.

실행 중 정상 접촉은 지지에 필요하므로 금지하지 않는다. 경미한 접촉/계산 오차와 실제 관통을
구별할 거리 허용치, 큰 기타 오차에서 계속 보정할지 trial을 종료할지는 사용자와 결과 검토 후 정한다.
종료 후의 새 trial 초기화는 허용하되 실행 중 기타 pose를 반복 덮어쓰는 보정으로 사용하지 않는다.
reset마다 검출 기록·실패 이유·설정·초기 목표·원본 frame을 저장하고 서로 다른 trial의 오차를 연결하지 않는다.

## 첫 검증 결과와 판정 한계

`initial_overlap_v2`는 H0/S0의 native 초기 상태를 읽어 human 54개·guitar 26개,
총 1,404쌍을 검사했다. native 총 형상은 55/28개이며 제외 형상을 반영한 부위별 활성 개수가
원본 XML과 일치한다. 양손뿐 아니라 몸통·다리·발도 검사 범위다. query 전후 native 관절/몸체
상태가 동일하고 추가 native physics step은 0이다. 환경 생성의 prepare 후 초기 상태 복원과는 구별한다.

R_Hip–G:body에서 음수 query 값 -1.331mm, R_Elbow–G:body에서 양수 값 +7.154mm가 나왔다.
**-1.331mm를 실제 관통 깊이라고 해석하지 않는다.** MuJoCo 3.2.3은 analytic 관통 100mm인
axis-aligned box 쌍에서 -50mm를 반환했다. 분리 10mm·접촉 0·관통 부호·20mm 밖 제외는
합성 검사로 확인했다. 음수 크기를 임의로 두 배 보정하거나 모든 형상에 같은 변환을 적용하지 않는다.
음수는 겹침 후보, 양수는 보조 backend의 분리 결과이며 PhysX clearance 인증이 아니다.
20mm보다 먼 쌍은 정확한 최단 거리 대신 검색 범위 밖으로 기록한다.

분리·접촉·관통·검색 범위 합성 검사 1개와 기존 물리 계약 6개가 통과했다.
v1의 첫 검사 실패(관통 깊이 가정, MuJoCo-before-Gym import 충돌)는 로그를 보존하고,
Gym 선행 import와 query 의미를 명시한 v2로 검증했다. geometry query 자체에 dynamics는 없다.
이미지는 native world pose에 원본 충돌 형상을 놓은 CPU 진단이며 실제 Isaac Gym 렌더가 아니다.

chair/ground, humanoid 자체 충돌, 스트랩의 천 충돌은 이번 범위 밖이다.
run별 초기 관절각/절대 스트랩 길이 입력과 batch trial 기록·hash 검증 재개는 구현했다.
허용 거리·PhysX runtime 판정·자동 start gate/reset·feedback은 아직 구현하지 않았다.

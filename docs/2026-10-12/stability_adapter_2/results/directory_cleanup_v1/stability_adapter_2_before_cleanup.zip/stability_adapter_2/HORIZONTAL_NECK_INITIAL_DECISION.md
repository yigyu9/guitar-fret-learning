# 넥 수평·앞판 정면 초기 회전 후보 결과

2026-10-09 사용자 뜻에 따라넥을바닥과평행하게하고줄이있는앞판을정면(+Y)으로향하게하는0°를우선초기회전후보로권한다. root가실제IsaacGym0°의front/side/hands를확인했다. 바디중심은본채팅의직전비교world[169.58454,65.01235,675.97298]mm를유지했다. 몸통/하체/양팔/손상태는유지했고기타p/q만바꿨다.

- 실제0°root p world: [-0.2304154634,0.0867123455,0.6759729981]m.
- 실제0°q xyzw: [-0.5,0.5,0.5,0.5]. pure 계산의반대부호q도같은회전이다.
- necklocal+Y=world[-1,0,0],frontlocal+Z=world[0,1,0].
- 단독비교표본: 넥-10/0/+10°, 앞판법선정면을유지. ±10°는이번비교표본이며연주중허용각의강제경계로채택하지않는다.

순수13검사와독립사전검수후actual native3배치를촬영했다. case별7checks(물리0/human bodyDOFexact/추가render readonly/noPhysicsCalls/frontY/center/elev)와aggregate2checks가모두true다. NVIDIA driver/device는현재접속불가였으나CPUPhysX+Mesa소프트웨어VulkanICD로IsaacGym정적카메라가작동했다. CUDA학습자원가용성을확인했다는뜻이아니다. 로그의visual geom/importer경고는그대로보존한다.

수평넥과현재왼손사이에높이차이가명확하므로다음설계단계는왼팔·손초기자세를낮춰맞추는것이다. 이번에는관절각/PD/스트랩길이/기본시작pose/controller/gate/reward/학습을변경하지않았다. 팔손재배치·관통·접촉·자유기타유지는아직검증하지않아안정자세로채택하지않는다. 오른손의연주위치도기타로컬좌표에서다시확인해야한다. 기타고정/강제손부착/물리중pose덮어쓰기는없다.

대표native후보: /home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/horizontal_neck_initial_v1/native/scene/candidate_001/pose.json. 동일staticUI로로드하면계산시body-center pivot과이후UIactor-root pivot차이를유의한다.

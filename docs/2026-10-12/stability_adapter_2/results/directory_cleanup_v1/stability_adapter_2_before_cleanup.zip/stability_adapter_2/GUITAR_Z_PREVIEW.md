# 기타 초기 Z 소폭 상승: 정적 배치 비교

사용자가 하체 초기각 변경 대신 기타 초기 Z를 조금 올리는 방향을 제안했다.
우선 저장된 H0 t=0 상태에서 +0/+2/+5/+10/+15mm를 비교한다. humanoid root·전신
초기각·기타 회전·절대 strap rest length L_A는 유지한다. 이 단계는 source geometry
정적 비교이며 native 환경의 초기 목표나 runtime pose를 변경하지 않는다.

1. 기록된 native 초기 pose의 모든 기타 source body에 같은 Z 이동을 적용한다.
   → 원래 배치 재현, 전신–기타 활성 1404 pair 음수 gap·근접 간격 비교.
2. 같은 초기 strap route의 두 기타 끝점만 같은 만큼 올린다.
   → route 길이와 고정 L_A 대비 초기 정적 장력 비교(속도 0 가정).
3. 최소 상승 후보와 팔꿈치/허벅지 간격을 Sol이 검토한다.
   → Luna가 그림·설명을 결과 폴더와 VISUAL_REPORT에 추가하고 별도 검수한다.

- [x] 정적 비교와 원자료 불변 확인 — 원본 음수 pair 1개 재현, 입력 hash 불변
- [x] 추천 후보·장력 변화·해석 범위 정리 — +5mm에 hip 3.303mm/elbow 4.208mm, route 5.811mm 단축·L_A 고정 시 장력 0N
- [x] 그림·문서 및 별도 검수 — 최소 gap 집계 확인, 그림 픽셀 재현, 남은 Critical/Warning/Suggestion 없음

음수 gap 크기는 MuJoCo source query이며 교정된 PhysX 관통 깊이가 아니다.
발–ground, chair, 자기 충돌, solver 안정성은 이 이동으로 해소됐다고 판정하지 않는다.
실제 초기 Z 변경 rollout은 후보를 확인한 뒤 수행한다. 그때 해당 초기 위치를 유지 목표로
고정하되 원본 공통 기타 pose로부터의 이동도 함께 기록한다. 원래 목표를 조용히 바꾸거나
실행 중 목표를 재설정하지 않는다. 기존 비교에서 같은 p/q를 쓰는 원칙의 예외를 명시한다.

# 오른손목 X 음수 방향 추가 초기각 비교

2026-10-06. 같은 손목 자세에서 초기 스트랩 장력1/2/5/10/20N은1초 두 오차를
함께 줄이지 못했다. LA1.1010801317960974m를 유지하고 이미 개선됐던 손목 X
음수 방향을 현재 진단 기준에서 조금 더 검사한다. 효과의 연속·단조성을 가정하지 않는다.

- [x] 1. negative_pose_late_v1/wrist_minus0050 입력을 기준으로 복사하고
  R_Wrist_x만−0.0025/−0.005rad 더 조정한다. 기존 audit_arm_initial_inputs.py로
  C02±0.3rad∩모델·기타초기p/q/목표·몸통/손가락/하체 목표·PD·route/LA·noSteps,
  source 음수 pair0·LH 위쪽 반구·국소 넥 아래를 fresh 검사한다.
- [x] 2. 통과 조건과 기준의0.1초 기존 PI ON을 비교한다. 새 어깨 접촉이 없는
  조건만0.5/1초 ON으로 직접 비교하며 초기/0.5초 순위로1초를 추정하지 않는다.
  source 거절 조건은 native를 실행하지 않는다. 통과한 추가각이 없으면 기준만 재현한다.
- [x] 3. 1초 최대 위치·회전 오차가 모두 기준보다 작은 추가각만 OFF
  0.1/0.5/1초를 비교한다(최대2조건). 없으면 기존각을 유지한다.
  기존 compare_arm_initial_trials.py를 수정하지 않고 재사용한다. 외부 기준의
  group/on 경로는 기존 negative_pose_late_v1 group/wrist_minus0050를 가리키는
  새 read-only symlink로 연결하며 원본은 변경하지 않는다. 입력SHA는 원본으로 resolve한다.
- [x] 4. Luna가 저장 trace·표·초기 source 결과를 누적28절에 추가하고 검수한다.
  설정·명령·로그·원자료·보존본과 실제 파일 경로·줄을 기록한다.

기준 R_Wrist_x=−0.42467687010765076rad, 추가 후보는
−0.42717687010765076/−0.42967687010765077rad다. 다른 초기각과 LA는 동일하다.
root 고정/기타 자유/+5mm 목표p/q, Torso/Spine/Chest9·손가락42·C02하체 목표,
주요66 연결·팔24 PI ±0.15rad/60Hz·기존gain/PD/solver를 유지한다.
고정·강제부착·runtime pose 덮어쓰기·동적 strap·새 gate/제어/학습은 추가하지 않는다.
source query는 PhysX cooked clearance/지지력 인증이 아니며 실제각·접촉·속도·포화를 측정한다.

입력: stability_adapter_2/trials/right_wrist_negative_extension_v1.
결과: docs/2026-10-12/stability_adapter_2/results/right_wrist_negative_extension_v1.

## 실행 결과와 다음 방향

초기3입력 모두 기존 source/LH 조건을 통과했다. 전체105개 중 다른104개의 native 초기각은
동일했고 R_Wrist_x만 native 기준−0.002499998/−0.004999995rad 달랐다.
RH palm–body source hull 간격은 기준2.313745mm에서2.342578/2.371586mm였다.
source unsigned 거리와 negative pair0는 PhysX cooked clearance·지지력 인증이 아니다.

0.1/0.5/1초 ON9회를 실행했다. 1초 최대 위치·회전은 기준73.660431mm/13.502121°,
추가−0.0025rad114.478578mm/27.196448°,−0.005rad124.274325mm/31.128511°였다.
두 오차를 줄인 후보가 없어 OFF를 추가하지 않고 기존각/LA를 유지한다.
모든1초 보정은212physics samples에서 포화됐으며 LH/어깨 contact0이다.
RH thumb3 행/unique samples는221/78,136/54,121/41이고 마지막 관측step은
163/139/138이다. 관측수·끝점은 힘·깊이·인과·연속 지지 인증이 아니다.
큰 종료 속도·drift가 남아 안정·연주 성공이 아니다.

새 read-only reference_links의3개 group/on은 기존 원자료를 가리킨다.
기간별 기준 raw5와 긴 실행의 짧은 prefix는 exact이며 입력138SHA가 현재와 일치한다.
기존 도구·원본·공용 자산은 변경하지 않았다.
다음에는 현재 기준 손목각의±0.00125rad 중간 조건을 같은 LA/제어에서 fresh source로
검사한다. 이미 시험한 이웃각 사이의 진단이며 국소 최솟값이나 안정성을 가정하지 않는다.
기타 p/q feedback·새 제어/gain/학습은 사용자 확인 전 추가하지 않는다.

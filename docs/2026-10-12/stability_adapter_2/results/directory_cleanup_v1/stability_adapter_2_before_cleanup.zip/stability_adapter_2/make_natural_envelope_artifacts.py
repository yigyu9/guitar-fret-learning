"""Render provisional-envelope summaries from the frozen saved-data analysis."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / 'docs/2026-10-12/stability_adapter_2/results/natural_envelope_assessment_v1'
A = ROOT / 'stability_adapter_2'
RUN_DIRS = [
    ROOT / 'docs/2026-10-12/stability_adapter_2/results/small_wrist_motion_v1/native',
    ROOT / 'docs/2026-10-12/stability_adapter_2/results/joint_only_fixed_strap_v1/native',
    ROOT / 'docs/2026-10-12/stability_adapter_2/results/fixed_strap_shoulder_response_v1/minus008',
    ROOT / 'docs/2026-10-12/stability_adapter_2/results/fixed_strap_shoulder_response_v1/plus008',
]
SOURCE_FILES = [
    P / 'analysis.json', P / 'windows.jsonl', P / 'timeline.jsonl', P / 'analysis_execution.json',
    A / 'NATURAL_ENVELOPE_ASSESSMENT_DECISION.md', A / 'NATURAL_ENVELOPE_ASSESSMENT_PLAN.md',
    A / 'NATURAL_PLAYING_ENVELOPE.md', A / 'analyze_natural_envelope.py',
]
for run_dir in RUN_DIRS:
    SOURCE_FILES.extend(run_dir / name for name in ('initial_values.json', 'report.json', 'trace.jsonl', 'states.jsonl'))

COLORS = ['#4C78A8', '#F58518', '#54A24B', '#B279A2']
LABELS = ['original wrist', 'joint18', 'shoulder −0.008 rad', 'shoulder +0.008 rad']
PANELS = [
    ('max_initial_position_mm', 30.0, 'Initial position · max (mm)', 'mm'),
    ('max_initial_rotation_deg', 5.0, 'Initial rotation · max (deg)', '°'),
    ('max_position_change_mm', 5.0, 'Rolling 1 s · max position change (mm)', 'mm'),
    ('max_rotation_change_deg', 1.0, 'Rolling 1 s · max rotation change (deg)', '°'),
]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out-dir', required=True)
    args = parser.parse_args()
    out = Path(args.out_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    figure_path = out / 'natural_envelope_limits.png'
    manifest_path = out / 'artifact_manifest.json'
    snapshot_path = out / 'source_snapshot.json'
    if any(path.exists() for path in (figure_path, manifest_path, snapshot_path)):
        raise SystemExit('refusing to overwrite existing artifact outputs')

    wrapper = out / 'run_producer.sh'
    paths = SOURCE_FILES + [Path(__file__).resolve(), wrapper]
    before = {str(path): sha(path) for path in paths}

    snapshot_root = out / 'source_snapshot'
    records = []
    for path in paths:
        rel = path.resolve().relative_to(ROOT)
        copied = snapshot_root / 'repo' / rel
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, copied)
        digest = sha(path)
        if sha(copied) != digest:
            raise RuntimeError('source copy SHA mismatch: ' + str(path))
        records.append({'original_path': str(path.resolve()), 'copy_path': str(copied), 'sha256': digest})
    snapshot_path.write_text(json.dumps({'files': records}, indent=2) + '\n')

    analysis = json.loads((P / 'analysis.json').read_text())
    if analysis.get('input_sha256_before') != analysis.get('input_sha256_after'):
        raise RuntimeError('saved analysis input hashes differ before/after')
    for source_path, expected_sha in analysis['input_sha256_before'].items():
        if before.get(source_path) != expected_sha:
            raise RuntimeError('current source differs from saved analysis input: ' + source_path)
    if not all(analysis.get('checks', {}).values()) or analysis.get('naturalness_or_playing_success_certified') is not False:
        raise RuntimeError('analysis checks or certification state unexpected')
    if len(analysis['runs']) != 4 or [r['run'] for r in analysis['runs']] != ['original', 'joint18', 'shoulder_minus', 'shoulder_plus']:
        raise RuntimeError('unexpected analysis run ordering')
    windows = (P / 'windows.jsonl').read_text().splitlines()
    if len(windows) != 4 * 121:
        raise RuntimeError('unexpected window record count')

    fig, axes = plt.subplots(2, 2, figsize=(13.2, 8.6))
    for ax, (field, limit, title, unit) in zip(axes.flat, PANELS):
        if field in ('max_initial_position_mm', 'max_initial_rotation_deg'):
            values = [float(run[field]) for run in analysis['runs']]
        else:
            values = [float(run[field]['max']) for run in analysis['runs']]
        fractions = np.asarray(values) / limit
        y = np.arange(4)
        bars = ax.barh(y, fractions, color=COLORS, height=0.62)
        ax.axvline(1.0, color='#333333', linestyle='--', linewidth=1.2, label='provisional limit')
        ax.set_yticks(y, LABELS)
        ax.invert_yaxis()
        ax.set_xlim(0.0, 1.1)
        ax.set_xticks(np.arange(0.0, 1.11, 0.2))
        ax.set_xlabel('fraction of provisional limit')
        ax.set_title(title, loc='left', fontsize=11, fontweight='bold')
        ax.grid(axis='x', alpha=0.22)
        ax.set_axisbelow(True)
        for bar, value in zip(bars, values):
            ax.text(bar.get_width() + 0.018, bar.get_y() + bar.get_height() / 2,
                    '{:.3f} {}'.format(value, unit), va='center', ha='left', fontsize=8)
    fig.suptitle('Saved-data comparison against provisional natural-playing envelope', fontsize=14, y=0.98)
    fig.text(0.5, 0.075, 'Initial limits: 30 mm / 5°; rolling 1 s limits: 5 mm / 1°.',
             ha='center', va='bottom', fontsize=9)
    fig.text(0.5, 0.052, 'Rolling windows: start 2.000–4.000 s (121 starts at 60 Hz; 241 samples per window).',
             ha='center', va='bottom', fontsize=9)
    fig.text(0.5, 0.029, 'Dashed line = provisional limit; saved-data observation, not naturalness or playing certification.',
             ha='center', va='bottom', fontsize=9)
    fig.tight_layout(rect=(0.02, 0.105, 0.98, 0.94), h_pad=2.0, w_pad=2.4)
    fig.savefig(figure_path, dpi=220, bbox_inches='tight')
    plt.close(fig)

    after = {str(path): sha(path) for path in paths}
    if before != after:
        raise RuntimeError('input SHA changed while producing figure')
    outputs = {figure_path.name: sha(figure_path)}
    manifest = {
        'producer_sha256_before': before[str(Path(__file__).resolve())],
        'producer_sha256_after': after[str(Path(__file__).resolve())],
        'inputs_sha256_before': before,
        'inputs_sha256_after': after,
        'outputs_sha256': outputs,
        'native_initializations': 0,
        'physics_steps': 0,
        'actor_inference_calls': 0,
        'training_updates': 0,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'figure': str(figure_path), 'sha256': outputs[figure_path.name], 'inputs': len(before)}))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Plot saved Seed 2 guitar-feedback analyses and their recorded Gym frames."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Dict, List

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.family"] = "NanumGothic"
matplotlib.rcParams["axes.unicode_minus"] = False

ROOT = Path(__file__).resolve().parents[1]
PHASE = ROOT / "docs/2026-10-12/stability_adapter_2/results/seed2_guitar_feedback_v1"
OLD = ROOT / "docs/2026-10-12/stability_adapter_2/results/seed2_guitar_response_v1"
LOCALITY = ROOT / "docs/2026-10-12/stability_adapter_2/results/seed2_response_locality_v1"
FONT = Path("/usr/share/fonts/truetype/nanum/NanumGothic.ttf")
NEW_LABELS = ["constant_0p008", "constant_0p016", "guitar_feedback"]
DISPLAY = {
    "saved_base": "Saved base",
    "saved_negative_0p002": "Saved shoulder Y -0.002 rad",
    "constant_0p008": "Constant -0.008 rad",
    "constant_0p016": "Constant -0.016 rad",
    "guitar_feedback": "Guitar feedback",
}
COLORS = {
    "saved_base": "#222222",
    "saved_negative_0p002": "#1f77b4",
    "constant_0p008": "#d62728",
    "constant_0p016": "#2ca02c",
    "guitar_feedback": "#9467bd",
}
CURVE_ORDER = list(DISPLAY)


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def finite_series(values, label: str) -> np.ndarray:
    result = np.asarray(values, dtype=float)
    if result.ndim != 1 or not np.isfinite(result).all():
        raise ValueError(f"{label} must be finite one-dimensional data")
    return result


def input_paths() -> List[Path]:
    paths = [
        Path(__file__).resolve(), FONT,
        PHASE / "artifact_brief.json", PHASE / "analysis.json",
        OLD / "probe_analysis.json", LOCALITY / "analysis.json",
    ]
    for label in NEW_LABELS:
        run = PHASE / "native" / label
        paths.extend([run / "report.json", run / "initial_values.json", run / "capture.json"])
        paths.extend(run / "frames" / "hands" / f"{frame:05d}.png" for frame in (0, 150))
    return paths


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    out = args.out_dir.resolve()
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f"refusing nonempty output directory: {out}")
    out.mkdir(parents=True, exist_ok=True)

    inputs = input_paths()
    missing = [str(path) for path in inputs if not path.is_file()]
    if missing:
        raise SystemExit("missing inputs: " + ", ".join(missing))
    before = {str(path): sha(path) for path in inputs}

    brief = read_json(PHASE / "artifact_brief.json")
    analysis = read_json(PHASE / "analysis.json")
    old_probe = read_json(OLD / "probe_analysis.json")
    locality = read_json(LOCALITY / "analysis.json")
    if analysis.get("counts") != {"native_initializations": 3, "physics_steps": 3600}:
        raise ValueError("unexpected fresh native counts")
    for name, document in (("feedback", analysis), ("saved probe", old_probe), ("locality", locality)):
        checks = document.get("checks")
        if not checks or not all(checks.values()):
            raise ValueError(f"{name} analysis checks failed")
    if list(analysis.get("curves", {})) != NEW_LABELS:
        raise ValueError("unexpected new curve labels")
    prefix = analysis.get("guitar_first24_pose_exact_vs_saved_base")
    if not isinstance(prefix, dict) or set(prefix) != set(NEW_LABELS):
        raise ValueError("missing step 0-24 exactness observation")
    if not all(type(prefix[label]) is bool for label in NEW_LABELS):
        raise ValueError("step 0-24 exactness values must be recorded booleans")
    if old_probe.get("counts", {}).get("native_initializations") != 7:
        raise ValueError("unexpected historical probe counts")

    series: Dict[str, dict] = {
        "saved_base": old_probe["curves"]["base"],
        "saved_negative_0p002": locality["curves"]["negative_shoulder_y"],
        **analysis["curves"],
    }
    if list(series) != CURVE_ORDER:
        raise ValueError("unexpected curve mapping")
    fig, axes = plt.subplots(3, 1, figsize=(13.2, 11.6), sharex=False, constrained_layout=True)
    for ax, field, title, ylabel in (
        (axes[0], "guitar_position_error_mm", "Guitar position error", "Error (mm)"),
        (axes[1], "guitar_rotation_error_deg", "Guitar rotation error", "World SO(3) error (degrees)"),
    ):
        for label in CURVE_ORDER:
            curve = series[label]
            x = finite_series(curve["time_s"], f"{label}.time_s")
            y = finite_series(curve[field], f"{label}.{field}")
            if len(x) != 1201 or len(y) != 1201 or not np.all(np.diff(x) > 0):
                raise ValueError(f"unexpected sample sequence: {label}.{field}")
            if not np.isclose(x[0], 0.0) or not np.isclose(x[-1], 5.0):
                raise ValueError(f"unexpected time coverage: {label}.{field}")
            ax.plot(x, y, color=COLORS[label], linewidth=1.5,
                    linestyle="--" if label.startswith("saved_") else "-",
                    label=DISPLAY[label])
        ax.set_title(title)
        ax.set_ylabel(ylabel)
        ax.grid(True, alpha=.25)
        ax.set_xlim(0.0, 5.0)
        ax.legend(loc="best", ncol=2, fontsize=8)
    axes[1].set_xlabel("Time (s)")

    ax = axes[2]
    for label in NEW_LABELS:
        control = analysis["curves"][label]["control"]
        time = finite_series(control["prestep_time_s"], f"{label}.prestep_time_s")
        if len(time) != 300 or not np.all(np.diff(time) > 0):
            raise ValueError(f"unexpected control update sequence: {label}")
        for key, linestyle, suffix in (
            ("requested_delta_rad", "--", "requested"),
            ("actual_float32_delta_vs_base_rad", "-", "actual f32"),
        ):
            delta_mrad = finite_series(control[key], f"{label}.{key}") * 1000.0
            if len(delta_mrad) != 300:
                raise ValueError(f"unexpected target delta length: {label}.{key}")
            ax.plot(time, delta_mrad, color=COLORS[label], linewidth=1.3,
                    linestyle=linestyle, label=f"{DISPLAY[label]} {suffix}")
    ax.set_title("Shoulder Y submitted target offset from base")
    ax.set_ylabel("Target delta (mrad)")
    ax.set_xlabel("Pre-step update time (s)")
    ax.set_xlim(0.0, 5.0)
    ax.grid(True, alpha=.25)
    ax.legend(loc="best", ncol=2, fontsize=7)
    fig.suptitle("Seed 2 guitar feedback: saved references and fresh runs", fontsize=13)
    curve_path = out / "seed2_guitar_feedback_curves.png"
    fig.savefig(curve_path, dpi=170)
    plt.close(fig)

    fig, axes = plt.subplots(2, 3, figsize=(12.8, 5.5), constrained_layout=True)
    camera_meta = {}
    for col, label in enumerate(NEW_LABELS):
        run = PHASE / "native" / label
        capture = read_json(run / "capture.json")
        report = read_json(run / "report.json")
        if report.get("completed") is not True or report.get("physics_steps") != 1200:
            raise ValueError(f"incomplete actual-camera run: {label}")
        frames = capture.get("frames", [])
        if capture.get("fps") != 30 or len(frames) != 151:
            raise ValueError(f"unexpected actual-camera metadata for {label}")
        camera_meta[label] = {"fps": 30, "frame_count": 151, "displayed_steps": [0, 1200]}
        for row, (step, idx) in enumerate(((0, 0), (1200, 150))):
            record = next((item for item in frames if item.get("physics_step") == step), None)
            if record is None or record.get("render_preserves_states") is not True:
                raise ValueError(f"missing state-preserving frame: {label}/{step}")
            if not np.isclose(float(record.get("time_s", -1)), step / 240.0):
                raise ValueError(f"camera timestamp mismatch: {label}/{step}")
            image_path = (run / "frames" / "hands" / f"{idx:05d}.png").resolve()
            matches = [key for key in record.get("image_sha256", {})
                       if Path(key).resolve() == image_path]
            if len(matches) != 1 or sha(image_path) != record["image_sha256"][matches[0]]:
                raise ValueError(f"camera image SHA mismatch: {image_path}")
            ax = axes[row, col]
            ax.imshow(plt.imread(image_path))
            ax.set_axis_off()
            if row == 0:
                ax.set_title(DISPLAY[label], fontsize=9)
            ax.text(.02, .03, f"t={step / 240:.1f} s | step {step}", transform=ax.transAxes,
                    color="white", fontsize=8, va="bottom",
                    bbox={"facecolor": "black", "alpha": .65, "pad": 3})
    fig.suptitle("Recorded Isaac Gym hands-camera frames: three fresh runs", fontsize=13)
    camera_path = out / "seed2_guitar_feedback_hands_camera.png"
    fig.savefig(camera_path, dpi=150)
    plt.close(fig)

    after = {str(path): sha(path) for path in inputs}
    if before != after:
        raise RuntimeError("input SHA changed during artifact generation")
    manifest = {
        "producer": str(Path(__file__).resolve()),
        "producer_sha256": sha(Path(__file__).resolve()),
        "producer_origin": {
            "copied_from": str(ROOT / "docs/2026-10-12/stability_adapter_2/results/seed2_response_locality_v1/source_final/stability_adapter_2/make_seed2_locality_artifacts.py"),
            "verified_source_sha256": "a43acd0aabdfe46308c31b0fda24c90280724e6412a8f52b0ce51556f7a9b4f4",
        },
        "input_count": len(inputs),
        "inputs_sha256_before": before,
        "inputs_sha256_after": after,
        "fresh_phase_counts": analysis["counts"],
        "fresh_analysis_checks": analysis["checks"],
        "historical_probe_counts": old_probe.get("counts"),
        "historical_locality_prefix_exactness": prefix,
        "historical_runs_are_saved_references_not_new_trials": True,
        "camera_frames": camera_meta,
        "native_calls_by_producer": 0,
        "outputs_sha256": {str(path): sha(path) for path in (curve_path, camera_path)},
    }
    manifest_path = out / "artifact_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
                             encoding="utf-8")
    print(curve_path)
    print(camera_path)
    print(manifest_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

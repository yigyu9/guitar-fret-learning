# 현재 실제 자세의 FK·palm 민감도 계측 계약

PALM_SUPPORT_RESIDUAL_AT_BODY9_PLAN의 offline 단계1~2다. Root/Sol은 물리 계측과후속제어를담당하고Luna는확정brief의산출물만담당한다. 기존실행/소스/계획/산출물은변경하지않는다. 추가native/physics실행은0이다.

1. torso_hold_native_collision_v1/native 저장states의step0/24/120/1200을읽는다. 왼팔/손FK의relative calibration은t0한번만하고각시점actualq를입력한다. Chest기준FK를실제각시점Chest worldpose로rigid변환한다. 매시점relative pose를다시맞춰정답을강제로만들지않는다. 왼팔·손모든body origin/rotation과현proposal의palm anchor/normal을actualpose와대조한다. 기존initialgate의0.1mm/0.001rad를동일한예측대조기준으로사용하고결과를숨기지않는다.
2. 동시점actualq에서왼팔12의central±0.0001rad FK미분을계산한다. Native한계밖인축은one-sided로하고actual q자체의native경계위반도별도기록한다. 초기target/Jacobian/다른자세anchor를currentmatrix로복사하지않는다. Position단위m/rad,normal단위1/rad를분리한다. Native qposition/FK지점변화의미분이며PD target/접촉응답matrix로인증하지않는다.
3. 요청palm유한옆면의현actualpoint에서가까운목표를만든다. Gy/Gz를3.1mm안쪽으로clamp한plane위점에서outward unitnormal방향0.1mm offset을둔다. Plane식과normal을metadata에저장하고목표를G frame에서계산해actualG worldpose로변환한다. 정확평행은강제하지않고source inwardnormal정렬은soft진단으로만계산한다.
4. Position-only damped least-squares(lambda0.01m/rad)의소스변위제안을계산하고model bounds∩actualq±0.05rad에제한해linear/nonlinear source점이동과실제오차변화를비교한다. 이각제안은actual q 주변기하예측이며최종PD목표가아니다. 기존81목표+residual의float32목표/초기offset±0.3/관절경계도별도계산한다. Base절대목표의중력보정을그대로둔다. Wholepalm/source collision·palmar상향·finger/Aug19·양손 조건은실제제어계약에서별도검증하며이선형제안만으로통과인증하지않는다.

- [ ] 저장actual4시점과t0calibrated FK의몸통이동포함대조
- [ ] 좌표/position·normal Jacobian·source보정예측/PD목표경계
- [ ] 그림/actualbaseline영상출처·결과해석·다음계획/원본보존

Step1의예측오차가크면해당FK로runtime제어를진행하지않고좌표/원점/회전가정부터진단한다. 통과하더라도실제PD/접촉응답은별도actual5초검증이필요하다. 초기G p/q복원·유지와최종66연주권한/제어합성목표는변경하지않는다.

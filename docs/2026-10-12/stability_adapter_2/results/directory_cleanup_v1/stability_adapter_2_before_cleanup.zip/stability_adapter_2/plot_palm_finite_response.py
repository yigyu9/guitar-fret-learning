"""Plot saved constant/tracking palm response and existing Gym camera frames."""
import argparse
import hashlib
import json
import math
from pathlib import Path

ROOT = Path('/home/ajou/yigyu/3')
PHASE = ROOT / 'docs/2026-10-12/stability_adapter_2/results/palm_finite_response_v1'
FACET = ROOT / 'docs/2026-10-12/stability_adapter_2/results/palm_neck_side_v1/facet_distal_search/search.json'
RUNS = {
    'constant': {
        'baseline': PHASE / 'calibration_runs/baseline',
        'corrected_quarter': PHASE / 'validation/corrected_quarter',
        'corrected_half': PHASE / 'validation/corrected_half',
        'corrected_bias': PHASE / 'validation/corrected_bias',
    },
    'tracking': {
        'baseline_tracking': PHASE / 'validation/baseline_tracking',
        'quarter_tracking': PHASE / 'validation/quarter_tracking',
    },
}
CAMERAS = {
    'corrected_bias': PHASE / 'native_corrected_bias',
    'quarter_tracking': PHASE / 'native_quarter_tracking',
}
CAMERA_STEPS = (0, 4, 8, 12, 16, 20, 24)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def explicit_inputs():
    paths = [PHASE / 'analysis.json', Path(__file__).resolve(), FACET,
             ROOT / 'stability_adapter_2/plot_palm_side_feedback.py']
    for group in RUNS.values():
        for directory in group.values():
            paths.extend(directory / f'{name}.json' for name in
                          ('report', 'trace', 'tasks', 'contacts'))
    for directory in CAMERAS.values():
        paths.extend((directory / 'report.json', directory / 'states.json'))
        for step in CAMERA_STEPS:
            for view in ('front', 'side'):
                paths.append(directory / f'blue_{view}_{step:03d}.png')
    paths = [path.resolve() for path in paths]
    if len(set(paths)) != len(paths):
        raise ValueError('duplicate explicit inputs')
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError('missing inputs: ' + ', '.join(missing))
    return paths


def validate_analysis(analysis):
    checks = analysis.get('checks')
    if not isinstance(checks, dict) or len(checks) != 12 or not all(checks.values()):
        raise ValueError('analysis.json must contain 12 passing checks')
    if analysis.get('counts') != {'native_initializations': 21, 'physics_steps': 504}:
        raise ValueError('unexpected analysis counts')
    summary = {item['label']: item for item in analysis.get('summary', [])}
    for group, runs in RUNS.items():
        for label, directory in runs.items():
            item = summary.get(label)
            expected_mode = 'bias' if group == 'constant' else 'tracking'
            if not item or Path(item['run_path']).resolve() != directory.resolve():
                raise ValueError(f'analysis does not identify {label} at expected path')
            if item['mode'] != expected_mode:
                raise ValueError(f'analysis mode mismatch for {label}')
    return checks, summary


def saved_run(directory, label, summary):
    report, trace, tasks, contacts = [read_json(directory / f'{name}.json') for name in
                                      ('report', 'trace', 'tasks', 'contacts')]
    if report.get('failure') or report.get('mode') not in ('bias', 'tracking'):
        raise ValueError(f'{label}: incomplete or unexpected saved run')
    if report.get('native_initializations') != 1 or report.get('physics_steps') != 24:
        raise ValueError(f'{label}: expected one init and 24 steps')
    if not report.get('checks') or not all(report['checks'].values()):
        raise ValueError(f'{label}: report checks are not all true')
    if not (len(trace) == len(tasks) == 25 and len(contacts) == 24):
        raise ValueError(f'{label}: saved-data length mismatch')
    times = [float(row['time_s']) for row in trace]
    if any(not math.isfinite(t) or abs(t - i / 240.0) > 1e-9
           for i, t in enumerate(times)):
        raise ValueError(f'{label}: unexpected saved timestamps')
    values = []
    guitar_position, guitar_rotation = [], []
    for task, row in zip(tasks, trace):
        vals = [float(value) for value in task]
        if len(vals) != 6 or not all(math.isfinite(value) for value in vals):
            raise ValueError(f'{label}: invalid palm task row')
        p_error = float(row['position_error_m'])
        q_error = float(row['rotation_error_deg'])
        if not math.isfinite(p_error) or not math.isfinite(q_error):
            raise ValueError(f'{label}: nonfinite guitar trace')
        guitar_position.append(p_error * 1000.0)
        guitar_rotation.append(q_error)
        values.append((math.sqrt(sum(v*v for v in vals[:3])) * 1000.0,
                       math.sqrt(sum(v*v for v in vals[3:])) / .08 * 180.0 / math.pi))
    expected = summary[label]
    if abs(max(p for p, _ in values) - expected['max_point_error_mm']) > 1e-6:
        raise ValueError(f'{label}: palm point metric does not match analysis')
    if abs(values[-1][1] - expected['end_normal_angle_deg']) > 1e-6:
        raise ValueError(f'{label}: normal angle does not match analysis')
    if abs(max(guitar_position) - expected['max_guitar_position_error_mm']) > 1e-6:
        raise ValueError(f'{label}: guitar position metric does not match analysis')
    if abs(max(guitar_rotation) - expected['max_guitar_rotation_error_deg']) > 1e-6:
        raise ValueError(f'{label}: guitar rotation metric does not match analysis')
    return {
        'time_s': times,
        'guitar_position_mm': guitar_position,
        'guitar_rotation_deg': guitar_rotation,
        'palm_point_mm': [p for p, _ in values],
        'palm_normal_angle_deg': [a for _, a in values],
    }


def make_curves(out_dir, data):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager

    font = Path('/usr/share/fonts/truetype/nanum/NanumGothic.ttf')
    if font.exists():
        plt.rcParams['font.family'] = font_manager.FontProperties(fname=font).get_name()
    plt.rcParams['axes.unicode_minus'] = False
    panels = (
        ('guitar_position_mm', '기타 위치 오차 (mm)'),
        ('guitar_rotation_deg', '기타 회전 오차 (°)'),
        ('palm_point_mm', '손바닥 추적점 오차 (mm)'),
        ('palm_normal_angle_deg', '법선 작업각 (°; 0.08 m/rad 환산)'),
    )
    colors = {'baseline': '#555555', 'corrected_quarter': '#2a789c',
              'corrected_half': '#e07a24', 'corrected_bias': '#ba4b4b',
              'baseline_tracking': '#555555', 'quarter_tracking': '#25855a'}
    outputs = []
    for group, runs in data.items():
        fig, axes = plt.subplots(2, 2, figsize=(13, 8), sharex=True)
        for ax, (field, title) in zip(axes.flat, panels):
            for label, values in runs.items():
                ax.plot(values['time_s'], values[field], color=colors[label], marker='o', ms=2.5,
                        lw=1.7, label=label)
            ax.set_title(title)
            ax.set_xlabel('저장 시각 (s)')
            ax.set_xlim(0, .1)
            ax.grid(True, alpha=.25)
            ax.legend(fontsize=8)
        fig.suptitle(f'저장 native response · {group} · 0.1 s', y=1.01)
        fig.tight_layout()
        path = out_dir / f'palm_finite_response_{group}.png'
        fig.savefig(path, dpi=160, bbox_inches='tight')
        plt.close(fig)
        outputs.append(path)
    return outputs


def make_camera(out_dir, input_map):
    import numpy as np
    from PIL import Image
    from plot_palm_side_feedback import overlay

    facet = read_json(FACET)
    local_facet = np.asarray(facet['palmar_facet_point_local_m'], dtype=float)
    outputs = []
    for label, directory in CAMERAS.items():
        report = read_json(directory / 'report.json')
        states = read_json(directory / 'states.json')
        if len(states) != 25:
            raise ValueError(f'{label}: expected 25 stored states')
        row_images = []
        for step in (0, 24):
            panels = []
            for view in ('front', 'side'):
                image_path = (directory / f'blue_{view}_{step:03d}.png').resolve()
                meta = report['images'].get(str(image_path))
                if not meta or meta.get('physics_step') != step:
                    raise ValueError(f'{label}: missing same-step image metadata {image_path}')
                if meta.get('sha256') != input_map[str(image_path)]:
                    raise ValueError(f'{label}: image hash differs from camera report')
                camera = report['camera_specs']['blue_' + view]
                panels.append(overlay(image_path, meta, camera, states[step], local_facet,
                                      f'{label} · step {step} · {view}'))
            row_images.append(panels)
        width, height = row_images[0][0].size
        if any(image.size != (width, height) for row in row_images for image in row):
            raise ValueError(f'{label}: camera image sizes differ')
        canvas = Image.new('RGB', (2 * width, 2 * height), (20, 20, 20))
        for row_index, row in enumerate(row_images):
            for col_index, image in enumerate(row):
                canvas.paste(image, (col_index * width, row_index * height))
        path = out_dir / f'palm_finite_response_camera_{label}.png'
        canvas.save(path)
        outputs.append(path)
    return outputs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out-dir', type=Path, required=True)
    args = parser.parse_args()
    out_dir = args.out_dir.resolve()
    if out_dir.exists():
        raise FileExistsError(f'preserve existing output directory: {out_dir}')

    paths = explicit_inputs()
    sealed = {str(path): sha256(path) for path in paths}
    # All data files, camera images, and the overlay helper are sealed before reads/imports.
    analysis = read_json(PHASE / 'analysis.json')
    checks, summary = validate_analysis(analysis)
    data = {group: {label: saved_run(directory, label, summary)
                    for label, directory in runs.items()} for group, runs in RUNS.items()}
    for directory in CAMERAS.values():
        report = read_json(directory / 'report.json')
        states = read_json(directory / 'states.json')
        if len(states) != 25 or not all(report.get('checks', {}).values()):
            raise ValueError('camera replay data failed stored checks or coverage')
        for step in CAMERA_STEPS:
            if states[step].get('physics_step') != step:
                raise ValueError('camera pose does not match requested image step')
            for view in ('front', 'side'):
                image_path = (directory / f'blue_{view}_{step:03d}.png').resolve()
                meta = report['images'].get(str(image_path))
                if not meta or meta.get('physics_step') != step or meta.get('sha256') != sealed[str(image_path)]:
                    raise ValueError('camera image metadata does not match sealed file')

    out_dir.mkdir(parents=True, exist_ok=False)
    outputs = make_curves(out_dir, data) + make_camera(out_dir, sealed)
    if any(sha256(path) != sealed[str(path)] for path in paths):
        raise RuntimeError('a sealed input changed while artifacts were generated')
    manifest = {
        'scope': 'saved 0.1 s analysis, traces, existing camera frames; no native simulation',
        'analysis_checks': checks,
        'analysis_counts': analysis['counts'],
        'inputs_sha256': sealed,
        'consumed_paths': sorted(str(path) for path in paths),
        'producer_sha256': sha256(Path(__file__).resolve()),
        'outputs_sha256': {path.name: sha256(path) for path in outputs},
        'camera_overlay_helper': str(ROOT / 'stability_adapter_2/plot_palm_side_feedback.py'),
        'camera_overlay': 'cyan source target polygon and orange source facet point at matching saved pose; neither is a cooked-contact measurement',
    }
    (out_dir / 'plot_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'outputs': manifest['outputs_sha256'], 'input_count': len(paths)}, indent=2))


if __name__ == '__main__':
    main()

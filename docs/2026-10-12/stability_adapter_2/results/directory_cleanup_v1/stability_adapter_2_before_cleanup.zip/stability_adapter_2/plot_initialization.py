"""Create measured-result PNGs from an existing run without simulating or editing it."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--images-dir', type=Path, required=True)
    args = parser.parse_args()
    trace = json.loads((args.run / 'trace.json').read_text())
    report = json.loads((args.run / 'report.json').read_text())
    time = np.array([s['time_s'] for s in trace])
    series = lambda key: np.array([s[key] for s in trace])
    paths = [args.images_dir / (args.run.name + '_' + name + '.png')
             for name in ('guitar_error', 'torso_drift', 'strap')]
    if any(p.exists() for p in paths):
        raise FileExistsError('preserve existing images; use a new run ID or images directory')
    args.images_dir.mkdir(parents=True, exist_ok=True)
    font_manager.fontManager.addfont('/usr/share/fonts/truetype/nanum/NanumGothic.ttf')
    plt.rcParams.update({'font.family': 'NanumGothic', 'font.size': 11, 'axes.unicode_minus': False})

    def save(fig, axes, title, path):
        for ax in axes:
            ax.set_xlim(time[0], time[-1])
            ax.set_xlabel('시간 (s)')
            ax.grid(alpha=.25)
            ax.set_axisbelow(True)
        fig.suptitle(title, fontsize=15)
        fig.text(.5, .015, f'CPU native POS PD | 240Hz 물리 · 60Hz 기록 | 저장된 {len(trace)}개 sample을 연결한 측정 그래프',
                 ha='center', fontsize=10)
        fig.tight_layout(rect=(0, .045, 1, .95))
        fig.savefig(path, dpi=160, facecolor='white')
        plt.close(fig)
        print(path.resolve())

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
    for ax, values, label, color in zip(axes,
            (series('position_error_m')*1000, series('rotation_error_deg')),
            ('기타 body-origin 위치 오차 (mm)', '기타 회전 오차 (°)'), ('#2563eb', '#dc2626')):
        ax.plot(time, values, 'o-', color=color)
        ax.set_ylabel(label)
        ax.set_ylim(bottom=0)
        ax.text(.04, .92, f'마지막 값: {values[-1]:.3f}', transform=ax.transAxes, color=color)
    save(fig, axes, '초기 목표 대비 기타 오차 — 자세 유지 성공 아님', paths[0])

    fig, axes = plt.subplots(3, 1, figsize=(11, 8))
    drift = series('torso_drift_deg')
    names = report['torso_held_joint_names']
    for ax, group in zip(axes, ('Torso', 'Spine', 'Chest')):
        for i, name in enumerate(names):
            if name.startswith(group + '_'):
                ax.plot(time, drift[:, i], 'o-', label=name)
        ax.axhline(0, color='black', linewidth=.7)
        ax.set_ylabel(group + ' 변화 (°)')
        ax.legend(loc='upper left', ncol=3, fontsize=9)
    save(fig, axes, '몸통 9관절 실제 변화 — PD 목표는 초기값 유지', paths[1])

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
    axes[0].plot(time, series('strap_length_m'), 'o-', label='현재 경로 길이 L')
    axes[0].plot(time, series('strap_rest_length_m'), '--', color='#dc2626', label='고정 rest length')
    axes[0].set_ylabel('스트랩 길이 (m)')
    axes[0].legend(fontsize=9)
    axes[1].plot(time, series('last_applied_tension_n'), 'o-', color='#059669')
    axes[1].set_ylabel('마지막 물리 tick 적용 장력 (N)')
    axes[1].set_ylim(-1, 5)
    save(fig, axes, '스트랩 길이와 저장된 마지막 적용 장력 — 시점 차이 주의', paths[2])


if __name__ == '__main__':
    main()

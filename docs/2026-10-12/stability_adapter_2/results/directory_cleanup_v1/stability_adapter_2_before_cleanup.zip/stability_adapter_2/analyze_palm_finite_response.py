"""Verify saved finite-response calibration, bias trials and native camera replay."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PHASE=ROOT/'docs/2026-10-12/stability_adapter_2/results/palm_finite_response_v1'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    if (PHASE/'analysis.json').exists():raise FileExistsError('preserve previous analysis')
    fit_path=PHASE/'calibration.json';hashes={str(fit_path):sha(fit_path)};fit=read(fit_path)
    if not all(fit['checks'].values()) or any(sha(p)!=h for p,h in fit['input_sha256'].items()):raise AssertionError('fit sources/contracts')
    old_path=PHASE.parent/'palm_normal_control_v1/cap_0p3/calibration.json'
    calibration_labels=['baseline']+['axis_'+str(i).zfill(2) for i in range(12)]+['heldout']
    validation_labels=['corrected_bias','corrected_quarter','corrected_half','baseline_tracking','quarter_tracking']
    folders=[PHASE/'calibration_runs'/l for l in calibration_labels]+[PHASE/'validation'/l for l in validation_labels]
    cameras=[PHASE/'native_corrected_bias',PHASE/'native_quarter_tracking'];folders+=cameras
    inventories=[PHASE.parent/n/'artifact_inventory.json' for n in ('palm_neck_side_v1','palm_side_feedback_v1','palm_plane_alignment_v1','palm_normal_control_v1','palm_support_weight_v1','palm_side_strap_v1','palm_side_strap_long_v1')]
    paths=[Path(p) for p in fit['input_sha256']]+[Path(__file__).resolve(),old_path]+inventories
    paths += [PHASE/n for n in ('execution.json','execution_validation.json','execution_scaled.json','execution_tracking.json','execution_camera.json','environment.json')]
    previous=PHASE.parent/'palm_side_strap_long_v1/current'
    paths += [previous/(n+'.json') for n in ('states','trace','normal_tasks','tasks','controls','contacts')]
    # Seal reports before using their metadata to discover producer/image input sets.
    report_paths=[folder/'report.json' for folder in folders];hashes.update({str(p):sha(p) for p in report_paths})
    reports={str(folder):read(folder/'report.json') for folder in folders}
    paths += [folder/(n+'.json') for folder in folders for n in ('states','trace','tasks','controls','contacts')]
    for report in reports.values():paths += [Path(p) for p in report['source_sha256']]+[Path(p) for p in report.get('images',{})]
    hashes.update({str(p):sha(p) for p in paths})
    from .palm_side_feedback import context,SideFeedback,np
    from .palm_normal_task import prepare,error_from_state
    from .build_fixed_lower_asset import pose,LOWER_BODIES
    from .strap import cable_forces
    from scipy.spatial.transform import Rotation
    ctx=prepare(context());old=read(old_path);config=read(ROOT/'stability_adapter_2/config.json')['strap'];arm=ctx['indices'];q0=ctx['q0'][arm]
    runs={};summaries=[];checks={};count={'native_initializations':0,'physics_steps':0}
    for folder in folders:
        r=reports[str(folder)];raw={n:read(folder/(n+'.json')) for n in ('states','trace','tasks','controls','contacts')}
        if r['failure'] or not all(r['checks'].values()) or r['physics_steps']!=24 or r['native_initializations']!=1:raise AssertionError('run contracts')
        if any(sha(p)!=h for p,h in r['source_sha256'].items()):raise AssertionError('producer SHA')
        if any(len(raw[n])!=25 for n in ('states','trace','tasks')) or any(len(raw[n])!=24 for n in ('controls','contacts')):raise AssertionError('coverage')
        if raw['states'][0]!=ctx['seed'] or any(error_from_state(s,ctx).tolist()!=t for s,t in zip(raw['states'],raw['tasks'])):raise AssertionError('initial/task')
        if any(s['physics_step']!=i for i,s in enumerate(raw['states'])) or any(abs(t['time_s']-i/240)>1e-9 for i,t in enumerate(raw['trace'])):raise AssertionError('state/time sequence')
        if any(v['physics_step']!=i+1 for n in ('controls','contacts') for i,v in enumerate(raw[n])):raise AssertionError('control/contact sequence')
        if any(s['human_body_states'][r['human_body_names'].index(n)]!=raw['states'][0]['human_body_states'][r['human_body_names'].index(n)] for s in raw['states'] for n in ('Pelvis',)+LOWER_BODIES):raise AssertionError('fixed lower')
        if r['rest_length_m']!=1.1018469719600776 or any(t['strap_rest_length_m']!=r['rest_length_m'] for t in raw['trace']):raise AssertionError('absolute rest length')
        if r['pd_kp']!=reports[str(folders[0])]['pd_kp'] or r['pd_kd']!=reports[str(folders[0])]['pd_kd']:raise AssertionError('same PD')
        for i,t in enumerate(raw['trace'][:-1]):
            tension=cable_forces(np.array(t['route_points_m']),np.array(t['route_point_velocities_mps']),r['rest_length_m'],config['stiffness_n_per_m'],config['damping_n_s_per_m'],config['max_tension_n'])[1]
            if abs(tension-raw['trace'][i+1]['last_applied_tension_n'])>1e-9:raise AssertionError('passive pre-step tension')
        if folder not in cameras:
            bias=np.array(r['bias_rad']);controller=SideFeedback(old['fk']['matrix'],q0,bias,old['lower_rad'],old['upper_rad']) if r['mode']=='tracking' else None
            record={}
            for i,v in enumerate(raw['controls']):
                updated=i%4==0
                if v['updated_before_step']!=updated:raise AssertionError('update schedule')
                if updated:
                    target=q0+bias;record={'task_error_m_scaled_rad':raw['tasks'][i]}
                    if controller is not None:target,record=controller.update(np.array(raw['tasks'][i]),1/60)
                expected=dict(record,updated_before_step=updated,physics_step=i+1,
                    final_target_rad=(q0.astype(np.float32)+(target-q0).astype(np.float32)).astype(float).tolist())
                if v!=expected:raise AssertionError('PI/target float32 reproduction')
        runs[str(folder)]=raw;count['native_initializations']+=1;count['physics_steps']+=24
        if folder in folders[:14] and folder.name!='baseline':continue
        pairs=[(v['physics_step'],c) for v in raw['contacts'] for c in v['contacts']]
        palm=[(s,c) for s,c in pairs if {c['body0_name'],c['body1_name']}=={'human/LH:palm','guitar/guitar'}]
        hip=[(s,c) for s,c in pairs if {c['body0_name'],c['body1_name']}=={'human/R_Hip','guitar/G:body'}]
        task=np.array(raw['tasks']);trace=raw['trace'];state=raw['states'][-1]
        pp,pq=pose(state['human_body_states'][ctx['palm_index']]);gp,gq=pose(state['guitar_body_states'][0]);gr=Rotation.from_quat(gq);ng=gr.apply(ctx['normal_G'])
        delta=pp+Rotation.from_quat(pq).apply(ctx['local_point'])-(gp+gr.apply(ctx['goal_point_G']-ctx['normal_G']*.00005));gap=float(delta@ng)
        summaries.append({'label':folder.name,'run_path':str(folder),'mode':r['mode'],
            'first_step_point_error_mm':float(np.linalg.norm(task[1,:3])*1000),'end_point_error_mm':float(np.linalg.norm(task[-1,:3])*1000),
            'max_point_error_mm':float(np.linalg.norm(task[:,:3],axis=1).max()*1000),
            'end_normal_angle_deg':float(np.linalg.norm(task[-1,3:])/.08*180/np.pi),
            'max_normal_angle_deg':float(np.linalg.norm(task[:,3:],axis=1).max()/.08*180/np.pi),
            'end_source_normal_gap_mm':gap*1000,'end_source_tangent_distance_mm':float(np.linalg.norm(delta-gap*ng)*1000),
            'max_guitar_position_error_mm':max(t['position_error_m'] for t in trace)*1000,'max_guitar_rotation_error_deg':max(t['rotation_error_deg'] for t in trace),
            'palm_contact_steps':sorted({s for s,c in palm}),'palm_contact_rows':len(palm),
            'positive_raw_palm_lambda_steps':sorted({s for s,c in palm if c['lambda']>0}),
            'positive_raw_palm_lambda_rows':sum(c['lambda']>0 for s,c in palm),'max_raw_palm_lambda':max((c['lambda'] for s,c in palm),default=0),
            'positive_raw_hip_lambda_rows':sum(c['lambda']>0 for s,c in hip),
            'max_actual_torso_drift_deg':float(np.abs([t['torso_drift_deg'] for t in trace]).max()),
            'minimum_source_palm_up_proxy_z':r['minimum_source_palm_up_proxy_z']})
    checks['all_21_contracts_coverage_same_initial_pd_and_rest']=True;checks['all_measured_tasks_exact']=True
    checks['constant_and_original_PI_applied_targets_reproduced']=True;checks['passive_tension_pre_step_exact']=True
    baseline_tracking=runs[str(PHASE/'validation/baseline_tracking')]
    checks['baseline_tracking_five_raw_prior_prefix_exact']=all(baseline_tracking[n]==read(previous/(n+'.json'))[:25 if n in ('states','trace','tasks') else 24] for n in baseline_tracking)
    checks['both_camera_five_raw_exact']=all(runs[str(folder)]==runs[reports[str(folder)]['reference_path']] for folder in cameras)
    checks['camera_28_images_sha_7_times_two_views']=all(len(r['images'])==14 and all(sha(p)==v['sha256'] for p,v in r['images'].items()) and all(sorted(v['physics_step'] for p,v in r['images'].items() if Path(p).name.startswith(name+'_'))==list(range(0,25,4)) for name in ('blue_front','blue_side')) for r in (reports[str(f)] for f in cameras))
    checks['counts_21_init_504_steps']=count=={'native_initializations':21,'physics_steps':504}
    execution=[r for n in ('execution.json','execution_validation.json','execution_scaled.json','execution_tracking.json','execution_camera.json') for r in read(PHASE/n)]
    checks['all_21_execution_exit_zero']=len(execution)==21 and all(r['exit_code']==0 for r in execution)
    checks['seven_previous_phases_preserved']=all(all(sha(p)==v['sha256'] for p,v in read(path).items()) for path in inventories)
    checks['fit_input_seals_unchanged']=all(sha(p)==h for p,h in fit['input_sha256'].items())
    checks['inputs_unchanged']=all(sha(p)==h for p,h in hashes.items())
    if not all(checks.values()):raise AssertionError(checks)
    result={'checks':checks,'input_sha256':hashes,'counts':count,'summary':summaries,'heldout':fit['heldout'],
        'predicted_corrected_end_error_m_scaled_rad':fit['predicted_corrected_end_error_m_scaled_rad'],
        'scope':'0.1s local bias response and separate original tracking comparison; source facet gap and raw lambda are not support certification; parallel is soft; no final candidate adoption'}
    (PHASE/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'checks':checks,'counts':count,'summary':summaries},indent=2))


if __name__=='__main__':main()

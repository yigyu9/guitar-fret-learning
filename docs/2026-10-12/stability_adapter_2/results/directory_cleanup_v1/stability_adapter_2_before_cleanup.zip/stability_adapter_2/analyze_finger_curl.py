"""Read saved finger targets and contact records; create no simulator."""
from pathlib import Path
import hashlib,json,math
R=Path(__file__).resolve().parents[1];A=R/'stability_adapter_2';D=R/'docs/2026-10-12/stability_adapter_2'
BASE=D/'results/fixed_strap_shoulder_response_v1/plus008';OUT=D/'results/finger_curl_diagnosis_v1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    assert not (OUT/'analysis.json').exists()
    paths=[Path(__file__).resolve(),A/'FINGER_CONTACT_REGION_PLAN.md',A/'run_small_wrist_recorded_diagnostic.py']+[BASE/n for n in ['initial_values.json','states.jsonl','controls.jsonl','contacts.jsonl','report.json','frames/hands/00000.png','frames/hands/00150.png']]
    before={str(p):sha(p) for p in paths}
    initial=json.loads((BASE/'initial_values.json').read_text());report=json.loads((BASE/'report.json').read_text())
    states=[json.loads(s) for s in (BASE/'states.jsonl').read_text().splitlines()];controls=[json.loads(s) for s in (BASE/'controls.jsonl').read_text().splitlines()];contacts=[json.loads(s) for s in (BASE/'contacts.jsonl').read_text().splitlines()]
    checks=dict(native_saved_complete=report['completed'] and report['physics_steps']==1200 and len(states)==1201 and len(controls)==len(contacts)==1200,step_coverage=[s['physics_step'] for s in states]==list(range(1201)) and [s['physics_step'] for s in controls]==[s['physics_step'] for s in contacts]==list(range(1,1201)))
    names=initial['human_joint_names'];rows=[];contact_rows=[]
    for finger in ['thumb','index','middle','ring','pinky']:
        body='human/LH:'+finger+'3';seen=set();guitars=set()
        for row in contacts:
            for c in row['contacts']:
                pair=[c['body0_name'],c['body1_name']]
                if body in pair and c['lambda']>0 and any(n.startswith('guitar/') for n in pair):
                    seen.add(row['physics_step']);guitars.update(n for n in pair if n.startswith('guitar/'))
        contact_rows.append(dict(body=body,positive_raw_lambda_steps=len(seen),first_step=min(seen) if seen else None,last_step=max(seen) if seen else None,positive_steps_at_or_after_2s=sum(s>=480 for s in seen),guitar_bodies=sorted(guitars)))
        for n in [n for n in names if n.startswith('LH:'+finger)]:
            k=names.index(n);target=controls[0]['final_target_rad'][k]
            assert all(c['final_target_rad'][k]==target for c in controls)
            rows.append(dict(joint=n,initial_deg=math.degrees(states[0]['human_dof_states'][k]['pos']),constant_target_deg=math.degrees(target),actual_0p5s_deg=math.degrees(states[120]['human_dof_states'][k]['pos']),actual_5s_deg=math.degrees(states[1200]['human_dof_states'][k]['pos'])))
    checks['all21_finger_targets_constant']=len(rows)==21
    after={str(p):sha(p) for p in paths};checks['inputs_preserved']=before==after;assert all(checks.values()),checks
    result=dict(checks=checks,input_sha256_before=before,input_sha256_after=after,source_trial=str(BASE),joint_rows=rows,distal_body_contacts=contact_rows,native_initializations=0,physics_steps=0,actor_inference_calls=0,training_updates=0,scope='saved scalar joint coordinates and positive raw lambda contact steps; no length counterfactual, anatomical pad identification, cooked clearance or force certification')
    (OUT/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(checks=checks,distal_body_contacts=contact_rows)))
if __name__=='__main__':main()

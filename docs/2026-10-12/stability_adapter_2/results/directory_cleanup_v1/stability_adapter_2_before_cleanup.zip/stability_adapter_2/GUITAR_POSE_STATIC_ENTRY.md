# 정적 기타 편집기의 최종 실행 진입점

`bash /home/ajou/yigyu/3/stability_adapter_2/open_guitar_pose_static.sh`

조작법은 [정적 가이드](/home/ajou/yigyu/3/stability_adapter_2/GUITAR_POSE_STATIC_GUIDE.md:11)와 같다. 물리 시간은항상0이며Space/E도물리를시작하지않는다. T는스트랩참고선표시만바꾼다. 저장전에viewer디버그선을지우고정적카메라촬영후복원하므로T/S가같은입력batch에들어와도이전스트랩선이사진에잔류하지않는다. 참고스트랩ON사진에는실제routeoverlay만별도로표시한다.

구현계획: 기존정적소스/결과는보존하고새entry에서캡처직전clear_lines를보장 → 검수 → 실제T/S연속입력저장시OFF사진의잔류주황선0및시간0검사 → 결과문서기록. 기존물리없는18검사와함께확인하며새물리trial/영상은만들지않는다.

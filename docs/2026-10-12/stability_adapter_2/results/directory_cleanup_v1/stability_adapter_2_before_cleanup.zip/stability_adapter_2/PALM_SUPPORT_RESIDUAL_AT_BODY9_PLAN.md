# 다음 단위: body9 PD 후보에서 손바닥 지지 보정 준비

몸통9 stiffness×2/damping×√2의 실제5초는 기타최대26.091583→14.052228mm/7.937143→2.884291°로 개선됐다. 그러나 손바닥 body contact 자체가0이며 엄지후면근접793→3step/중지전면1052→12step으로 줄었다. 새gain을 세면grip/연주안정화 성공으로 채택하지 않는다. 기타오차 개선이 있는 임시 진단 기준으로만 body9×2를 사용하고 기존×1 경과도 보존한다.

지금의 저장 팔PD목표와 실제 초기각 차이는 중력/접촉 하의 기존 목표 보정이다. 모든 팔목표를 실제 초기각으로 치환했던 과거 비교는 큰 악화를 보였다. 따라서 기존81목표를 base로 두고 작은 palm task residual만 추가할 수 있는지 먼저 확인한다. 이 단계에서 초기각·finger21목표·LA·몸통9목표·양팔손gain·guitar초기p/q를 바꾸지 않는다.

1. 현재 실제 저장 pose의0/0.1/0.5/5초에서 native q→source FK 변환을 독립 확인한다. Palm anchor/normal은 현 proposal의 source_anchors를 사용한다. 이전 다른 자세에서 만든 context/Jacobian/대표점은 재사용하지 않는다. 수치 FK오차와 native 좌표계·jointaxis를 기록한다. 소스 FK Jacobian은 실제 PD/접촉 응답 행렬이 아님을 구분한다.
2. 검증된 FK에서 왼팔12의 작은 angle perturbation에 따른 palm world점/법선 Jacobian을 계산한다. 목표는 실제 기타의 요청 유한 옆면 patch 안에서 가까운 지점이며 tangential 이동을 허용한다. 정확한 평행은 강제하지 않고 법선 정렬을 soft 항으로 둔다. Wholepalm/source 겹침·native 관절한계·palmar +Z 반구·finger/Aug19·양손충돌 기록과 동시에 가능한 보정 방향을 평가한다. Source거리의 양/음은 cooked contact 인증으로 쓰지 않는다. 팔12는 소단계의 임시보정 범위이며 최종66 연주권한은 유지한다.
3. 후보 계산이 타당하면 기존81목표+bounded/rate-limited palm residual을 하나의 최종PD목표로 제출하는 새runner를 설계한다. Actual q를 목표로 직접 대체하지 않고 기존 base를 유지한다. 잔차 상한·속도·damping은 단계2의 실제수치와 모델 한계로 정하고 별도 실행 계약에 기록한다. Finger21·몸통9 목표와 나머지목표는 그대로다. 처음은 feedback ON 한5초/스트랩 두영상만 수행하고 완료된 OFF를 비교한다. 초기source 실패·사라진 thumb접촉을 숨기지 않는다.
4. Palm 지지가 생기면 기타 world초기p/q 오차 복원 항을 추가할 수 있는지 물리 응답을 확인한다. Guitar에 직접 힘/고정/손부착/pose overwrite를 넣지 않는다. 연주목표66+안정화 residual의 clipping·우선순위·anti-windup/연주권한을 확인한 뒤 학습 구조를 결정한다. WAIT→REACH→GRIP→TRANSPORT를 연주 필수 선행 상태기로 만들지 않는다.

- [ ] 저장 native/FK 좌표·actual anchor/normal 대조
- [ ] 현재자세 FK 민감도·물리한계 안 residual 방향/범위
- [ ] 실행계약 후 ON 한5초·스트랩영상/초기값·원자료검증

계획은 미실행이다. 먼저 단계1~2의 offline 진단만 진행하며 불확실한 matrix로 제어를 바로 실행하지 않는다. Body9×2의 기타오차 감소는 한실행 관측이며 재현성·초기복원·세면지지·연주안정화의 전체 목표 완료가 아니다.

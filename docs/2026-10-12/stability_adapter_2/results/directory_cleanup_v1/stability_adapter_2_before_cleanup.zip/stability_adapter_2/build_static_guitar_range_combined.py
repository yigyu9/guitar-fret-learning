"""Create one labeled sheet from the five saved combined native placements."""
import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
PHASE = ROOT / 'docs/2026-10-12/stability_adapter_2/results/static_guitar_natural_range_v1'
COMPARISON = PHASE / 'combined/comparison.json'
OUT = PHASE / 'artifacts_combined'
FONT_PATH = Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
CELL = (480, 270)
GUTTER, TITLE_H, HEADER_H = 190, 42, 44
VIEWS = {
    'Front': lambda case: Path(case['path']) / 'front.png',
    'Side': lambda case: Path(case['path']) / 'side.png',
    'Hands': lambda case: Path(case['path']) / 'images/frames/hands/00000.png',
}


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    with Path(path).open(encoding='utf-8') as stream:
        return json.load(stream)


def write(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, sort_keys=True)
        stream.write('\n')


def centered(draw, box, text, font, color):
    left, top, right, bottom = box
    b = draw.textbbox((0, 0), text, font=font)
    w, h = b[2] - b[0], b[3] - b[1]
    draw.text((left + (right-left-w)/2-b[0], top + (bottom-top-h)/2-b[1]),
              text, font=font, fill=color)


def main():
    if OUT.exists():
        raise FileExistsError('refusing to overwrite '+str(OUT))
    producer = Path(__file__).resolve()
    if not COMPARISON.is_file() or not FONT_PATH.is_file():
        raise FileNotFoundError('combined comparison or label font missing')
    comparison_sha = sha(COMPARISON)
    comparison = read(COMPARISON)
    rows = comparison.get('rows')
    if len(rows or []) != 5 or comparison.get('physics_steps') != 0 or not all(comparison.get('checks', {}).values()):
        raise ValueError('expected five completed static combined rows')

    inputs = {str(producer): sha(producer), str(COMPARISON.resolve()): comparison_sha,
              str(FONT_PATH): sha(FONT_PATH)}
    prepared = {}
    cells = []
    native_root = (PHASE / 'combined').resolve()
    for case in rows:
        case_dir = Path(case['path']).resolve()
        try:
            case_dir.relative_to(native_root)
        except ValueError:
            raise ValueError('case path is outside combined result root')
        meta_path = case_dir / 'comparison.json'
        capture_path = case_dir / 'images/capture.json'
        local, capture = read(meta_path), read(capture_path)
        if local.get('id') != case['id'] or not all(local.get('checks', {}).values()):
            raise ValueError('case check failed or ID mismatch: '+case['id'])
        if local.get('native_state', {}).get('physics_step') != 0:
            raise ValueError('nonzero native state: '+case['id'])
        inputs[str(meta_path.resolve())] = sha(meta_path)
        inputs[str(capture_path.resolve())] = sha(capture_path)
        prepared[case['id']] = {}
        for view, path_fn in VIEWS.items():
            image_path = path_fn(case).resolve()
            actual = sha(image_path)
            if view in ('Front', 'Side'):
                expected = local.get('extra_image_sha256', {}).get(str(image_path))
            else:
                frames = capture.get('frames', [])
                if len(frames) != 1 or frames[0].get('physics_step') != 0:
                    raise ValueError('hands capture is not one t0 image: '+case['id'])
                expected = next((value for source, value in frames[0].get('image_sha256', {}).items()
                                 if Path(source).resolve() == image_path), None)
            if expected is None or actual != expected:
                raise ValueError('native image SHA mismatch: '+str(image_path))
            inputs[str(image_path)] = actual
            with Image.open(image_path) as source:
                if source.mode == 'RGBA' and source.getchannel('A').getextrema() != (255, 255):
                    raise ValueError('unexpected transparent native frame: '+str(image_path))
                image = source.convert('RGB')
                image.thumbnail(CELL, Image.Resampling.LANCZOS)
                if image.size != CELL:
                    raise ValueError('source image is not 16:9: '+str(image_path))
                prepared[case['id']][view] = image.copy()
            cells.append({'case_id': case['id'], 'case_path': str(case_dir), 'view': view,
                          'source_image': str(image_path), 'source_image_sha256': actual})

    if any(sha(path) != digest for path, digest in inputs.items()):
        raise RuntimeError('bounded input changed during validation')
    OUT.mkdir(parents=True, exist_ok=False)
    width = GUTTER + len(rows) * CELL[0]
    height = TITLE_H + HEADER_H + len(VIEWS) * CELL[1]
    sheet = Image.new('RGB', (width, height), (242, 244, 247))
    draw = ImageDraw.Draw(sheet)
    fonts = {'title': ImageFont.truetype(str(FONT_PATH), 25),
             'case': ImageFont.truetype(str(FONT_PATH), 18),
             'view': ImageFont.truetype(str(FONT_PATH), 20)}
    centered(draw, (GUTTER, 0, width, TITLE_H), 'Combined placements — native static views',
             fonts['title'], (20, 28, 38))
    for col, case in enumerate(rows):
        x = GUTTER + col * CELL[0]
        centered(draw, (x, TITLE_H, x + CELL[0], TITLE_H + HEADER_H), case['id'],
                 fonts['case'], (25, 35, 45))
    for row, view in enumerate(VIEWS):
        y = TITLE_H + HEADER_H + row * CELL[1]
        centered(draw, (0, y, GUTTER, y + CELL[1]), view, fonts['view'], (25, 35, 45))
        for col, case in enumerate(rows):
            sheet.paste(prepared[case['id']][view], (GUTTER + col * CELL[0], y))
    sheet_path = OUT / 'contact_sheet_combined_front_side_hands.png'
    sheet.save(sheet_path, format='PNG', optimize=False)
    if any(sha(path) != digest for path, digest in inputs.items()):
        raise RuntimeError('bounded input changed while building contact sheet')
    output_sha = sha(sheet_path)
    mapping = {'source_comparison': str(COMPARISON.resolve()),
               'source_comparison_sha256': comparison_sha,
               'image_cell_px': list(CELL),
               'layout': '3 view rows (front, side, hands) x 5 columns in input order',
               'aspect_handling': 'aspect-preserving 480x270 fit; no crop, overlay, or geometry edit',
               'cells': cells, 'output': str(sheet_path.resolve()), 'output_sha256': output_sha}
    write(OUT / 'case_mapping.json', mapping)
    outputs = {str(sheet_path.resolve()): output_sha,
               str((OUT / 'case_mapping.json').resolve()): sha(OUT / 'case_mapping.json')}
    write(OUT / 'artifact_manifest.json', {
        'producer': str(producer), 'producer_sha256': inputs[str(producer)],
        'source_comparison': str(COMPARISON.resolve()), 'source_comparison_sha256': comparison_sha,
        'bounded_input_sha256': inputs, 'outputs_sha256': outputs,
        'combined_case_count': len(rows), 'sheet_count': 1,
        'scope': 'contact-sheet packaging of saved native PNGs; no simulation or source-image editing'})
    print(json.dumps({'sheet': str(sheet_path), 'sha256': output_sha,
                      'case_count': len(rows), 'bounded_inputs': len(inputs)}, indent=2))


if __name__ == '__main__':
    main()

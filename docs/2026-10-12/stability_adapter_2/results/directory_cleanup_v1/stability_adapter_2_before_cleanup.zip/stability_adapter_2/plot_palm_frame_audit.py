#!/usr/bin/env python3
"""Plot saved palm-point displacements from the CPU frame audit JSON."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


OUTPUT_NAME = "palm_frame_displacement.png"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_inputs(audit_path: Path) -> tuple[dict, dict, Path]:
    audit_path = audit_path.resolve()
    jacobian_path = audit_path.with_name("jacobian.json")
    audit = json.loads(audit_path.read_text())
    jacobian = json.loads(jacobian_path.read_text())
    checks = audit.get("checks", {})
    if not checks or not all(checks.values()):
        raise ValueError("audit checks must all pass")
    if len(audit.get("input_sha256", {})) != 67:
        raise ValueError("expected 67 embedded input hashes")
    for name, expected in audit["input_sha256"].items():
        path = Path(name)
        if not path.is_file() or sha256(path) != expected:
            raise ValueError(f"embedded input SHA mismatch: {name}")
    if jacobian.get("shape") != [1, 65, 6, 105]:
        raise ValueError("unexpected Jacobian tensor shape")
    if jacobian.get("expected_fixed_root_shape") != [1, 65, 6, 105]:
        raise ValueError("unexpected expected fixed-root shape")
    if jacobian.get("device") != "cpu":
        raise ValueError("expected CPU Jacobian descriptor")
    if jacobian.get("palm_rows_nonzero") != {"L": True, "R": True}:
        raise ValueError("expected both recorded palm rows to be nonzero")
    if len(audit.get("saved_points", [])) != 3:
        raise ValueError("expected saved t=0, 1, and 3 second points")
    return audit, jacobian, jacobian_path


def plot(audit: dict, output_path: Path) -> None:
    samples = {float(item["time_s"]): item for item in audit["saved_points"]}
    times = (1.0, 3.0)
    fields = (
        ("center_displacement_m", "Hull volume center"),
        ("body_origin_displacement_m", "Palm body origin"),
        ("wrist_origin_displacement_m", "Wrist origin"),
    )
    colors = ("#2864a5", "#e07a2d")
    fig, axes = plt.subplots(1, 2, figsize=(12, 5.2), sharey=True)
    x = np.arange(len(fields))
    width = 0.34
    for ax, side, title in zip(axes, ("L", "R"), ("Left palm", "Right palm")):
        for i, time_s in enumerate(times):
            values_mm = [
                1000.0 * samples[time_s]["palms"][side][field]
                for field, _ in fields
            ]
            bars = ax.bar(
                x + (i - 0.5) * width,
                values_mm,
                width,
                label=f"t = {time_s:g} s",
                color=colors[i],
            )
            ax.bar_label(bars, fmt="%.1f", padding=2, fontsize=8)
        ax.set_title(title)
        ax.set_xticks(x, [label for _, label in fields], rotation=12, ha="right")
        ax.grid(axis="y", alpha=0.25)
        ax.set_axisbelow(True)
        ax.legend(frameon=False)
    axes[0].set_ylabel("Displacement from t=0 (mm)")
    fig.suptitle("Saved palm-frame point displacement at discrete snapshots", y=0.98)
    fig.text(
        0.5,
        0.015,
        "Source convex-hull volume center and body/wrist origins; snapshots only, not continuous motion or contact certification.",
        ha="center",
        fontsize=9,
    )
    fig.tight_layout(rect=(0.02, 0.07, 0.98, 0.93))
    fig.savefig(output_path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    out_dir = args.out_dir.resolve()
    if out_dir.exists() and any(out_dir.iterdir()):
        raise SystemExit(f"refusing to overwrite nonempty output directory: {out_dir}")
    out_dir.mkdir(parents=True, exist_ok=True)
    audit, jacobian, jacobian_path = load_inputs(args.audit)
    image_path = out_dir / OUTPUT_NAME
    plot(audit, image_path)
    manifest = {
        "scope": "JSON-only plot of saved CPU audit snapshots; no simulation",
        "inputs": {
            "audit_json": {"path": str(args.audit.resolve()), "sha256": sha256(args.audit.resolve())},
            "jacobian_json": {"path": str(jacobian_path), "sha256": sha256(jacobian_path)},
            "audit_embedded_inputs": audit["input_sha256"],
        },
        "checks": {
            "audit_all_true": all(audit["checks"].values()),
            "jacobian_shape": jacobian["shape"],
            "jacobian_device": jacobian["device"],
            "palm_rows_nonzero": jacobian["palm_rows_nonzero"],
        },
        "plotter": {"path": str(Path(__file__).resolve()), "sha256": sha256(Path(__file__).resolve())},
        "outputs": {OUTPUT_NAME: {"path": str(image_path), "sha256": sha256(image_path)}},
    }
    (out_dir / "plot_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()

# 현재 손바닥 기준점과 Jacobian 준비 상태 감사

2026-10-07. 기존 승인된 초기 조건과 저장 상태를 읽는 계측 단계다.
새 위치 제어·변화율 제한·gain·기타 목표·학습을 적용하지 않는다.
기준 입력은 `trials/quiescent_3s_v1/reference.json`, LA는1.1010801317960974m다.
root 고정·기타 자유/+5mm·몸통9/손가락42/C02하체 목표·기존 물리를 유지한다.

- [x] 1. 저장된0/1/3초 상태에서 양손 source palm convex-hull 체적 중심을
  재구성한다. 이를 native palm body-origin 좌표계로 옮겨 local offset의
  일관성과 초기 offset으로의 world 위치 재구성 오차를 확인한다.
  wrist/palm body-origin 이동과 형상 중심 이동을 따로 기록한다.
  형상 중심은 접촉점·해부학적 손바닥 중심·native COM이라고 가정하지 않는다.
- [x] 2. 같은 입력의 fresh native 초기화에서 Jacobian tensor를 취득·refresh한다.
  CPU descriptor의 shape/device/dtype과 fixed-root row/column 계약을 확인한다.
  human/guitar/DOF 상태·targets·PD·LA 및 steps=0이 조회 전후 같은지 검사한다.
  저장 초기 상태와도 대조한다. 초기 tensor가 없거나 0이면 준비 실패로 기록하고,
  simulate 또는 상태 재설정으로 임의 보완하지 않는다.
  이 단계의 nonzero/shape 검사만으로 Jacobian의 기준점·frame 정확성을 인증하지 않는다.
- [x] 3. 결과에 맞춰 현재 기준의 별도 위치 보정 제안을 작성하고 독립 검수한다.
  Native Jacobian 대 fresh 초기 FK 유한차분으로 world frame·origin/COM·열 대응을
  검증하는 것은 다음 계측 단계다. 제어 구현 전에 그 검증이 필요하다.
  실제 위치 task/변화율 제한/새 gain의 적용은 중요한 변경으로 먼저 사용자에게 확인한다.

설치된 문서는 fixed root의 shape를 `(env, links-1, 6, dofs)`로 설명한다.
root row와 free-root의 추가6열이 없으며, body row는link_index-1이다.
문서는 선형·각속도 대응을 설명하지만 이 프로젝트의 palm 기준점에 대한
Jacobian 원점/COM 및 초기 refresh 시점은 실측으로 구분해야 한다.
참조: `/home/ajou/yigyu/3/isaacgym/docs/programming/tensors.html:293`.

출력은 `docs/2026-10-12/stability_adapter_2/results/palm_frame_audit_v1/`에
원시 tensor·점 좌표·로그·그림·설명·입력 SHA를 보존한다. 기존 결과를 덮어쓰지 않는다.

## 계측 결과

첫 gymtorch 조회는 설치된 Ninja 부재로 실패했고, 두 번째 조회는 capsule 포인터를
ctypes 주소로 해석해 실패했다. 두 로그와 당시 코드를 보존했다. 세 번째는 문서의
CPU float32 descriptor.data_address를 읽어 복사했고 정상 종료했다. 의존성 설치는 없다.
검수 후 0행 거부 판정을 추가한 네 번째 조회도 정상 종료했고 9개 검사를 통과했다. Jacobian shape `(1,65,6,105)`, palm rows L17/R43가
nonzero다. 이 준비 검사만으로 frame/COM/FK 미분 정확성을 인증하지 않는다.
저장된 왼손 source 형상 중심 이동은1초138.278mm/3초144.535mm다.
원점과 형상 중심을 구분하는 다음 계획은 PALM_POSITION_CURRENT_PROPOSAL.md를 따른다.

"""Read-only comparison of fixed initial strap lengths at one humanoid pose."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--results-dir',type=Path,required=True)
    parser.add_argument('--reference-dir',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args = parser.parse_args()
    if args.out.exists():raise FileExistsError('preserve previous comparison')
    audit = read(args.results_dir/'strap_inputs.json')
    base_run = args.results_dir/'short/load_00n'
    base = read(base_run/'report.json')
    initial = np.array(base['initial_joint_targets_rad'])
    state0 = read(base_run/'states.json')[0]
    arm = base['arm_indices']
    selection_path = args.results_dir/'native_selection.json'
    selection = read(selection_path)
    rows,paths = [],[args.results_dir/'strap_inputs.json',selection_path]
    for prefix in (args.results_dir,args.results_dir/'off'):
        for group in ('short','hold_05s','hold_1s'):
            for path in sorted((prefix/group).glob('*/report.json')):
                run = path.parent
                raw = {n:read(run/(n+'.json')) for n in ('report','trace','states','contacts','controls','leg_torques')}
                report,trace,states,contacts,controls = [raw[n] for n in ('report','trace','states','contacts','controls')]
                matched = [r for r in audit['records'] if r['id']==run.name and r['settings']==report['initial_settings']]
                target = np.array(report['initial_joint_targets_rad']);arm = report['arm_indices']
                q = np.array([[v['pos'] for v in s['human_dof_states']] for s in states])
                command = np.array([c['final_arm_targets_rad'] for c in controls])
                counts,steps,up = {},{},[]
                for s in states:
                    body,names = s['human_body_states'],report['human_body_names']
                    p = {n:np.array([body[names.index(n)]['pose']['p'][a] for a in ('x','y','z')]) for n in ('L_Wrist','LH:middle1','LH:index1','LH:pinky1')}
                    normal = np.cross(p['LH:middle1']-p['L_Wrist'],p['LH:index1']-p['LH:pinky1'])
                    up.append(float(normal[2]/np.linalg.norm(normal)))
                for sample in contacts:
                    for c in sample['contacts']:
                        pair = (c['body0_name'],c['body1_name'])
                        if any(n.startswith('guitar/') for n in pair):
                            for n in pair:
                                if n.startswith('human/'):
                                    counts[n] = counts.get(n,0)+1
                                    steps.setdefault(n,set()).add(sample['physics_step'])
                mode = 'on' if prefix==args.results_dir else 'off'
                checks = {'native_checks':all(report['checks'].values()),
                    'accepted_initial_recipe':bool(matched) and all(r['accepted_for_diagnostic'] for r in matched),
                    'all_initial_targets_and_bodies_fixed':bool(np.array_equal(target,initial)) and states[0]==state0,
                    'only_length_setting_changes':{k:v for k,v in report['initial_settings'].items() if k!='strap_rest_length_m'}=={k:v for k,v in base['initial_settings'].items() if k!='strap_rest_length_m'},
                    'first_law_tension_matches_source_query':bool(matched) and all(abs(trace[1]['last_applied_tension_n']-r['initial_law_tension_n'])<1e-9 for r in matched),
                    'initial_native_limits_and_arm_box':bool(((target>=np.array(report['native_joint_lower_rad'])-2e-7)&(target<=np.array(report['native_joint_upper_rad'])+2e-7)).all() and ((target[arm]>=np.array(report['diagnostic_lower_rad'])-2e-7)&(target[arm]<=np.array(report['diagnostic_upper_rad'])+2e-7)).all()),
                    'saved_initial_q_and_zero_velocity_match':bool(np.array_equal(q[0],target) and all(v['vel']==0 for v in states[0]['human_dof_states'])),
                    'reported_mode_matches_path':report['mode']==mode,
                    'fixed_rest_length':all(s['strap_rest_length_m']==report['absolute_rest_length_m'] for s in trace) and report['absolute_rest_length_m']==report['initial_settings']['strap_rest_length_m'],
                    'target_bounds':bool(((command>=np.array(report['diagnostic_lower_rad'])-2e-7)&(command<=np.array(report['diagnostic_upper_rad'])+2e-7)).all() and (np.abs(command-target[arm])<=.15+2e-7).all()),
                    'exact_control_schedule':all(c['updated_before_step']==(mode=='on' and i%4==0) for i,c in enumerate(controls)),
                    'sample_counts':len(states)==len(trace)==len(raw['leg_torques'])==report['physics_steps']+1 and len(contacts)==len(controls)==report['physics_steps'],
                    'finite_controls_and_dofs':bool(np.isfinite(command).all() and np.isfinite(q).all()),
                    'execution_sources_current':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in report['source_sha256'].items())}
                for key in ('human_joint_names','human_body_names','guitar_body_names','arm_indices','native_pd_kp','native_pd_kd','native_drive_modes','native_effort_caps_nm','native_joint_lower_rad','native_joint_upper_rad','diagnostic_lower_rad','diagnostic_upper_rad','physics_parameters','guitar_goal_position_m','guitar_goal_quaternion_xyzw','initial_route_length_m','controller','physics_hz','control_hz'):
                    checks[key+'_unchanged'] = report[key]==base[key]
                if group!='short':
                    short = prefix/'short'/run.name
                    checks['short_prefix_exact'] = all(raw[n][:25 if n in ('states','trace','leg_torques') else 24]==read(short/(n+'.json')) for n in raw if n!='report')
                if mode=='off':
                    checks['paired_initial_native_state_exact'] = states[0]==read(args.results_dir/group/run.name/'states.json')[0]
                rows.append({'run':str(run.resolve()),'group':group,'name':run.name,'mode':mode,'duration_s':trace[-1]['time_s'],'checks':checks,
                    'rest_length_m':report['absolute_rest_length_m'],'initial_law_tension_n':trace[1]['last_applied_tension_n'],'max_position_error_m':max(s['position_error_m'] for s in trace),'max_rotation_error_deg':max(s['rotation_error_deg'] for s in trace),
                    'end_position_error_m':trace[-1]['position_error_m'],'end_rotation_error_deg':trace[-1]['rotation_error_deg'],
                    'end_linear_speed_mps':trace[-1]['linear_speed_mps'],'end_angular_speed_rad_s':trace[-1]['angular_speed_rad_s'],
                    'max_applied_tension_n':max(s['last_applied_tension_n'] for s in trace[1:]),
                    'max_arm_raw_drift_deg':float(np.rad2deg(np.abs(q[:,arm]-target[arm])).max()),
                    'max_arm_scalar_limit_violation_deg':float(np.rad2deg(np.maximum(np.maximum(np.array(report['native_joint_lower_rad'])[arm]-q[:,arm],q[:,arm]-np.array(report['native_joint_upper_rad'])[arm]),0)).max()),
                    'min_left_palm_up_dot':min(up),'saturated_physics_samples':sum(any(c['saturated']) for c in controls),
                    'contact_rows_by_human_body':counts,'contact_physics_samples_by_human_body':{n:len(v) for n,v in steps.items()},
                    'contact_first_last_step_by_human_body':{n:[min(v),max(v)] for n,v in steps.items()}})
                paths += [run/(n+'.json') for n in raw]+[Path(p) for p in report['source_sha256']]
    declared = [Path(c[c.index('--out')+1]).resolve() for p in args.results_dir.glob('*_commands.json') for c in read(p)]
    required = {'load_00n'} | set(selection['selected_ids'])
    checks = {'initial_audit_contracts':audit['runtime_sources_unchanged'] and all(all(r['checks'].values()) for r in audit['records']),
        'selected_inputs_unique_and_accepted':len(selection['selected_ids'])==len(set(selection['selected_ids'])) and set(selection['selected_ids'])<={r['id'] for r in audit['records'] if r['accepted_for_diagnostic']},
        'initial_route_unchanged_across_lengths':all(r['initial_route_length_m']==audit['reference_route_length_m'] for r in audit['records']),
        'initial_audit_sources_current':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==s for p,s in audit['source_sha256'].items()),
        'all_selected_short_ON_present':{r['name'] for r in rows if r['group']=='short' and r['mode']=='on'}==required,
        'declared_run_coverage_exact':len(declared)==len(rows) and set(declared)=={Path(r['run']) for r in rows},
        'reference_reproduces_previous_raw5':all(read(args.results_dir/group/'load_00n'/(n+'.json'))==read(args.reference_dir/group/'wrist_minus0050'/(n+'.json')) for group in {r['group'] for r in rows if r['name']=='load_00n' and r['mode']=='on'} for n in ('states','trace','contacts','leg_torques','controls'))}
    paths += [args.reference_dir/group/'wrist_minus0050'/(n+'.json') for group in {r['group'] for r in rows if r['name']=='load_00n' and r['mode']=='on'} for n in ('states','trace','contacts','leg_torques','controls')]
    paths += list(args.results_dir.glob('*_commands.json'))+[Path(p) for p in audit['source_sha256']]+[Path(__file__).resolve()]
    output = {'scope':'Fixed initial strap lengths, identical humanoid and guitar state, unchanged joint PI; no p/q feedback or stability/playing certificate','checks':checks,'rows':rows,
        'reference_dir':str(args.reference_dir.resolve()),'semantics':'contact rows are not force/cause/depth; first/last do not imply continuity; saturation counts held physics samples',
        'input_sha256':{str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
    args.out.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'checks':checks,'failed_rows':{r['run']:[k for k,v in r['checks'].items() if not v] for r in rows if not all(r['checks'].values())}},indent=2))
    if not rows or not all(checks.values()) or not all(all(r['checks'].values()) for r in rows):raise SystemExit(1)


if __name__=='__main__':main()

"""Plot recorded lower-body PD/solver diagnostic summaries; no simulation."""
import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="comparison_all.json")
    parser.add_argument("--output", type=Path, required=True, help="PNG output path")
    args = parser.parse_args()
    rows = json.loads(args.input.read_text())["rows"]
    names = [row["preset"] for row in rows]
    positions = [row["position_error_mm"] for row in rows]
    rotations = [row["rotation_error_deg"] for row in rows]
    leg_deviations = [row["max_leg_raw_target_deviation_deg"] for row in rows]
    x = list(range(len(rows)))

    limits = [row["max_native_scalar_limit_violation_deg"] for row in rows]
    fig, axes = plt.subplots(4, 1, figsize=(13.5, 10.5), sharex=True)
    axes[0].bar(x, positions, color="#2563a6")
    axes[0].set_yscale("log")
    axes[0].set_ylabel("Position error\n(mm, log)")
    axes[0].grid(True, axis="y", alpha=.25)
    axes[1].bar(x, rotations, color="#d97706")
    axes[1].set_ylabel("Rotation error\n(deg)")
    axes[1].grid(True, axis="y", alpha=.25)
    axes[2].bar(x, leg_deviations, color="#7c3aed")
    axes[2].set_ylabel("Raw leg target Δ\n(deg)")
    axes[2].grid(True, axis="y", alpha=.25)
    axes[3].bar(x, limits, color="#b91c1c")
    axes[3].set_ylabel("Scalar-limit violation\n(deg)")
    axes[3].set_xlabel("Recorded 0.1 s diagnostic preset")
    axes[3].grid(True, axis="y", alpha=.25)
    axes[3].set_xticks(x, names, rotation=42, ha="right", fontsize=8)
    fig.suptitle("Lower-body PD/solver comparisons — diagnostics, not stability success", fontsize=12)
    fig.text(.5, .01,
             f"Raw leg values are direct, unwrapped actual−target differences. All {len(rows)} rows use the same initial "
             "pose and absolute strap length; 0.1 s CPU PhysX runs.", ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .045, 1, .97), h_pad=1.2)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=170, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()

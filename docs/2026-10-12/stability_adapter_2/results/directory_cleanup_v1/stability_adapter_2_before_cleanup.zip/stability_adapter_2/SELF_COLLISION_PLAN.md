# Humanoid 내부 충돌 활성화

사용자 요청: humanoid의 손–손, 팔–몸통 등 내부에서도 native 충돌 반력이 생기게 한다.
원본/이전 실행을 보존하고 새 경로에서 적용한다. 필요한 결정은 별도 승인 없이 진행한다.
root와 하체는 물리 고정, 몸통9/상지66/기존 PD·PI와 자유 기타·수동 strap을 유지한다.

1. 설치 SDK 계약과 importer의 native shape filter를 초기화1회/physics0으로 읽는다.
   actor filter−1은 importer 설정 보존,0은 모든 self pair 허용,양수는 전체 self 제외다.
   원래 contact/exclude28쌍·관절 연결부·동일 고정 cluster는 구분한다.
2. 공통 human filter1을 제거하고 importer의 인접/명시 제외는 보존하는 새 환경을 구현한다.
   shape pair 전체 행렬로 양손 및 비인접 팔–몸통 허용을 검사한다. guitar의 공통 filter2와
   disabled thumb_pad/support/pluck proxy filter3은 새 human mask와 호환되는지 검증한다.
   외부 기타 충돌이나 proxy 제외를 조용히 깨뜨리지 않는다.
3. 마지막 near2µm 초기각·기타 생성 위치·LA에서 OFF/ON0.1초를 비교한다. OFF는 이전
   raw prefix를 재현해야 한다. 실제 human–human contact 행, 속도/유한값/하체 고정과
   기타 drift를 기록한다. 반력은 contact lambda를 힘 단위로 임의 변환하지 않고 기록한다.
   native contact가 관찰되지 않으면0.5초까지만 추가 진단하며 안정화 성공을 주장하지 않는다.
4. 결과 이미지/짧은 영상·문서와 원자료를 docs/2026-10-12/stability_adapter_2/results/
   self_collision_v1/에 저장하고 독립 검토한다. 후속 기본 경로를 새 환경으로 갱신한다.

초기 source 교차와 실제 cooked collider는 다르다. 초기 비인접 교차가 발견되면 이를
해결하지 않은 채 안정 자세라고 부르지 않는다. 인접 mesh 겹침이 있다는 이유로 비인접
손/팔/몸통 충돌 전체를 다시 끄지 않는다. 기타 고정·손 부착·runtime pose 재주입은 없다.

- [x] native importer filter0step 사전 계측
- [x] 최소 self-collision 구현·pair matrix 검증
- [x] 짧은 실행·산출물·독립 검토

사전 계측 완료: importer에서도 양쪽 손/손목은 동일640(128|512)이다. 이 값은
양손뿐 아니라 반대 팔꿈치와도 충돌을 제외한다. 왼쪽 distal에서는 오른쪽 elbow bit,
오른쪽 distal에서는 왼쪽 elbow bit만 제거한다. 동일 손 내부의 importer 제외는 우선
보존하므로 이 단계는 손가락–손가락 전체 충돌까지 켜는 설정은 아니다.
기본 filter0인7개 human shape에는 서로 다른 미사용 bit를 부여해 기존 허용 행렬을
유지한다. guitar는 human과 겹치지 않는 예약 bit를 쓰고, disabled proxy는 모든
human/guitar active shape와 공유하는 mask를 사용한다. ground/chair의 기존 처리는 유지한다.
전체 행렬과 native readback으로 원래 명시 exclude28쌍/손–기타 허용/proxy 제외를 검사한다.

OFF/ON 각0.1초 완료: 초기 전체 상태가 이전near2µm와 exact이며 OFF raw5도 재현했다.
ON의1431 activehuman body pair 중 shape mask가1115쌍을 허용하고316쌍을 제외한다.
importer 기본 행렬 대비323쌍을 추가 허용하며 의도하지 않은 변화는 없다. 이전 OFF는
공통 human mask1 때문에 모든 self pair가 제외됐다는 점과 구분한다.
사람 내부 접촉은0→9행, LH:palm–RH:index1 pair의 positive rawlambda6행이다.
기록 step20–24(.083333–.1초)이며 정확한 최초 접촉시각/힘 단위/무관통을 인증하지 않는다.
기타 최대오차4.041302mm/.641189°→4.035079mm/.639349°로 작은 차이이며 LH–기타
접촉0이 남아 안정성공이 아니다. 하체8개 link fullstruct는 모두 고정이다.
충돌 기능이 확인돼0.5초 확장하지 않는다. 이후 기본은 SelfCollisionEnvironment로 두고,
현재 초기 자세는 지지 성공으로 채택하지 않는다. 손가락끼리의 비인접 충돌을 추가하려면
같은 손의 importer exclusion group을 더 세분화하는 별도 설계가 필요하다.

이미지·전체 25개 저장 pose 영상과 최종 독립 검토를 완료했다. 변경 경로와 실제 줄 번호는
[CHANGED_FILES.md](../docs/2026-10-12/stability_adapter_2/results/self_collision_v1/CHANGED_FILES.md)에 기록했다.

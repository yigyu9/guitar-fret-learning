# 어깨 목표 추종의 최소 PD 비교 제안

2026-10-07. 사용자가 “승인할게 시도해줘”로 아래 비교 범위를 승인했다.
구현·검수 후 기준/시험 각0.1초, 계약에 문제가 없으면 각0.5초를 진행한다.

## 근거와 목적

동일 PALM_RATE의 0.5초에서 기타 최대 이탈은36.091149mm/4.761921°,
왼손 source 중심 이탈은90.540508mm였다. L_Shoulder_x와 R_Shoulder_z의
완료 step 목표–실제 native scalar 차이는 최대21.619762°/17.266792°였다.
총 DOF force 센서를 추가해도 기존7개 원자료가 같았으므로 관측은 확보했지만,
actuator 전용 토크가 아니어서 포화·PD 부족의 원인을 판단하지 못했다.

다음에는 초기각·스트랩을 더 세분화하기 전에 **어깨 stiffness만 바꾼 물리 비교**로
목표 추종과 기타 유지가 실제로 개선되는지 확인한다. Gain 부족을 전제하지 않는다.
손 위치 개선만으로 기타 유지 성공을 선언하지 않는다.

## 비교할 두 조건

| 항목 | 기준 | 시험 |
|---|---:|---:|
| L/R Shoulder x/y/z 6 native DOF stiffness |200|300|
| 같은 6 DOF damping |50|50|
| 같은 6 DOF effort cap (Nm) |150|150|
| 나머지 DOF의 PD/effort |기존|기존|
| controller |PALM_RATE|PALM_RATE|

Native DOF 좌표 이름에 따른 설정이며 독립 Euler 관절/모터별 분리를 주장하지 않는다.
각 fresh 환경 생성 때만 properties를 설정하고 실행 중 gain을 바꾸지 않는다.
초기 q/고정 root/기타 초기 p(+5mm)·q/절대 LA1.1010801317960974m와 물리 조건은 같다.
Torso·Spine·Chest9 목표, Thorax 이하66 연결, 손가락42·C02하체 목표를 유지한다.
Thorax/Elbow/Wrist gain과 ±0.15rad 보정·기준±0.3rad box·0.02rad/update도 같다.
자유 기타·접촉·스트랩 힘을 유지하며 상태 덮어쓰기·강제 부착·기타 복원력은 없다.

## 작은 실행 순서와 검토

- [x] 사용자 승인: 어깨6 stiffness200→300 비교라는 새로운 PD 변경을 확인했다.
- [x] 구현/독립 검수: 별도 비교 CLI로 설정6개만 변경됨을 확인한다.
- [x] 기준/시험 각0.1초: 기존 초기 source/LH 조건과 native 계약을 검사했다.
- [x] 코드·계약 실패가 없어 같은 두 조건을 각0.5초 실행하고 검토했다.

초기 gate 불통과, 비유한값, 예상 외 설정·목표 변경, solver/계측 계약 실패 시
해당 단계에서 중단하고 실패·부분 로그를 보존한다. 관측된 악화도 결과로 남긴다.
후속1초 연장·새 gain·damping·effort·제어권 변경은 이번 승인에 포함하지 않는다.

각 시간에서 기타 초기 p/q 최대·최종 오차, 왼손 초기 위치 이탈, 양팔 목표–실제
scalar 차이, 실제 scalar 한계 위반, source 손바닥/국소 넥 조건과 native 접촉을 비교한다.
힘 센서는 총 DOF force로만 기록하고 effort cap과 직접 비교해 포화로 부르지 않는다.
개선 여부를 보고 원래 초기 자세/스트랩 탐색 또는 다음 제어 설계를 결정한다.
아직 기타 유지의 성공 허용치나 연주 성공 기준을 임의로 정하지 않는다.

산출물은 docs/2026-10-12/stability_adapter_2/results/shoulder_pd_compare_v1에
이미지와 설명, 실제 명령·원자료·실패 기록·변경 파일 줄 번호를 저장했다.

## 실제 결과

기준/시험 각24·120step의4fresh rollout, 총288step을 완료했다. Native13계약과
wrapper의6개stiffness만 변경/초기상태·SDK저장목표 유지/총힘 계측·SHA 계약이 통과했다.
200의기존7raw exact와 각조건의raw7·force short prefix도 일치했다.
후처리 첫실행의 step0 회전 재계산 차이 약1.01e−7° 실패·소스를 보존했다.
Quaternion은exact였고 near-identity acos 검사를 cosine4float64eps 기준으로 수정했다.
검증본7계약/131SHA는 통과했으며 native를 재실행하지 않았다.

| 0.5초 최대 관측 | stiffness200 | stiffness300 |
|---|---:|---:|
| 기타 위치오차(mm) |36.091149|35.780031|
| 기타 회전오차(°) |4.761921|4.550541|
| LH source 초기위치 이탈(mm) |90.540508|91.485370|
| L_Shoulder_x 완료step scalar 목표–실제 gap(°) |21.619762|22.803789|
| R_Shoulder_z 완료step scalar 목표–실제 gap(°) |17.266792|17.915964|
| 실제 arm native scalar 한계위반(°) |0.030300|0.043885|
| LH / RH contact 행 |0 / 135|0 / 100|

0.5초 마지막 시점의 기타 위치오차는34.773068→35.780031mm로 오히려1.006964mm
늘었고, 회전오차는4.316934→4.236367°였다. 구간 최대값 감소를 후기 유지 개선으로
해석하지 않는다. 300의 위치오차 최대는 이번 구간의 끝0.5초에서 관측됐다.

구간 최대 기타 두오차는0.311118mm/0.211380° 줄었지만 손이탈·어깨gap은 늘었다.
Stiffness 단독 증대가 추종·지지 문제를 해소하지 못했으므로300을 채택하지 않고
200을 진단 기준으로 유지한다. 같은제어수학이어도 피드백 상태가 달라 전달목표는 다르다.
Source 손방향/국소 넥 조건 관측은 유지됐지만 실제 지지·cooked clearance 인증이 아니다.
총힘은 actuator-only 토크·PD원인의 증거가 아니다. 1초는 미측정이며 안정/연주 성공은 아니다.

코드·실제 원시 기록·최종 그림·문서 독립 검수를 완료했다.
[그림과 상세 결과](../docs/2026-10-12/stability_adapter_2/results/shoulder_pd_compare_v1/README.md) 및
[변경 파일·실제 줄 번호](../docs/2026-10-12/stability_adapter_2/results/shoulder_pd_compare_v1/CHANGED_FILES.md)를 참고한다.

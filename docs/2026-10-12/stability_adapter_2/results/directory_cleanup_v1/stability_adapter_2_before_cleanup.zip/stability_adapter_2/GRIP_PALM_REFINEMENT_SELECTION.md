# source 결과 기반 실제5초 후보 선택

grip_palm_refinement_v1/search.json의8개 source 후보를 검토했다. 새 native 실행 전 기록이다.
사람–기타/양손/비인접 왼손 source 교차가 없고 palm-up>0이며 max gap과 palm gap이
기준 seed2보다 줄어든 후보는5개다. 전체 fit 적용은 교차 때문에 거절한다.
원자료와 실패 후보는 모두 보존하며 손–기타 source 교차를 접촉이라고 재분류하지 않는다.

- `w1_a0p5`: 최대 gap2.868843mm, palm2.129666mm. 여섯 target gap 모두3mm 이내다.
- `w1_a0p25`: 최대 gap4.342514mm, palm2.980610mm. 같은 방향의 작은 보정으로 비교한다.

기준 seed2는 최대 gap5.830554mm/palm3.841850mm, 이전 실제5초 최대 기타오차
26.772807mm/8.323296°다. 기준 원자료는 이전 경로에서 읽으며 이번에 재실행하지 않는다.
같은 w1 방향의 1/2·1/4를 골라 정적 접근량의 차이에 따른 실제 유지 성능을 확인한다.
w2 방향도 저장했지만1/2에서 비인접 왼손 교차가 남아 이번 native 대상으로 쓰지 않는다.

각 후보는 새 run_grip_palm_refinement에서 fresh native q 범위/비선택 DOF/초기PD목표/
source교차/up/FK를 적분 전 확인하고 통과하면5초 실행한다(최대2init/2400step).
초기 근접3mm는 접촉 유지·하중 지지·cooked clearance·기타 안정화 성공과 다르다.
PD/LA/기타초기p,q/root하체고정/오른손/몸통9목표/startupoffset 법칙은 동일하다.

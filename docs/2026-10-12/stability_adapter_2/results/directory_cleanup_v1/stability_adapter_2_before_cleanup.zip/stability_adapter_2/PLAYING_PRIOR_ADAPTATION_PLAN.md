# 자유 기타에서 fret·strike prior를 사용하는 학습 설계

## 목적과 현재 판단

사용자 추가 목표: 기타가 안정된 상태에서 기존 fret·strike 체크포인트로 연주하고,
자유 기타의 자세·속도·접촉 변화 때문에 생기는 연주 오차를 학습으로 줄인다.
기타의 **초기 world 위치·회전 복원/유지**와 **현재 기타에 대한 연주 정확도**를 함께 달성한다.
2초는 분석 구간의 기준일 뿐 필수 WAIT나 연주 시작 조건이 아니다.

이번 단위는 코드/체크포인트 계약 조사와 설계다. 기존 체크포인트 선정 완료,
연주 연결 구현 완료, 신규 학습/물리 실행 완료를 뜻하지 않는다.
기존 코드·자산·체크포인트와 소비된 실험 계획은 보존한다.

## 이번 단위와 다음 단위

- [x] 기존 관측 좌표계, action 의미, 실행 후 history, actuator 차이 조사.
- [x] 대표 체크포인트 두 개의 계약·정규화 buffer·관절 이름을 CPU로 읽어 증거 저장.
- [x] 단일 최종 제어권과 단계별 학습/평가 계획을 자체 검토·기록. 독립 검수는 도구 한도로 미완료.
- [ ] 다음: 평가 기록으로 source 후보를 좁히고, 이름 기반 60→66 매핑과 관측 view를 작은 CPU 계약 검사로 구현.
- [ ] 이후: 하나의 Isaac Gym 환경에서 짧은 연주 구간을 실행하고 초기값·0~5초 실제 스트랩 영상을 저장.
- [ ] 연결 검증 후 보정 정책 소규모 학습, 동일 구간 비교, 범위 확장.

## 확인된 기존 계약

| 항목 | Fret-v2 | Strike-v2 | 설계 영향 |
|---|---|---|---|
| 관측 차원 | 420 | 303 | 실제 checkpoint manifest와 순서를 대조한다 |
| 연주 action | 왼쪽 Shoulder~손가락 30 | 오른쪽 Shoulder~손가락 30 | 양쪽 Thorax 6은 source action에 없다 |
| 손/목표 geometry | 현재 기타 frame G | 현재 기타 frame G | 고정된 world 목표를 그대로 재사용하지 않는다 |
| action 의미 | 정규화 [-1,1] → EMA → 관절 범위의 절대 PD 목표 | 동일 기본 의미 | 현재 초기각에 action을 rad offset처럼 더하지 않는다 |
| 후처리 | 단계별 mask·finger synergy | pick grip 제한 등 | 실제 checkpoint의 학습 단계별 실행 계약을 보존한다 |
| history | 이전 실행 action 30 | 이전 실행 action 30 | raw actor 출력 대신 최종 적용 목표에 대응하는 값을 넣는다 |

근거: [Fret 계약](/home/ajou/yigyu/3/tab2body/fret_v2_contract.py:17),
[Strike 계약](/home/ajou/yigyu/3/tab2body/strike_v2_contract.py:19),
[원본 action 변환](/home/ajou/yigyu/3/tab2body/env/base.py:824),
[이름 기반 기존 조립](/home/ajou/yigyu/3/tab2body/full/action.py:146).
기존 Full의 105D/60 active 조립은 참고 계약이다. 현재 fixed-lower 81 native DOF,
주요 제어 66에 그대로 넣을 수 있는 완성된 simulator backend가 아니다.
[현재 Full 구현 상태](/home/ajou/yigyu/3/full/03_implementation/STATUS.md:1)를 따른다.

## 오차를 세 종류로 나누어 해결

1. **관측/실행 계약 오류**: G 좌표 변환, 관절 이름/순서, limit, EMA, 후처리,
   정규화, 이전 action, event clock 오류는 학습으로 숨기지 않고 연결 코드에서 먼저 해결한다.
2. **같은 연주 목표의 물리 응답 차이**: 기타가 움직이고 양손이 동시에 힘을 주며
   초기 자세·하체 구속·self-collision·접촉 형상·PD 방식이 달라진다. 이는 보정 정책의 학습 대상이다.
3. **연주 prior 자체의 한계**: 원래 고정 기타에서도 실패하는 이벤트는 자유 기타 오차와 구별한다.
   학습 iteration이나 파일 날짜로 성공한 source라고 판정하지 않는다.

기존 helper는 회전하는 G frame의 상대 속도까지 계산한다:
`v_G = R_G^T (v_hand - v_Gorigin - omega_G × (p_hand-p_Gorigin))`.
Native API의 COM/root 속도 의미를 대조한 뒤 사용한다. 단순히 world 속도를 회전시키거나
기타 속도를 관측에서 0으로 지우면 안 된다.
[구현](/home/ajou/yigyu/3/tab2body/env/base.py:1033).
Projected gravity는 기존 policy가 학습한 **Thorax local** 정의를 유지한다.
정규화 통계는 source별 체크포인트 값을 동결하고, 새 보정 정책은 별도 통계를 사용한다.
정규화 clip 비율과 범위를 벗어난 관측 field를 기록한다.

## 제어권: 하나의 최종 목표만 제출

주요 제어 범위는 양쪽 Thorax부터 손가락까지 66이다. 몸통9 목표 유지,
root/하체 고정, 나머지 native 관절 목표 유지, 자유 기타와 수동 스트랩을 유지한다.

```mermaid
flowchart LR
  S[하나의 실제 물리 상태·연주 clock] --> V[현재 G 기준 source 관측]
  V --> P[동결 fret·strike + 단계별 후처리]
  P --> M[관절 이름 기반 연주 목표 조립]
  S --> R[연주 오차·기타 초기 p/q 오차를 보는 보정 정책]
  M --> C[보정 합성·제한·한 번의 평활화]
  R --> C
  C --> D[하나의 81D PD 목표 제출]
  D --> S
```

source 60개 관절은 checkpoint limit/scale로 정의한 연주 목표를 사용한다.
추가 Thorax 6개는 현재 안정화 기준 목표를 시작값으로 사용하며 보정 정책에 제어권을 준다.
제어되지 않는 native 관절은 이름으로 식별해 목표를 유지한다. 인덱스 단순 연결은 하지 않는다.

권장 합성은 **연주 목표 + 하나의 공동 residual**이다. residual은 66관절에 대해
연주 오차와 기타 초기 p/q 오차를 동시에 관측한다. 연주 정책과 별도 안정화 정책이
같은 관절의 PD 목표를 각각 제출하거나 두 보정량을 검증 없이 누적하지 않는다.
기존 PI 등을 활성화한다면 잔차/포화 역할을 먼저 분리하고 OFF 비교를 한다.

EMA 전 연주 목표 `u_play`, rad 보정 `delta_q`, 직전 최종 목표 `q_prev`에 대해
`u = u_play + delta_q`, `q_next = alpha*q_prev + (1-alpha)*u`를 기본으로 한다.
모델/손 관절 한계, task별 grip 안전 범위, 목표 변화율을 한 번의 합성 과정에서 적용한다.
최종 적용 `q_next`를 이름별로 역정규화해 source history에 돌려준다.
source 관절의 최종 목표는 native 한계와 checkpoint 한계의 교집합 안에 두어
history가 표현할 수 있게 한다. 범위 밖 값을 몰래 clip해서 실제 적용값과 다르게 보고하지 않는다.
잔차0에서 source 후처리·EMA·history가 원래와 일치하는 검사를 선행한다.
기존 source EMA 이후에 다시 EMA를 적용하는 이중 평활화는 하지 않는다.
모든 task 특유의 제한이 이 단순 수식과 동일한 순서인지는 실제 후보별로 확인한다.

현재 native POS PD와 source의 explicit stiffness torque + implicit damping은 다르다.
따라서 action 변환 일치만으로 actuator 동등성을 주장하지 않는다.
현재 native 방식을 유지한 짧은 전달 오차를 먼저 측정하고, backend 변경은 별도 비교로 수행한다.
첫 source target과 현재 유지 target의 점프를 기록하며, 필요하면 제한된 목표 변화율로 이행한다.
강제 pose 변경이나 필수 접근/그립 단계로 해결하지 않는다.

## 학습 구조와 입력·보상

우선 source 가중치/정규화를 동결하고 작은 feed-forward residual actor와 critic을 학습하는
구조를 권장한다. 기존 PPO 배관은 재사용 가능성을 조사하되 이전 StabilityAdapter의
33D/단계 reward를 복사하지 않는다. 최종 입력 차원·hidden 폭·gain·잔차 한도·보상 가중치는
관측/제어 연결과 무학습 baseline 측정 후 정한다. 초기 residual 출력은 0으로 둔다.
66 전체에 권한을 두되 arm/finger별 탐색 크기를 분리한다. support 손가락을 영구 동결하지 않는다.

입력: source 관측/연주 이벤트와 위상, 양쪽 base action, 실제 q/qdot와 직전 최종 목표,
현재 G p/q/속도와 초기 목표에 대한 오차, 손–넥/피크–현 오차, 지지 접촉 상태,
strap 길이/여유/장력. Raw contact lambda를 힘 N으로 잘못 입력/보고하지 않는다.
접촉만으로 충분히 관측되지 않는 경우에 한해 짧은 history나 recurrent 구조를 후속 비교한다.

| 목적 | 학습/평가 항목 | 주의 |
|---|---|---|
| Fret | 지정 현/프렛/손가락, 압현 유지, 잘못 누른 현, 전환·release timing | 실제 task detector 계약 대조 |
| Strike | 지정 현, 방향, event timing, 중복·누락·오타현, 회복 | 상대 피크–현 속도와 crossing 사용 |
| 기타 유지 | 초기 world p/q 오차·최대 이탈·후기 변화 | 현재 G frame 연주 오차와 별도 목적 |
| 물리/제약 | 비인접 자기충돌, 과한 교차, 관절 범위, 목표 급변, 잔차 포화 | 관측 가능한 실제 물리 근거로 평가 |
| 부드러운 제어 | 잔차 크기·변화율, 사용 가능한 effort 지표 | 미세 떨림을 성공 배제 조건으로 삼지 않음 |

연주 보상과 기타 유지 보상을 함께 둔다. 손을 멈추어 기타만 유지하거나,
연주만 맞추며 기타를 계속 이동시키는 경우 모두 따로 드러나도록 metric을 분리한다.
왼손 위쪽 반구/넥 옆면 지지와 가까운 평행은 초기 자세 제약·연주 중 soft 선호로 구분한다.
연주 중 특정 손바닥 접촉을 영구 필수로 두어 운지 전환을 막지 않는다.
초기 p/q 허용값과 연주 성능 저하 한도는 실제 비교 뒤 명시하며 임의 성공 판정을 하지 않는다.

## 단계별 비교와 승급

1. **계약/후보 조사**: 동일 곡의 체크포인트, 평가 결과, manifest, 관절 한계,
   normalization, actuator, collision filter, thumb support/pick geometry를 대조한다.
   기존 fixed-guitar 평가는 보존 자료를 우선 사용한다. 재현이 필요하면 새 별도 reference run에
   한정하며 자유 기타 실험에는 고정을 도입하지 않는다.
2. **무학습 연결**: 같은 단일 환경·같은 상태에서 양쪽 관측 생성, 한 clock, 한 PD 제출,
   한 physics step, 실행 history 회신을 검사한다. 짧은 단일 이벤트/전환부터 시작한다.
3. **잔차 학습**: 선별한 소수 이벤트에서 free G와 작은 reset perturbation으로 시작한다.
   초기 자세/LA 변형은 유효 초기 겹침 검사를 통과한 범위만 사용하고 episode 중 LA는 고정한다.
   외력 perturbation이 필요하면 별도 trial로 기록한다. 상태 덮어쓰기를 perturbation으로 쓰지 않는다.
4. **확장/평가**: 운지 전환→여러 현/타현→짧은 phrase→더 긴 구간으로 확장한다.
   비교 조건은 source-only, source+학습하지 않은 동일 residual 구조(출력0), source+학습 residual이다.
   세 조건이 항상 서로 다른 제어라고 가정하지 않고 잔차0 동등성 검사 결과를 남긴다.
   필요하면 고정된 관절 목표 보정 기준도 별도 condition으로 비교한다.
5. **선택적 fine-tune**: 계약이 맞는데도 지속적인 residual 포화와 연주 실패가 남으면
   source 복사본의 일부 층만 작은 learning rate와 원본 action 유지 penalty로 조정한다.
   원본은 보존하고 개선 여부를 held-out 이벤트/초기조건에서 확인한다.

각 실제 trial은 초기값, seed, source SHA/계약, controller 설정, 실제0~5초 스트랩 포함
전신/손 영상을 저장한다. 학습 중에는 고정 평가 seed/이벤트 구간을 주기적으로 기록한다.
학습에 사용하지 않은 초기 perturbation과 이벤트를 따로 평가한다.
기타 초기 오차/후기 변화, fret·strike 성능, 목표/실제각 오차, 잔차 포화, 접촉을 함께 비교한다.

## 이번 조사 한계와 기존 실험 연결

대표 두 파일은 ABI 조사용이다. 최신/최고 성능/최종 채택 checkpoint로 선정하지 않는다.
Fret 대표는 goal_pair 단계여서 full_song용 frozen loader의 자격을 자동 충족하지 않는다.
현재 CPU 계약 조립 Full 구현도 실제 양손 Isaac Gym rollout 완료를 뜻하지 않는다.
사용 가능한 GPU/학습 backend 검사는 아직 하지 않았고 학습도 시작하지 않았다.

기존 body9 PD×2 정지 유지와 같은 손목 움직임의 LA−2mm는 기초 물리 증거다.
손목1축 작은 움직임을 fret·strike 연주 검증으로 확대 해석하지 않는다.
LA total−4mm 계획은 미실행으로 보존하며, source 연결 설계와 별도 실험 단위로 이어간다.

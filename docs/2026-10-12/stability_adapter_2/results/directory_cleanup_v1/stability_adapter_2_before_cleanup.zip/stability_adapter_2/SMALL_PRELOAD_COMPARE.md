# 개선된 손목 자세에서 작은 스트랩 초기 장력 비교

2026-10-06. wrist_pose_strap_v1의 5/10/20N 길이는 같은 humanoid 초기 자세에서
1초 위치·회전을 모두 악화시켰다. 기존 0–5N 구간 안의 1/2N을 비교한다.
초기 장력과 유지 성능이 단조 관계라고 가정하지 않는다.

- [x] 1. 이전 0N 입력을 그대로 복사하고 L0=1.1010801317960974m,
  stiffness=6000N/m의 LA=L0−T0/6000으로 1/2N 입력을 만든다.
  새 read-only auditor가 전체 초기 humanoid q/body·guitar p/q·목표·PD·route 동일,
  모델 한계·vel0·no steps·길이만 변경을 확인하고 fresh source 겹침/LH 조건을 검사한다.
  기존 생성기·검사기·실험 source는 수정하지 않는다.
- [x] 2. 통과한 0/1/2N의 기존 PI ON을 0.1초 실행한다. 새 어깨 접촉이 없는
  조건은 0.5/1초 ON으로 직접 비교한다. 0.5초 순위로 1초를 추정하지 않는다.
  0N raw5는 이전 negative_pose_late_v1 wrist_minus0050와 기간별 exact여야 한다.
- [x] 3. 1초 최대 위치·회전이 모두 0N보다 작은 길이만 동일 초기 조건에서
  OFF 0.1/0.5/1초를 비교한다(최대2조건). 없으면0N을 유지한다.
  기존 compare_strap_initial_trials.py로 모든 기간·고정LA·초기상태·PI·SHA·명령
  coverage를 검증한다. 기준은 진단용이며 성공 기준은 임의로 선언하지 않는다.
- [x] 4. Luna가 저장 trace 그림·표·설명을 누적27절에 추가하고 별도 검수를 받는다.
  절대 파일 경로·실제 줄, raw/로그·명령·보존본·검증 기록을 남긴다.

24팔 PI ±0.15rad/60Hz와 C02±0.3rad∩모델, 주요66 연결, Torso/Spine/Chest9·
손가락42·C02하체 초기 목표, root 고정, 기타 +5mm p/q, native PD/solver를 유지한다.
기타 fixation/강제 손 부착/runtime pose 덮어쓰기/동적 strap/새 제어/gain/gate/학습은 없다.
초기 source 음수 pair0·LH 위쪽 반구·국소 넥 아래를 유지하며 source query는 PhysX
cooked clearance·지지력 인증이 아니다. 실제 q/속도·접촉·장력·포화를 별도로 측정한다.

계획·구현·입력: stability_adapter_2 및 trials/small_preload_v1.
원자료·로그·그림·설명: docs/2026-10-12/stability_adapter_2/results/small_preload_v1.

## 실행 결과와 다음 방향

초기3입력 모두 fresh source 음수 pair0·LH up0.926704·국소 넥 아래24.622mm를
통과했다. 전체 native 초기 q/body·기타 p/q·PD·route는 같고 길이만 달랐다.
0/1/2N 절대LA는 각각1.1010801317960974/1.1009134651294308/
1.1007467984627641m다. 0.1/0.5/1초 ON9회를 완료했다.
1N은0.5초35.468898mm/4.990968°로0N35.481509mm/4.991410°보다 조금 작았지만
1초79.221741mm/15.027785°로0N73.660431mm/13.502121°보다 커졌다.
2N의1초는120.773180mm/30.086380°였다. 개선 길이가 없어 새 OFF는 실행하지 않는다.
기존0N 길이와 개선된 손목각을 다음 진단 기준으로만 유지한다.

모든1초 ON은212 physics samples에서 보정이 포화됐으며 LH/어깨 contact0이다.
RH thumb3 행/unique samples는0/1/2N에서221/78,194/74,137/53이고 마지막 관측
step163/160/138이다. 행과 first/last는 힘·인과·깊이·연속 지지 인증이 아니다.
최대 적용 장력은15.034899/15.463361/15.991668N이며 초기 설정값은 runtime 일정힘이 아니다.
큰 drift와 종료 속도가 남아 안정·연주 성공이 아니다.

다음은0N 길이를 유지하고 현재 초기각에서 R_Wrist_x를−0.0025/−0.005rad 더
조정하는 fresh source 검사다. C02±0.3rad∩모델 안의 조건만 만들고 다른 초기각은 유지한다.
이미 관찰한 음수방향의1초 개선을 조금 더 검사하며 효과가 계속된다고 가정하지 않는다.
기타 오차 feedback과 학습은 사용자 확인 전 추가하지 않는다.

"""Plot existing batch-contract report/trace files without modifying them."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt


TRIAL_LABELS = {
    "H0_LA": "H0, rest 1.089185 m",
    "H0_RElbow_plus002_LA": "R_Elbow_x +0.02 rad, rest 1.089185 m",
    "H0_LA_plus001": "H0, rest 1.090185 m (trajectory overlaps H0_LA)",
}


def load_completed(batch_dir):
    checkpoint = json.loads((batch_dir / "checkpoint.json").read_text())
    trials = {}
    for trial_id, entry in checkpoint["completed"].items():
        report_path = batch_dir / entry["report"]
        digest = hashlib.sha256(report_path.read_bytes()).hexdigest()
        if digest != entry["sha256"]:
            raise ValueError(f"completed report hash mismatch for {trial_id}")
        report = json.loads(report_path.read_text())
        trace_path = report_path.with_name("trace.json")
        trace = json.loads(trace_path.read_text())
        if not report.get("completed") or report.get("stability_success") is not None:
            raise ValueError(f"unexpected diagnostic status for {trial_id}")
        trials[trial_id] = (report, trace)
    if not trials:
        raise ValueError("checkpoint has no completed trials")
    return trials


def plot(batch_dir, output):
    trials = load_completed(batch_dir)
    fig, axes = plt.subplots(1, 3, figsize=(16, 5.6), constrained_layout=True)
    colors = {"H0_LA": "#2563a6", "H0_RElbow_plus002_LA": "#dd7b22",
              "H0_LA_plus001": "#24835b"}

    for trial_id, (report, trace) in trials.items():
        label = TRIAL_LABELS.get(trial_id, trial_id)
        color = colors.get(trial_id)
        time = [sample["time_s"] for sample in trace]
        axes[0].plot(time, [1000 * sample["position_error_m"] for sample in trace],
                     marker="o", ms=3, color=color, label=label)
        axes[1].plot(time, [sample["rotation_error_deg"] for sample in trace],
                     marker="o", ms=3, color=color, label=label)
        route = [sample["strap_length_m"] for sample in trace]
        rest = [sample["strap_rest_length_m"] for sample in trace]
        axes[2].plot(time, route, marker="o", ms=3, color=color,
                     label=f"{label}: route length")
        axes[2].plot(time, rest, color=color, linestyle="--", alpha=0.65,
                     label=f"{label}: absolute rest length")

    axes[0].set(title="Guitar position error", xlabel="Time (s)", ylabel="Position error (mm)")
    axes[1].set(title="Guitar rotation error", xlabel="Time (s)", ylabel="Rotation error (deg)")
    axes[2].set(title="Strap lengths", xlabel="Time (s)", ylabel="Length (m)")
    for ax in axes:
        ax.grid(True, alpha=0.25)
        ax.legend(fontsize=7, loc="best")
    fig.suptitle("Batch contract v1 — three 0.1 s CPU PhysX diagnostics (not stability success)",
                 fontsize=12)
    fig.text(0.5, -0.035,
             "All three starts include source-shape R_Hip–G:body signed gap −1.331 mm; "
             "this is a penetration candidate, not calibrated depth or PhysX clearance certification.",
             ha="center", fontsize=9)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=160, bbox_inches="tight")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", type=Path, required=True,
                        help="batch directory containing checkpoint.json")
    parser.add_argument("--out", type=Path, required=True, help="output PNG path")
    args = parser.parse_args()
    plot(args.batch, args.out)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Render sealed shoulder-target response traces from saved native runs."""
import hashlib
import importlib.util
import json
import math
import shutil
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path("/home/ajou/yigyu/3")
A = ROOT / "stability_adapter_2"
P = ROOT / "docs/2026-10-12/stability_adapter_2/results/fixed_strap_shoulder_response_v1"
BASE = ROOT / "docs/2026-10-12/stability_adapter_2/results/joint_only_fixed_strap_v1/native"
OUT = P / "artifacts"
FIGURE = OUT / "fixed_strap_shoulder_response.png"
SNAPSHOT = OUT / "source_snapshot"
MANIFEST = OUT / "artifact_manifest.json"
FONT = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
SOURCE_FILES = [
    A / "make_fixed_strap_shoulder_artifacts.py",
    A / "run_fixed_strap_shoulder_phase.py",
    A / "prepare_fixed_strap_shoulder_response.py",
    A / "analyze_fixed_strap_shoulder_response.py",
    A / "analyze_small_wrist_motion.py",
    A / "analyze_body9_strap_minus4mm.py",
    A / "analyze_body9_strap_fine.py",
    A / "warmstart_targets.py",
    A / "strap.py",
    A / "build_fixed_lower_asset.py",
    A / "FIXED_STRAP_SHOULDER_RESPONSE_PLAN.md",
]


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line]


def archive_sources():
    OUT.mkdir(exist_ok=False)
    SNAPSHOT.mkdir()
    producer_hash = sha256(SOURCE_FILES[0])
    files = []
    for source in SOURCE_FILES:
        relative = source.relative_to(ROOT)
        copied = SNAPSHOT / relative
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, copied)
        digest = sha256(source)
        if sha256(copied) != digest:
            raise RuntimeError("source copy SHA mismatch: " + str(source))
        files.append({"original_path": str(source), "copy_path": str(copied), "sha256": digest})
    record = {"producer_sha256": producer_hash, "files": files}
    (OUT / "source_snapshot.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    return record


def load_saved_metrics(path):
    spec = importlib.util.spec_from_file_location("saved_shoulder_metrics", str(path))
    if spec is None or spec.loader is None:
        raise ImportError("cannot load archived saved-trace metrics helper")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.metrics


def input_paths(analysis, snapshot):
    paths = {Path(path) for path in analysis["input_sha256"]}
    paths.update(SOURCE_FILES)
    paths.update({P / "analysis.json", P / "proposal.json", P / "preparation.json",
                  P / "minus008_execution.json", P / "plus008_execution.json",
                  P / "minus008.log", P / "plus008.log",
                  BASE / "videos.json", FONT, OUT / "source_snapshot.json"})
    for row in snapshot["files"]:
        paths.add(Path(row["copy_path"]))
    for folder in (BASE, P / "minus008", P / "plus008"):
        for camera in ("hands", "whole_body"):
            for frame in ("00000.png", "00150.png"):
                paths.add(folder / "frames" / camera / frame)
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError("missing sealed inputs: " + ", ".join(sorted(missing)))
    return {str(path): sha256(path) for path in sorted(paths)}


def verify_summary(summary, rows, metrics):
    if len(rows) != 1201 or rows[0]["time_s"] != 0.0 or rows[-1]["time_s"] != 5.0:
        raise ValueError("expected 1201 saved trace rows covering 0 through 5 seconds")
    observed = metrics(rows)
    for key, value in observed.items():
        if not math.isclose(value, summary[key], rel_tol=0.0, abs_tol=1e-8):
            raise ValueError("analysis summary differs from saved helper metric: " + key)


def main():
    if FIGURE.exists() or MANIFEST.exists() or OUT.exists():
        raise SystemExit("refusing to overwrite; use a fresh artifact path")
    analysis = read_json(P / "analysis.json")
    if not analysis["checks"] or not all(analysis["checks"].values()):
        raise ValueError("analysis checks are incomplete")
    expected_counts = (2, 2400)
    observed_counts = (analysis["new_native_initializations"], analysis["new_physics_steps"])
    if observed_counts != expected_counts:
        raise ValueError("analysis does not describe the expected two saved native probes")

    snapshot = archive_sources()
    before = input_paths(analysis, snapshot)
    for path, expected in analysis["input_sha256"].items():
        if before[path] != expected:
            raise ValueError("analysis input SHA mismatch: " + path)
    if before[str(A / "make_fixed_strap_shoulder_artifacts.py")] != snapshot["producer_sha256"]:
        raise ValueError("producer does not match its pre-run snapshot")

    helper = load_saved_metrics(SNAPSHOT / "stability_adapter_2/analyze_small_wrist_motion.py")
    traces = {
        "baseline": read_jsonl(BASE / "trace.jsonl"),
        "minus008": read_jsonl(P / "minus008/trace.jsonl"),
        "plus008": read_jsonl(P / "plus008/trace.jsonl"),
    }
    summaries = {row["label"]: row["guitar"] for row in analysis["summary"]}
    for label, rows in traces.items():
        verify_summary(summaries[label], rows, helper)

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 11})
    fig, axes = plt.subplots(1, 2, figsize=(14.0, 7.2))
    fig.suptitle("Fixed passive strap: constant L_Shoulder_y target offsets", fontsize=14)
    series = [
        ("baseline", "Current18 baseline", "#3568a8"),
        ("minus008", "Shoulder target −0.008 rad", "#d97728"),
        ("plus008", "Shoulder target +0.008 rad", "#2a8b62"),
    ]
    panels = [
        ("position_error_m", 1000.0, "Guitar position error to initial world pose", "Position error (mm)"),
        ("rotation_error_deg", 1.0, "Guitar rotation error to initial world pose", "Rotation error (degrees)"),
    ]
    for ax, (field, scale, title, ylabel) in zip(axes, panels):
        ax.axvspan(2.0, 5.0, color="#777777", alpha=0.10, label="2–5 s evaluation window")
        for key, label, color in series:
            rows = traces[key]
            ax.plot([row["time_s"] for row in rows],
                    [row[field] * scale for row in rows],
                    color=color, linewidth=1.25, label=label)
        ax.set_title(title)
        ax.set_xlabel("Saved native time (s)")
        ax.set_ylabel(ylabel)
        ax.set_xlim(0.0, 5.0)
        ax.grid(True, alpha=0.24)
        ax.legend(frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.16), ncol=2, fontsize=8)
    fig.text(0.5, 0.025,
             "Curves show error to initial world pose; late 2–5 s variation is measured from t=2 s.",
             ha="center", fontsize=8.5)
    fig.tight_layout(rect=(0.0, 0.10, 1.0, 0.92), w_pad=2.4)
    fig.savefig(FIGURE, dpi=180)
    plt.close(fig)

    after = input_paths(analysis, snapshot)
    producer_after = sha256(SOURCE_FILES[0])
    if before != after or snapshot["producer_sha256"] != producer_after:
        raise RuntimeError("producer or sealed inputs changed during render")
    manifest = {
        "producer": str(SOURCE_FILES[0]),
        "producer_sha256_before": snapshot["producer_sha256"],
        "producer_sha256_after": producer_after,
        "inputs_sha256_before": before,
        "inputs_sha256_after": after,
        "outputs_sha256": {FIGURE.name: sha256(FIGURE)},
        "native_calls": 0,
        "physics_steps": 0,
        "actor_inference_calls": 0,
        "training_updates": 0,
        "figure": FIGURE.name,
        "scope": "saved current18, minus008 and plus008 native traces only; no physical or model execution",
    }
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"figure": str(FIGURE), "sha256": manifest["outputs_sha256"],
                      "sealed_input_count": len(before)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

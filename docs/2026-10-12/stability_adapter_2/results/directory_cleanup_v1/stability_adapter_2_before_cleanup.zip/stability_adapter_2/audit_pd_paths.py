"""Read-only audit of original gain/cap functions and stored CPU PD properties."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from .control import control_indices

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def function(path, name):
    tree = ast.parse(path.read_text())
    nodes = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == name]
    if len(nodes) != 1:
        raise ValueError('one original function required: '+name)
    node = nodes[0]
    module = ast.Module(body=[node], type_ignores=[])
    namespace = {'np':np}
    exec(compile(module, str(path), 'exec'), namespace)
    return namespace[name], node.lineno


def constant(path, name):
    tree = ast.parse(path.read_text())
    matches = [node.value for node in tree.body if isinstance(node, ast.Assign) and
               any(isinstance(t, ast.Name) and t.id == name for t in node.targets)]
    if len(matches) != 1:
        raise ValueError('one original literal required: '+name)
    return ast.literal_eval(matches[0])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise FileExistsError('preserve previous audit')
    base = ROOT/'tab2body/env/base.py'
    safety = base.with_name('safety.py')
    fret = base.parent/'tasks/task_fret.py'
    strike = base.parent/'tasks/task_strike.py'
    config = Path(__file__).with_name('config.json')
    gains = ROOT/read(config)['gain_source']
    reference = ROOT/'docs/2026-10-12/stability_adapter_2/results/shoulder_pd_compare_v1/hold_05s/kp200/report.json'
    sources = [base, safety, fret, strike, gains, config, reference, Path(__file__).resolve(),
        Path(__file__).with_name('environment.py'), Path(__file__).with_name('control.py'),
        ROOT/'isaacgym/docs/programming/physics.html', ROOT/'isaacgym/docs/programming/tensors.html']
    inputs = {str(p.resolve()):sha(p) for p in sources}
    stored = read(reference)
    if stored['stiffness'] != 200 or not all(stored['checks'].values()):
        raise ValueError('stored baseline contracts failed')
    if not all(sha(p) == h for p, h in stored['input_sha256'].items()):
        raise ValueError('stored baseline inputs differ')
    inputs.update(stored['input_sha256'])
    names = stored['human_joint_names']
    gain_function, gain_line = function(base, '_compute_gains')
    cap_function, cap_line = function(safety, 'dof_torque_limit')
    kp, kd = gain_function(SimpleNamespace(dof_names=names, _gains_src=read(gains)))
    caps = np.array([cap_function(n) for n in names])
    main_indices, torso_indices = control_indices(names)
    controls = {}
    for task, path, key in (('Fret', fret, 'FRET_CONTROL_PREFIXES'), ('Strike', strike, 'STRIKE_CONTROL_PREFIXES')):
        prefixes = constant(path, key)
        controls[task] = [n for n in names if n.startswith(prefixes)]
    checks = {'105_named_DOFs':len(names) == 105,
        'original_nominal_kp_matches_native200':kp.tolist() == stored['PD_after']['stiffness'],
        'original_nominal_kd_matches_native200':kd.tolist() == stored['PD_after']['damping'],
        'original_explicit_cap_matches_native200_effort_values':caps.tolist() == stored['PD_after']['effort'],
        'task_policy30_each_main66_torso9':all(len(v) == 30 for v in controls.values()) and len(main_indices) == 66 and len(torso_indices) == 9,
        'all_inputs_current':all(sha(p) == h for p, h in inputs.items())}
    result = {'checks':checks, 'input_sha256':inputs,
        'gain_function_source':{'path':str(base), 'line':gain_line},
        'cap_function_source':{'path':str(safety), 'line':cap_line},
        'nominal_rows':[{'joint':n, 'kp':float(p), 'kd':float(d), 'explicit_cap':float(c)} for n, p, d, c in zip(names, kp, kd, caps)],
        'task_policy_names':controls, 'main66_names':[names[i] for i in main_indices], 'torso9_names':[names[i] for i in torso_indices],
        'scope':'actual original pure gain/cap functions, stored native200 properties; no native initialization/step or new actuation',
        'limitations':'nominal equality is not actuator equivalence; original imported effort is not measured here; original POS+force tensor vs docs EFFORT requirement needs runtime API verification, not a bug/failure claim'}
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps({'checks':checks, 'input_SHA_entries':len(inputs)}, indent=2))
    if not all(checks.values()):
        raise AssertionError(checks)


if __name__ == '__main__':
    main()

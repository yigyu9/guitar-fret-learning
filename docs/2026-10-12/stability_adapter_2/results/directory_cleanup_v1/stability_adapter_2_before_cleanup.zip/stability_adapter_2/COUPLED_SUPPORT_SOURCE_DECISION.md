# 팔12·손가락 hinge6 source 검증 후 결정

## 확인한 것

이 단위는 LA−2mm 시험의 실제 저장 상태0/0.1/0.5/5초에서,
왼팔12관절과 thumb/index/middle의 single-hinge6관절을 함께 바꾼 source 형상 검사다.
추가 Isaac Gym 초기화·물리 step·학습·actor 추론은0이다.
실제 연주 제어권은 기존 양쪽 Thorax부터 손가락66관절을 유지한다.

- 조건부 모델의24시점×11링크 비교264개,4개 identity,18축 수치미분5검사 통과.
- v1의 t0 목표 치환 오류를 v2에서 원본 제출 PD 목표로 수정했다.
- v2의 same-left 비인접 source pair 누락을 v3에서110쌍 명시 검사로 보완했다.
- v1/v2 소스·결과·실행 기록·로그는 원본과 별도 보존본을 모두 남겼다.
- v3의7검사 통과.4개 baseline과12개 제안 중 source screen 통과는0.5초의1/4보정 한 개다.

통과한 한 행의 palm–neck side patch 거리 upper는9.994144851→9.972901669mm다.
감소량은 약21.243µm로 작고, 여전히 약10mm 떨어진 source 배치다.
초기와5초 시점에는 통과한 방향이 없다. 손바닥 대표점 오차가 줄어도
전체 손바닥의 patch 거리가 커지는 경우는 거절했다.
손가락–기타 source 교차 증가도 남으므로 이 결과를 완전 그립으로 채택하지 않는다.

## 다음 작은 단위

현재 weighted LS가 손바닥과 엄지/앞면 손가락 목표를 동시에 줄이면서 손바닥 접근을
희생하는 경우가 있다. 다음에는 기존 bounds·whole-source 검사·up hemisphere를 유지하고,
손바닥 접근을 우선하는 목적/제약을 설계해 같은 저장 상태에서 먼저 비교한다.
단 한 시점의 source 통과를 근거로 같은 보정량의 실제5초 PD 실행으로 바로 승급하지 않는다.
새 physical 실행 전 float32 최종 목표로 한계와 baseline 조립을 다시 확인한다.

조건부 모델에는 현재 실측 finger1 상대변환을 공급한다. 이는 전역 손가락 FK나
미래 PD 응답·PhysX 접촉·지지력 인증이 아니다. LP 공통구 반지름도 native penetration이 아니다.
검색 로그의 Isaac Gym plugin preload 경고는 원본에 남겼다. 이번 계산은 native sim을
생성하지 않았으므로 로그 exit0을 실제 native simulator 실행 성공으로 해석하지 않는다.

연주 전이는 [추가 학습 평가 계획](/home/ajou/yigyu/3/stability_adapter_2/PLAYING_RESIDUAL_EVALUATION.md:1)을 따른다.
현재 source 검증과 작은 손목 유지 성능을 fret·strike 연주 성능으로 확대하지 않는다.

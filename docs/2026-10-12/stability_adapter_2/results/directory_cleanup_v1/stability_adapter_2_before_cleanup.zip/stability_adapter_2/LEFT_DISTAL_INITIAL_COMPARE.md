# 왼팔 distal 초기각 단일축 비교

2026-10-07. 오른팔 미세 조합이 1초 이탈을 줄이지 못해 같은 오른팔/LA에서 왼팔 조건을 검사한다.
기준은 negative_pose_late_v1/wrist_minus0050, LA=1.1010801317960974m이다.
기존 사용자 승인 C02±0.3rad∩모델 범위 안에서 L_Elbow_x/y·L_Wrist_x/y 한축씩±0.025rad만 바꾼다.
누락각은 native 기준 초기각에서 가져오며 다른104개 각을 유지한다.

- [x] 1. 기준+8후보를 기존 audit_arm_initial_inputs.py로 fresh 검사한다.
  초기 계약/noSteps, 음수 source pair0, 왼손 위쪽 반구·국소 넥 아래·projection 범위를 유지한다.
  거절 후보는 물리 실행하지 않는다. source 형상은 cooked clearance/지지 인증이 아니다.
- [x] 2. 통과 후보와 기준의0.1초 PI ON을 비교한다. 새 어깨 접촉이 없는 조건은
  짧은 순위로 거르지 않고0.5/1초 ON을 직접 비교한다(최대27 ON).
- [x] 3. 1초 최대 위치·회전이 모두 기준보다 작은 후보 중 양오차 비율 합이 작은
  최대2조건만 같은 초기각 OFF0.1/0.5/1초를 비교한다. 개선 없으면 기준각/LA를 유지한다.
  unchanged compare_arm_initial_trials.py와 원본 read-only 참조 연결로 계약/prefix/명시SHA를 검증한다.
- [x] 4. Luna가 원자료 표·저장trace 이미지·설명을 누적31절에 추가하고 별도 검수를 받는다.
  변경 경로/실제 줄·설정/명령/로그/원자료/보존본/검증을 남긴다.

humanoid root 고정·기타 자유/+5mm 목표p/q·몸통9/손가락42/C02하체 초기 목표 유지.
주요 Thorax 이하66 연결, 팔24 PI±0.15rad/60Hz·기존 PD/gain/solver 유지.
고정·강제부착·runtime pose 덮어쓰기·동적strap·새 gate/제어/학습은 없다.
기타 p/q feedback은 사용자 확인 전이며 현재 관절 목표 유지 PI와 구별한다.
실제각·접촉·속도·포화를 측정하며 접촉 수는 힘/인과/깊이/연속 지지 인증이 아니다.

입력: stability_adapter_2/trials/left_distal_initial_v1.
결과: docs/2026-10-12/stability_adapter_2/results/left_distal_initial_v1.

## 실행 결과와 다음 방향

초기9조건 중기준과5후보가 통과했다. L_Elbow_x+0.025/L_Elbow_y−0.025/
L_Wrist_x−0.025는각2/4/2 source 음수pair로거절했다. 손바닥 정상방향·위쪽반구·
국소넥아래·projection 및 초기계약은9조건에서통과했다. source 부호는물리관통깊이인증이아니다.
통과6조건의ON0.1/0.5/1초18회를완료했다. 모든1초후보는기준73.660431mm/13.502121°보다
이동·회전이커새각채택/OFF추가는없다. 모든1초LH/어깨contact0·포화212physics samples이며
큰drift/종료속도가남아안정·연주성공이아니다.
L_Wrist_y−0.025의초기LH:palm–guitar최소signed source query0.072963mm도실제접촉인증은아니다.
198명시입력SHA/기간prefix/기준raw5/명령coverage와기존물리·제어계약은통과했다.

다음에는측정한LH source 경계를향해한축씩L_Elbow_x+0.003125/+0.00625,
L_Elbow_y−0.0015625/−0.003125,L_Wrist_x−0.00625/−0.0125,L_Wrist_y−0.0375rad를
현재기준에서fresh검사한다. 기존C02±0.3∩모델안이며거절후보는실행하지않는다.
오른팔/LA·source/LH조건·몸통/손가락/C02하체목표·PI/PD/solver/기타목표를유지한다.
새제어/학습은사용자확인전이다.

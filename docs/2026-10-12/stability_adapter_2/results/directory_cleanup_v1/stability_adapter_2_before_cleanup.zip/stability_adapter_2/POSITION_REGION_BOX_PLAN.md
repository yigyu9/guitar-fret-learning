# 기타 위치 허용영역 박스 시각화 계획

사용자 요청대로 기타를 여러 위치로 옮긴 비교표 대신, 기타 한 대를 선택 기준 포즈에 그대로 두고 기타 root 위치가 움직일 수 있는 3D 허용영역 박스를 장면에 표시한다.

- 기타 root 기준점: world `[-0.325, 0.000, 0.800]m`, Euler XYZ `[67.5, 75.0, 157.5]°`.
- 위치영역: X `[-0.50,-0.15]m`, Y `[-0.15,0.15]m`, Z `[0.65,z_chest]m`.
- `z_chest`는 저장된 동일 초기 휴머노이드 자세의 `Chest` rigid-body origin world Z를 읽어 사용한다. 이전 native 시작 상태에서는 약 `0.88374m`다. 이는 가슴 높이의 근사이지 표면/충돌 경계가 아니다.
- box는 기타의 전체 mesh가 아니라 기타 actor-root reference point의 허용영역이다. root marker를 따로 표시한다.
- 정적 Isaac Gym camera image에 camera view/projection으로 투영한 box edge, 가슴 높이 상한과 root marker를 깊이 검사해 그린다. 기타 pose·휴머노이드 pose·물리 step은 바꾸지 않는다.
- 결과는 `docs/2026-10-12/stability_adapter_2/results/position_region_box_v1/`에 저장한다. 기존 boundary comparison phase는 보존한다.

완료 기준: 한 개의 고정 reference guitar와 휴머노이드가 포함된 front/isometric 장면 2개, Chest 기반 상한의 기록, root marker와 영역 수치 설명, zero physics 및 render-state invariant 검증.

#!/usr/bin/env python3
"""Plot saved 0.5 s palm-position comparison data; never runs physics."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


MODES = ("PI", "RATE_PI", "PALM_RATE")
UPDATE_STEPS = tuple(range(1, 118, 4))
COLORS = {"PI": "#2563a6", "RATE_PI": "#d97706", "PALM_RATE": "#16835d"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text())


def target_updates(report, controls):
    arm = report["arm_indices"]
    previous = np.asarray(report["initial_joint_targets_rad"], dtype=float)[arm]
    updates = [control for control in controls if control["updated_before_step"]]
    if [control["physics_step"] for control in updates] != list(UPDATE_STEPS):
        raise ValueError("expected 30 saved 60 Hz target updates at steps 1,5,...,117")
    times, changes = [], []
    for control in updates:
        current = np.asarray(control["final_arm_targets_rad"], dtype=float)
        if current.shape != previous.shape:
            raise ValueError("delivered target vector does not match arm index vector")
        times.append((control["physics_step"] - 1) / 240.0)
        changes.append(float(np.max(np.abs(current - previous))))
        previous = current
    return times, changes


def load_data(results: Path):
    comparison_path = results / "comparison.json"
    comparison = read_json(comparison_path)
    checks = comparison.get("checks", {})
    expected_checks = {"three_trials_contracts_pass", "consumed_sources_current",
                       "all_three_prior_0p1s_prefixes_exact", "three_actual_native_exits_zero",
                       "source_point_reconstruction_consistent", "new_conditions_rate_bound"}
    if set(checks) != expected_checks or not all(checks.values()):
        raise ValueError("comparison must carry six passing contract checks")
    if [row.get("mode") for row in comparison.get("rows", [])] != list(MODES):
        raise ValueError("comparison rows do not match expected modes")
    prefix_checks = comparison.get("prior_0p1s_prefix_checks", {})
    expected_prefixes = {f"{mode}/{name}" for mode in MODES
                         for name in ("states", "trace", "controls", "contacts", "hands", "queries", "leg_torques")}
    if set(prefix_checks) != expected_prefixes or not all(prefix_checks.values()):
        raise ValueError("prior 0.1 s prefix observations are incomplete or failed")
    input_hashes = comparison.get("input_sha256", {})
    if len(input_hashes) != 138:
        raise ValueError("expected 138 embedded input SHA records")
    for name, expected in input_hashes.items():
        path = Path(name)
        if not path.is_file() or sha256(path) != expected:
            raise ValueError(f"comparison input SHA mismatch: {path}")

    state_observations = comparison.get("all_saved_guitar_body_states_exactly_equal_to_PI", {})
    if set(state_observations) != set(MODES[1:]) or any(type(value) is not bool for value in state_observations.values()):
        raise ValueError("recorded guitar-state comparison observation has an unexpected schema")

    series = {}
    consumed = [comparison_path]
    for mode in MODES:
        run = results / mode
        paths = {name: run / f"{name}.json" for name in
                 ("report", "states", "trace", "queries", "controls", "hands", "contacts")}
        raw = {name: read_json(path) for name, path in paths.items()}
        report, states, trace, queries, controls = (raw[name] for name in
                                                    ("report", "states", "trace", "queries", "controls"))
        if not all(report["checks"].values()) or len(states) != 121 or len(trace) != 121 or \
                len(queries) != 121 or len(raw["hands"]) != 121 or len(controls) != 120 or len(raw["contacts"]) != 120:
            raise ValueError(f"saved {mode} run record/check counts do not match 0.5 s contract")
        steps = list(range(121))
        if [x["physics_step"] for x in states] != steps or \
                [x["physics_step"] for x in queries] != steps or \
                [x["time_s"] for x in trace] != [i / 240.0 for i in steps] or \
                [x["time_s"] for x in queries] != [i / 240.0 for i in steps]:
            raise ValueError(f"saved {mode} state/trace/query alignment does not match steps 0..120")
        series[mode] = {**raw, "paths": paths}
        consumed.extend(paths.values())

    # The comparison's booleans are observations: check their consistency with raw saved states,
    # but permit false and plot unmodified data in either case.
    reference_states = [state["guitar_body_states"] for state in series["PI"]["states"]]
    raw_state_equality = {}
    for mode in MODES[1:]:
        raw_equal = [state["guitar_body_states"] for state in series[mode]["states"]] == reference_states
        if state_observations[mode] != raw_equal:
            raise ValueError(f"recorded/raw guitar-state equality observation differs for {mode}")
        raw_state_equality[mode] = raw_equal
    reference_trace = series["PI"]["trace"]
    trace_equality = {
        mode: ([x["position_error_m"] for x in series[mode]["trace"]] ==
               [x["position_error_m"] for x in reference_trace] and
               [x["rotation_error_deg"] for x in series[mode]["trace"]] ==
               [x["rotation_error_deg"] for x in reference_trace])
        for mode in MODES[1:]
    }
    return comparison_path, comparison, series, consumed, raw_state_equality, trace_equality


def plot(series, summary_rows, trace_equality, output: Path):
    fig, axes = plt.subplots(2, 2, figsize=(12.5, 8.2))
    for mode in MODES:
        run = series[mode]
        trace, queries, controls, report = (run[name] for name in ("trace", "queries", "controls", "report"))
        color = COLORS[mode]
        times = np.asarray([item["time_s"] for item in queries])
        source_goal = np.asarray([
            np.linalg.norm(np.asarray(item["left_source_world_m"], dtype=float) -
                           np.asarray(item["palm_goal_world_m"], dtype=float)) * 1000.0
            for item in queries
        ])
        guitar_pos = np.asarray([item["position_error_m"] * 1000.0 for item in trace])
        guitar_rot = np.asarray([item["rotation_error_deg"] for item in trace])
        axes[0, 0].plot(times, source_goal, color=color, marker=".", ms=3.0, lw=1.4, label=mode)
        axes[0, 1].plot(times, guitar_pos, color=color, marker=".", ms=3.0, lw=1.4, label=mode)
        axes[1, 0].plot(times, guitar_rot, color=color, marker=".", ms=3.0, lw=1.4, label=mode)

        update_times, target_changes = target_updates(report, controls)
        axes[1, 1].plot(update_times, target_changes, color=color,
                        marker={"PI": "o", "RATE_PI": "s", "PALM_RATE": "^"}[mode],
                        ms=3.5, lw=1.0, label=mode)

        # Ensure the plotted raw samples agree with each summary row without treating their
        # relative values as a pass/fail criterion.
        row = summary_rows[mode]
        derived = (float(source_goal.max()), float(guitar_pos.max()), float(guitar_rot.max()),
                   float(max(target_changes)))
        expected = (row["max_left_palm_displacement_mm"], row["max_guitar_position_error_mm"],
                    row["max_guitar_rotation_error_deg"], row["max_final_target_change_per_update_rad"])
        if not np.allclose(derived, expected, rtol=0, atol=1e-9):
            raise ValueError(f"raw plotted values do not match recorded summary for {mode}")

    axes[0, 0].set(title="Left source center to palm goal", ylabel="Distance (mm)")
    axes[0, 1].set(title="Guitar position error to shared +5 mm goal", ylabel="Error (mm)")
    axes[1, 0].set(title="Guitar rotation error to shared +5 mm goal", ylabel="Error (degrees)")
    axes[1, 1].set(title="Maximum arm-target change at updates", ylabel="Max |Δ target| (rad)")
    for ax in axes.flat:
        ax.set_xlabel("Time (s)")
        ax.set_xlim(0, .5)
        ax.set_xticks(np.arange(0, .51, .1))
        ax.grid(True, alpha=.24)
        ax.legend(frameon=False, fontsize=8)
    footer = ("Position/rotation traces match exactly." if all(trace_equality.values()) else
              "Guitar position/rotation traces differ; raw values are shown with no visual offset.")
    fig.suptitle("Saved 0.5 s palm-position follow-up — three diagnostic modes", y=.99)
    fig.text(.5, .012, footer, ha="center", fontsize=9)
    fig.tight_layout(rect=(0, .04, 1, .96), h_pad=2.0, w_pad=1.7)
    fig.savefig(output, dpi=170, bbox_inches="tight")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-dir", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    out = args.out_dir.resolve()
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f"refusing to overwrite nonempty output directory: {out}")
    comparison_path, comparison, series, consumed, state_equality, trace_equality = load_data(
        args.results_dir.resolve())
    rows = {row["mode"]: row for row in comparison["rows"]}
    out.mkdir(parents=True, exist_ok=True)
    image = out / "palm_position_half_second.png"
    plot(series, rows, trace_equality, image)
    producer = Path(__file__).resolve()
    manifest = {
        "scope": "saved 0.5 s result visualization only; no native query/run",
        "comparison": {"path": str(comparison_path), "sha256": sha256(comparison_path),
                       "checks": comparison["checks"],
                       "prior_0p1s_prefix_checks": comparison["prior_0p1s_prefix_checks"],
                       "recorded_guitar_state_equality": comparison["all_saved_guitar_body_states_exactly_equal_to_PI"]},
        "observations": {"raw_guitar_body_state_equality_vs_PI": state_equality,
                         "position_rotation_trace_equality_vs_PI": trace_equality},
        "embedded_source_sha256": comparison["input_sha256"],
        "consumed_json_sha256": {str(path.resolve()): sha256(path) for path in consumed},
        "plotter": {"path": str(producer), "sha256": sha256(producer)},
        "outputs": {image.name: {"path": str(image), "sha256": sha256(image)}},
        "derivations": {
            "source_goal_mm": "1000 * norm(queries.left_source_world_m - queries.palm_goal_world_m)",
            "target_change": "max abs delta of delivered arm target vector; initial baseline is report.initial_joint_targets_rad[arm_indices]",
            "target_update_time_s": "(physics_step - 1) / 240; 30 updated_before_step controls at steps 1,5,...,117",
        },
    }
    (out / "plot_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()

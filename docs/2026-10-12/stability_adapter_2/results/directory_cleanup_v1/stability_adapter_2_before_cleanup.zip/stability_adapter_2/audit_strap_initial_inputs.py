"""Fresh initial source checks for fixed-pose 0--5 N strap inputs; no rollout."""
import argparse
import hashlib
import json
from pathlib import Path

from .environment import InitialEnvironment, np, gymapi
from .initial_overlap import build_probe, query_pairs
from .pose_strap_inputs import pose_metrics, input_hashes
from .strap import cable_forces


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-settings',type=Path,required=True)
    parser.add_argument('--settings-dir',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args = parser.parse_args()
    if args.out.exists():raise FileExistsError('preserve prior audit')
    candidates = sorted(args.settings_dir.glob('*.json'))
    if not candidates:raise ValueError('no initial settings inputs')
    hashes = input_hashes(args.base_settings)
    for path in candidates+[Path(__file__).resolve()]:
        hashes[str(path.resolve())] = hashlib.sha256(path.read_bytes()).hexdigest()
    env = InitialEnvironment(json.loads(args.base_settings.read_text()))
    try:
        base_q,names,main = env.initial_q.copy(),list(env.names),env.main_indices.copy()
        human,guitar,goal = env.bodies(env.human),env.bodies(env.guitar),env.goal_position.copy()
        props = env.gym.get_actor_dof_properties(env.env,env.human).copy()
        base_settings,route,mass = env.initial_settings,env.initial_route_length,env.guitar_mass
    finally:
        env.close()
    records = []
    for path in candidates:
        env = InitialEnvironment(json.loads(path.read_text()))
        try:
            h,g = env.bodies(env.human),env.bodies(env.guitar)
            q = env.gym.get_actor_dof_states(env.env,env.human,gymapi.STATE_ALL).copy()
            probe = build_probe(env)
            geometry,hand = query_pairs(*probe),pose_metrics(env,probe)
            points,velocities = env.route()
            strap = env.config['strap']
            _,tension,_,_ = cable_forces(points,velocities,env.rest_length,
                strap['stiffness_n_per_m'],strap['damping_n_s_per_m'],strap['max_tension_n'])
            checks = {
                'only_absolute_length_setting_changes':{k:v for k,v in env.initial_settings.items() if k!='strap_rest_length_m'}=={k:v for k,v in base_settings.items() if k!='strap_rest_length_m'},
                'all_humanoid_initial_targets_and_body_states_unchanged':bool(list(env.names)==names and np.array_equal(env.initial_q,base_q) and np.array_equal(h,human)),
                'initial_native_limits_and_dofs':bool(((env.initial_q>=env.lower-2e-7)&(env.initial_q<=env.upper+2e-7)).all() and np.array_equal(q['pos'],env.initial_q) and (q['vel']==0).all()),
                'guitar_initial_states_and_goal_unchanged':bool(np.array_equal(g,guitar) and np.array_equal(env.goal_position,goal)),
                'native_pd_limits_unchanged':bool(np.array_equal(env.gym.get_actor_dof_properties(env.env,env.human),props)),
                'route_and_main66_unchanged':bool(env.initial_route_length==route and len(main)==66 and np.array_equal(env.main_indices,main)),
                'rest_length_in_existing_zero_to_five_newton_interval':route-5/strap['stiffness_n_per_m']<=env.rest_length<=route,
                'initial_law_tension_in_interval':-1e-9<=tension<=5+1e-9,
                'read_only_no_steps':bool(env.steps==0 and np.array_equal(h,env.bodies(env.human)) and np.array_equal(g,env.bodies(env.guitar)) and np.array_equal(q,env.gym.get_actor_dof_states(env.env,env.human,gymapi.STATE_ALL)))}
            if not all(checks.values()):raise AssertionError(checks)
            accepted = geometry['negative_gap_pair_count']==0 and hand['palm_normal_valid'] and hand['palm_up_dot']>=0 and hand['neck_projection_in_range'] and hand['palm_height_vs_local_lower_m']<=0
            records.append({'id':path.stem,'input_path':str(path.resolve()),'settings':env.initial_settings,
                'checks':checks,'accepted_for_diagnostic':bool(accepted),
                'initial_route_length_m':env.initial_route_length,'initial_law_tension_n':tension,
                'geometry':geometry,'hand':hand})
        finally:
            env.close()
    output = {'phase':'strap','base_settings':str(args.base_settings.resolve()),
        'guitar_mass_kg':mass,'reference_route_length_m':route,'source_sha256':hashes,
        'runtime_sources_unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==s for p,s in hashes.items()),
        'records':records,'scope':'read-only initial source checks; no cooked clearance, support or stability certificate'}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'accepted':[r['id'] for r in records if r['accepted_for_diagnostic']],
        'runtime_sources_unchanged':output['runtime_sources_unchanged']},indent=2))
    if not output['runtime_sources_unchanged']:raise SystemExit(1)


if __name__=='__main__':main()

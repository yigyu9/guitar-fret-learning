"""Replay recorded PD commands in native Gym and capture matching camera frames."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=False)
    report_path=args.reference/'report.json';hashes={str(report_path.resolve()):sha(report_path)};reference=read(report_path)
    files=[Path(p) for p in reference['source_sha256']]
    files += [args.reference/(name+'.json') for name in ('states','trace','tasks','contacts','controls')]
    files += [Path(__file__).resolve()]+[Path(__file__).with_name(n) for n in
        ('probe_palm_contact_facet.py','capture_isaac_gym_initial.py','palm_side_source_checks.py','face_referenced_geometry.py','search_palm_neck_side.py')]
    hashes.update({str(p.resolve()):sha(p) for p in files})
    if reference['failure'] or not all(reference['checks'].values()) or reference['physics_steps']!=24:raise AssertionError('headless contracts')
    if any(sha(p)!=h for p,h in reference['source_sha256'].items()):raise AssertionError('headless sources changed')
    from .probe_palm_contact_facet import PalmCameraEnvironment
    from .palm_side_feedback import context,SETTINGS,np
    from .palm_normal_task import prepare,error_from_state
    from .environment import gymapi
    from .audit_palm_side_target import side_target
    from .run_joint_hold import native_state,snapshot
    from .native_contacts import body_names,read_contacts
    ctx=prepare(context());arm=ctx['indices'];q0=ctx['q0'][arm];bias=np.array(reference['bias_rad'])
    source={n:read(args.reference/(n+'.json')) for n in ('states','trace','tasks','contacts','controls')}
    env=PalmCameraEnvironment(read(SETTINGS),ctx['shift']);names=body_names(env.gym,env.env)
    values={n:[] for n in source};images={};checks={'commands_preserve_states':True,'render_preserves_states':True}
    def record_state():
        state=native_state(env);values['states'].append(state);values['trace'].append(snapshot(env));values['tasks'].append(error_from_state(state,ctx).tolist())
    def capture():
        before=native_state(env);env.gym.step_graphics(env.sim);env.gym.render_all_camera_sensors(env.sim)
        for name in env.camera_specs:
            path=args.out/(name+'_'+str(env.steps).zfill(3)+'.png')
            env.gym.write_camera_image_to_file(env.sim,env.env,env.cameras[name],gymapi.IMAGE_COLOR,str(path))
            _,polygon,_=side_target(env)
            images[str(path.resolve())]={'sha256':sha(path),'physics_step':env.steps,'target_polygon_W_m':polygon.tolist()}
        checks['render_preserves_states'] &= before==native_state(env)
    def save(failure=None):
        report=dict(reference,mode='camera_command_replay',reference_path=str(args.reference.resolve()),source_sha256=hashes,
            native_initializations=1,physics_steps=env.steps,checks=checks,failure=failure,images=images,camera_specs=env.camera_specs,
            scope='actual Isaac Gym camera; recorded PD targets replayed with state equality checked; no pose/state replay')
        for name,value in [('report',report)]+list(values.items()):(args.out/(name+'.json')).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    try:
        record_state();capture()
        for step,control in enumerate(source['controls']):
            if control['updated_before_step']:
                before=native_state(env);target=q0+bias+np.array(control.get('applied_residual_rad',[0.]*12));offsets=np.zeros(66,dtype=np.float32)
                for i,d in zip(arm,target-q0):offsets[list(env.main_indices).index(i)]=d
                env.set_main_offsets(offsets);checks['commands_preserve_states'] &= native_state(env)==before
            actual=dict(control,final_target_rad=env.target[arm].astype(float).tolist());values['controls'].append(actual)
            env.step_physics();record_state();values['contacts'].append({'physics_step':env.steps,'contacts':read_contacts(env.gym,env.env,names)})
            if env.steps%4==0:capture()
        checks.update(camera_five_raw_exact=values==source,inputs_unchanged=all(sha(p)==h for p,h in hashes.items()),images_14=len(images)==14)
        save()
        if not all(checks.values()):raise AssertionError(checks)
        print(json.dumps(checks),flush=True)
    except Exception as error:
        save({'type':type(error).__name__,'message':str(error)});raise
    finally:env.close()


if __name__=='__main__':main()

# 0.5초 저장 기록의 팔 목표–실제 응답 대조

2026-10-07. 기존 3조건 비교의 후속 분석이다. 새 환경이나 제어 설정을 추가하지 않고,
저장된 실제 전달 목표와 4 physics steps 뒤 상태를 읽는다. 사용자가 승인한 반복 검증과
기존 계획의 ‘새 범위를 넓히기 전 목표각–실제응답 대조’ 안에서 진행한다.

- [x] 분석: 이전 138 입력 SHA와 13 frozen copies를 확인하고, 각 조건의 30 갱신을 대조한다.
- [x] 검증: 시점·목표 유지·원자료 대응과 전체 JSON 재생성을 확인하고 별도 검수한다.
- [x] 기록: Luna가 그래프·설명을 만들고 누적 보고서와 변경 파일 줄 번호를 추가한다.

각 갱신은 pre-step k=0,4,...116이며, 같은 전달 목표를 유지하는 다음 상태는 k+4다.
왼팔·오른팔 각각 전달 목표와 현재 실제 관절 좌표의 최대 절대 차이를 degree로 표시한다.
이는 구면 관절의 물리적 상대 회전각이나 실제 토크가 아니다.

왼손에서 `A_k(q_delivered-q_actual)`은 해당 상태의 **정적 선형 목표 이동**이다.
`p_(k+4)-p_k`는 1/60초 뒤 측정된 실제 source 중심 이동이다. 정적 계산에는 응답 시간이
없으므로 두 값을 같은 시간의 예측/오차로 부르거나, 그 차이를 PD 부족의 증명으로 쓰지 않는다.
실제 이동을 갱신 시점의 초기 손 위치 복귀 방향에 투영해, 그 방향의 이동 성분을 본다.
초기 오차가 0인 첫 구간의 투영은 정의하지 않고 null로 저장한다.

추가로 `A_k(q_actual_next-q_actual)`과 실제 이동의 차이를 기록하되, 이는 팔 외 몸통의
움직임·비선형성·frame/미분 오차가 함께 섞인 잔차이며 어느 원인 하나를 확정하지 않는다.
Native force/접촉력/actuator 토크는 이번 저장 기록으로 측정하지 않는다.

Root 고정, 몸통9/손가락42/C02 하체 목표, 주요66 연결, 초기 기타 p/q, 고정 LA,
기존 PD와 제어 수식을 유지한다. 기타 고정·강제 부착·pose 덮어쓰기·학습은 추가하지 않는다.
결과는 docs/2026-10-12/stability_adapter_2/results/palm_target_response_v1에 저장한다.
다음 PD·제어권 변경은 이 자료와 측정 한계를 확인한 뒤 별도 계획으로 사용자에게 확인한다.

## 저장 데이터 분석 결과

각각 30개의 갱신 구간을 분석했다. 실제 전달 목표와 갱신 직전 실제 관절 좌표의
최대 차이는 PI/RATE_PI/PALM_RATE 순으로 왼팔21.038724/21.062126/21.462316°,
오른팔17.213643/17.228633/17.236607°였다. 해당 좌표는 각각 L_Shoulder_x와
R_Shoulder_z다. 원래 자세 대비 관절 편차와 다르며 물리적 상대 회전각이 아니다.

세 조건 모두 정의 가능한29구간의 복귀 방향 투영이 음수였다. 첫 zero-error 구간은
null이다. PALM_RATE 마지막 갱신 구간(0.483333→0.5초)에서 정적 선형 목표 이동은
177.530793mm였지만 측정된16.7ms 손 이동은0.745714mm, 복귀 방향 성분은
−0.613600mm였다. 정적 목표값은16.7ms 변위의 예측이 아니며 PD 부족을 증명하지 않는다.

이 결과로 초기 손 위치 유지가 달성되지 않았음을 확인했다. 다음에는 native DOF force
관측 API의 의미와 현재 backend에서의 계측 가능성을 먼저 확인하는 것이 적절하다.
총 DOF force를 actuator-only 토크나 접촉력으로 바꿔 설명하지 않는다. PD 이득·effort
cap·상태 초기각·기타 목표·스트랩 길이는 아직 바꾸지 않는다.

현재 설치 SDK에는 enable_actor_dof_force_sensors/get_actor_dof_forces 메서드가 있다.
[SDK 설명](/home/ajou/yigyu/3/isaacgym/docs/programming/forcesensors.html:174)은 총 DOF
force라고 명시한다. [API 문서](/home/ajou/yigyu/3/isaacgym/docs/api/python/gym_py.html:1728)는
AssetOptions의 모드 의존성을 언급하지만, 실제 바인딩에는 dof_force_sensor_mode 필드가
없었다. 관측을 위한 메서드 존재와 실제 런타임 계측 지원은 구별한다. 아직 센서 활성화·
새 환경 실행은 없으며 [바인딩 점검 기록](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/palm_target_response_v1/force_api_binding_inspection.json)에 남겼다.

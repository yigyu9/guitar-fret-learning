# 후면·옆면 근접 자세의 실제5초 진단

추가support-plane 검색의완료된 첫후보 old_near17은source human–guitar/양손/비인접왼손교차0,손바닥위쪽반구와native/Aug19/C02/기존목표차이한계를만족한다. 엄지rear witness dot.872530도후면방향이다. 그러나대표점margin.886486mm와thumb/palm유한patch거리2.583857/2.157375mm로기존source접근조건을통과하지못했다. **이조건을초기접촉/grip/안정화성공으로채택하지않는다.** 기존검색결과·게이트·거절사유는그대로보존한다.

다음은이근접자세를actualphysics에서확인하기위한별도진단이다. 필요근거는source대표점/간격만으로actual접촉과자세유지성능을알수없다는점이다. Source검색의support접근gate와native안전초기admission을분리하며,검색기준미달을성공으로재분류하지않는다.

1. 진행중인partial파일은입력으로봉인하지않는다. 완료후보1개의payload를별도immutable snapshot에복사하고SHA를기록한다. 기타목표p·q/LA1.1018469719600776m/PD gain/solver/material·초기81q를동일하게한두조건을준비한다.
2. Native진단admission은source전체human–guitar/양손/비인접왼손교차0,up hemisphere,initial33bounds/모델한계/제출목표한계·FK/실제초기q일치다. Source support조건미달은기록하고면별접촉/초기기타오차를실제로관찰한다. Cooked initial clearance를source만으로인증하지않는다.
3. 조건A는기존절대81PD목표. 조건B는왼손finger21 PD목표만이번actual초기21각으로유지하고팔12/다른48목표는기존값이다. 66인터페이스의한최종목표로합쳐제출한다. Fingers는물리PD로움직이며손/기타attachment나상태overwrite가아니다. 기타오차feedback은아직없다.
4. 새runner는기존consume된native기록runner를SHA대조·복사해진단policy/보고scope만분명히한다. Source/FK초기검사에실패하면partial기록으로남기며5초완료라고표시하지않는다. 통과시각조건actual5초/1200step·초기값/wholebody·hands0~5초151frame30fps를남긴다. 실제제약위반/접촉소실/기타이탈을그대로보인다.
5. Source support-plane3후보검색은그대로완료까지기록하며본진단과별도집계한다. 실제영상·접촉·기타이동/회전과손가락 목표효과로후속초기배치/유지제어를설계한다. 좋은초기기하만으로연주성공으로축소하지않는다.

Root·하체물리고정/몸통9PD목표·최종양쪽Thorax→손가락66권한/자유기타·중력·충돌·수동strap은같다. 기타고정·강제손부착·지속pose덮어쓰기·기타목표외력은없다. 중요조건선택은사용자자율진행지침에따라기록하고진행한다. 독립검수도구thread limit은보류상태이며root검증과구분한다.

- [ ] 완료source snapshot·두native조건/목표compose 사전검증
- [ ] 두actual5초/초기값·전신·손영상
- [ ] source/native별개결과·제약·접촉/지속성비교·이미지설명·보존

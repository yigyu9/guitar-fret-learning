#!/usr/bin/env python3
"""Plot saved DOF force observations and scalar target gaps; no simulator use."""

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

SELECTED = ('L_Shoulder_x', 'R_Shoulder_z')
COLORS = {'L_Shoulder_x': '#4c78a8', 'R_Shoulder_z': '#f58518'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def checked_hashes(mapping, label):
    if not isinstance(mapping, dict) or not mapping:
        raise ValueError(label + ' SHA map missing')
    for path, expected in mapping.items():
        p = Path(path)
        if not p.is_file() or sha(p) != expected:
            raise ValueError(label + ' input SHA mismatch: ' + path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True, help='saved summary.json')
    parser.add_argument('--out', type=Path, required=True, help='new PNG output path')
    args = parser.parse_args()
    summary_path = args.input.resolve()
    out = args.out.resolve()
    report_path = summary_path.parent / 'attempt_v2' / 'force_report.json'
    manifest_path = out.with_name('plot_manifest.json')
    if not summary_path.is_file() or not report_path.is_file():
        raise FileNotFoundError('summary.json and sibling attempt_v2/force_report.json are required')
    if out.exists() or manifest_path.exists():
        raise FileExistsError('preserve existing plot output and manifest')

    summary = json.loads(summary_path.read_text())
    report = json.loads(report_path.read_text())
    required_summary_checks = {'sensor_contracts_pass', 'saved_coverage_alignment', 'finite_shapes', 'inputs_current'}
    required_report_checks = {
        'original_thirteen_native_contracts', 'all_seven_previous_arrays_exact',
        'force_sensor_enable_supported', '120_aligned_force_samples',
        'force_reads_preserve_states_targets_PD', 'observer_and_reference_sources_current',
    }
    if set(summary.get('checks', {})) != required_summary_checks or not all(summary['checks'].values()):
        raise ValueError('summary checks are absent or failed')
    if set(report.get('checks', {})) != required_report_checks or not all(report['checks'].values()):
        raise ValueError('force report checks are absent or failed')
    input_hashes = summary.get('input_sha256', {})
    if len(input_hashes) != 170:
        raise ValueError('expected 170 input SHA entries in summary')
    report_hashes = report.get('input_sha256', {})
    if len(report_hashes) != 167:
        raise ValueError('expected 167 input SHA entries in force report')
    checked_hashes(input_hashes, 'summary')
    checked_hashes(report_hashes, 'force report')

    if len(summary.get('time_s', [])) != 120 or len(report.get('native_DOF_type_codes', [])) != 105:
        raise ValueError('saved 120-step samples and 105 native DOFs required')
    if set(report['native_DOF_type_codes']) != {1} or set(report.get('native_DOF_units', [])) != {'Nm'}:
        raise ValueError('native DOF type/unit metadata differs')
    if report.get('samples') != 120 or report.get('t0_force_measurement') is not None:
        raise ValueError('expected 120 completed-step samples and unmeasured t=0')
    times = np.asarray(summary['time_s'], dtype=float)
    if not np.allclose(times, np.arange(1, 121) / 240.0, atol=1e-12, rtol=0):
        raise ValueError('sample times must correspond to completed steps 1..120')

    fig, axes = plt.subplots(1, 2, figsize=(13.2, 5.8), sharex=True)
    for joint in SELECTED:
        if joint not in summary.get('selected', {}):
            raise ValueError('selected joint missing: ' + joint)
        selected = summary['selected'][joint]
        if selected.get('native_DOF_unit') != 'Nm':
            raise ValueError(joint + ' force unit is not Nm')
        force = np.asarray(selected.get('native_total_DOF_force', []), dtype=float)
        gap = np.asarray(selected.get('post_step_scalar_target_gap_deg', []), dtype=float)
        if force.shape != (120,) or gap.shape != (120,) or not np.isfinite(force).all() or not np.isfinite(gap).all():
            raise ValueError(joint + ' must have 120 finite force and gap samples')
        axes[0].plot(times, force, color=COLORS[joint], lw=1.8, label=joint)
        axes[1].plot(times, gap, color=COLORS[joint], lw=1.8, label=joint)

    axes[0].axhline(0, color='#555555', lw=1, alpha=.75)
    axes[0].set_title('Native total DOF force sensor')
    axes[0].set_ylabel('Signed force (Nm)')
    axes[0].text(.02, .03, 't=0 unmeasured; first sample is completed step 1.',
                 transform=axes[0].transAxes, fontsize=9, color='#444444')
    axes[1].set_title('Post-step target-to-actual scalar coordinate gap')
    axes[1].set_ylabel('Absolute scalar gap (°)')
    axes[1].set_xlabel('Completed-step sample time (s)')
    for ax in axes:
        ax.set_xlim(0, .505)
        ax.set_xlabel('Completed-step sample time (s)')
        ax.grid(True, alpha=.25)
        ax.legend(frameon=False)
    fig.suptitle('Saved DOF force observations and post-step coordinate gaps', fontsize=14)
    fig.tight_layout(rect=(0, 0, 1, .94))

    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=180, bbox_inches='tight')
    plt.close(fig)
    manifest = {
        'purpose': 'read-only plot of saved force report summary; no simulator use',
        'summary': {'path': str(summary_path), 'sha256': sha(summary_path), 'embedded_input_sha256_count': len(input_hashes)},
        'force_report': {'path': str(report_path.resolve()), 'sha256': sha(report_path), 'embedded_input_sha256_count': len(report_hashes)},
        'summary_checks': summary['checks'],
        'force_report_checks': report['checks'],
        'input_sha256': input_hashes,
        'force_report_input_sha256': report_hashes,
        'plotter': {'path': str(Path(__file__).resolve()), 'sha256': sha(__file__)},
        'series': [{'joint': name, 'force_unit': 'Nm', 'gap_unit': 'degree scalar difference',
                    'sample_times_s': [float(times[0]), float(times[-1])], 'samples': 120} for name in SELECTED],
        't0_force_measurement': None,
        'output': {'path': str(out), 'sha256': sha(out)},
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'output': str(out), 'sha256': sha(out), 'summary_sha_count': len(input_hashes),
                      'force_report_sha_count': len(report_hashes)}))


if __name__ == '__main__':
    main()

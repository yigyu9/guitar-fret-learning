# 세 면 후보에서 초기 팔 목표 불일치를 분리하는 비교

## 진단 근거

`three_face_support_loss_v1`은 같은 설정의 추가 1회 실제5초와 두 기존 조건의 저장 actual pose 12개를 분석했다. SDK shape의 friction은 human55개/guitar28개 모두1.0이고 query전후 state/PD/Python 제출목표는 같았다. Source palm 옆면 간격은 saved 조건2.129621→9.894188mm, initial-finger 조건2.129621→5.392989mm였다. Palm 지정facet inward dot은 .994174에서 .979404/.978362로 유지돼 방향만으로 지지위치를 유지하지 못했다. 지정 thumb facet inward dot은 초기−.816388이며 해부학적 pad 정체성은 확인되지 않았다. hull근접과 선택facet 접촉을 동일시하지 않는다.

Left Shoulder_x의 actual-minus-target scalar좌표 오차는 첫 목표 제출 전 이미 .288445rad였고 5초 .378943/.379285rad다. 초기 half 배치와 이전 절대 팔 목표를 달리 둔 의도적 불일치가 포함돼 전체 수치를 PD 추종 실패나 몸체 SO(3) 회전으로 해석하지 않는다. 다음에는 이 목표 불일치만 분리한다. source 거리·facet 방향·접촉 소실만으로 원인을 단정하지 않는다.

## 작은 실행 단위와 체크리스트

- [ ] saved_finger_targets의 실제 초기81각/Gp·q/속도/몸통9·오른쪽·고정 root/하체·PD/solver·절대LA를 유지한다. 기준은 이번 shape readback의 완료된 실제5초를 저장 reference로 사용하며 신규 baseline 실행에 포함하지 않는다.
- [ ] 신규2조건의 왼팔12 absolute PD target을 모두 같은 실제초기12각으로 둔다. 첫 조건은 기존 손가락21 절대목표를 유지하고, 둘째는 손가락21도 실제초기21각을 목표로 둔다. 나머지48 목표와 양쪽66 최종 제어권은 그대로다. 초기 q 자체나 gain/material/strap/controller를 바꾸지 않는다.
- [ ] named offsets±.3 및 native hard range, float64합성→native float32 exact/숨은 clipping 없음, 12/21/48/66 분담을 준비 단계에서 검사한다. fresh 초기 source/FK/위쪽 손바닥 proxy 검사를 통과하면 각각5초 실행한다. 실패는 partial초기값/영상/로그로 남긴다.
- [ ] 두 신규 실행의 초기값·target81·actual states/contacts/control 및 실제Gym 전신/손0~5초151frame 영상을 저장한다. 목표는 물리 PD로 제출하며 관절/bodystate/기타pose를 강제로 유지하지 않는다.
- [ ] 첫.1초/최대/종료/마지막1초 Gp·q오차, arm/finger scalar목표오차와 실제변위, 손바닥/검지/엄지 body접촉을 저장 reference와 비교한다. 세 면 실제 지속지지·힘·PhysX cooked 관통 여부는 body기록/source거리로 인증하지 않는다.

이후 초기각·스트랩 탐색과 기타 오차 복원/유지는 원자료 결과에 따라 계속한다. 이번2조건은 제어 목표의 초기 배치 일치 효과를 보는 진단이며 안정·연주 성공이나 학습 구조 확정은 아니다. SDK 물성은 읽기 진단 후 변경하지 않고 마찰0 가설은 사용하지 않는다. 설정/계획/구현은 `stability_adapter_2/`, 결과는 `docs/2026-10-12/stability_adapter_2/results/three_face_arm_initial_target_v1/`에 둔다. 이 계획은 아직 구현/실행하지 않았다.

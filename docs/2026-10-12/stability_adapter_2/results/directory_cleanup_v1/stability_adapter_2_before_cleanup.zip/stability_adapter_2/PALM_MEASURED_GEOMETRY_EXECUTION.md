# 실제finger pose 기반팔12 기하제안의겹침검사

PALM_MEASURED_POSE_RESIDUAL_PLAN의단계1~2다. 저장body9 PD×2의step0/24/120/1200에서각body actualpose로현재source mesh를만든다. 추가native초기화/physics0이며기존파일/실행을변경하지않는다.

각시점palm_support_runtime_fk_v1의geometricdq를1/0.5/0.25배로검사한다. 팔body의움직임은검증된3좌표FK의현재q→q+dq 차이만사용하고현재actualbodypose에그rigid변화를적용한다. LH:fingerbody는actualpalm에대한현재measuredrelativepose를유지한채palmrigid변화로이동한다. Finger21 q→미래pose를기존실패FK로예측하지않는다. 실제physicsstate에는쓰기없다.

후보각마다전체human–guitar source hull 교차, 움직이는LH팔손과다른human의native mask허용 selfpair 교차, 양손 source 교차를조회한다. Native-connected/samehand importer제외는그대로다. 손바닥전체source hull–요청유한patch거리 witness 상/하한, palmar +Z proxy·normal정렬과PD목표경계를저장한다. 원본source common insphere radius이지cooked penetration depth가아니다.

후보screening은0.1µm LP numericalepsilon과baseline대비source common radius 증가10µm를기준으로‘새/증가 source교차 없음’을표시한다. 이는source후보선별기준이며최종native성공/관통허용기준이아니다. 현재baseline교차도숨기지않고pair명·증가량을보고한다. 팔source point가목표로가까워져도finger겹침/손바닥상향·목표한계를함께본다.

Baseline fraction0의meshes/state는exact변하지않고currentpalm frame의rigid변화는sourceFK palm계산과대조한다. 조건통과시에도실제PD/접촉응답인증은아니다. 안전방향이없으면생성된source collision쌍을근거로작은멀티task/방향변경을정하며임의로gate를낮추지않는다. 이후기존절대81목표+boundedresidual의한actual5초/초기값·스트랩두영상은별도실행계약에서진행한다.

- [ ] 현재actualsource4시점과16배치/fraction0~1검사
- [ ] 원시겹침쌍·palm witness/상향/목표경계 대조
- [ ] 물리ON 실행방향·그림/설명·보존검증

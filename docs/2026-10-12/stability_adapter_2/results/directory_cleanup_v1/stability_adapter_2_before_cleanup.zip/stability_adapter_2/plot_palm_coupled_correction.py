"""Plot saved coupled palm-correction trials; performs no simulation."""
import argparse
import hashlib
import json
import math
from pathlib import Path

ROOT = Path('/home/ajou/yigyu/3')
PHASE = ROOT / 'docs/2026-10-12/stability_adapter_2/results/palm_coupled_correction_v1'
PREVIOUS = ROOT / 'docs/2026-10-12/stability_adapter_2/results/palm_coupled_response_v1'
RUNS = {
    'baseline': PREVIOUS / 'baseline',
    'quarter': PHASE / 'quarter',
    'half': PHASE / 'half',
    'full': PHASE / 'full',
}
ANALYSIS = PHASE / 'analysis.json'


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def explicit_inputs():
    paths = [ANALYSIS, Path(__file__).resolve()]
    paths.extend(folder / name for folder in RUNS.values()
                 for name in ('trace.json', 'contacts.json'))
    paths = [p.resolve() for p in paths]
    if len(set(paths)) != len(paths) or any(not p.is_file() for p in paths):
        raise FileNotFoundError('missing or duplicate declared plot inputs')
    return paths


def read_data():
    analysis = json.loads(ANALYSIS.read_text())
    checks = analysis.get('checks')
    if not isinstance(checks, dict) or len(checks) != 5 or not all(checks.values()):
        raise ValueError('analysis.json must contain five passing checks')
    if analysis.get('counts') != {'native_initializations': 3, 'physics_steps': 72}:
        raise ValueError('unexpected phase counts')
    curves = analysis.get('curves', {})
    if set(curves) != set(RUNS):
        raise ValueError('unexpected analyzed curve labels')
    result = {}
    for label, folder in RUNS.items():
        trace = json.loads((folder / 'trace.json').read_text())
        contacts = json.loads((folder / 'contacts.json').read_text())
        curve = curves[label]
        if len(trace) != 25 or len(contacts) != 24:
            raise ValueError(f'{label}: expected 25 trace rows and 24 contact records')
        times = [float(row['time_s']) for row in trace]
        if any(not math.isfinite(t) or abs(t - i / 240.0) > 1e-9
               for i, t in enumerate(times)):
            raise ValueError(f'{label}: invalid trace time coverage')
        vectors = curve['guitar_error_W_m_rad']
        gaps = curve['source_normal_gap_mm']
        expected_lambda = curve['step_max_raw_palm_lambda']
        if len(vectors) != 25 or len(gaps) != 25 or len(expected_lambda) != 24:
            raise ValueError(f'{label}: invalid analyzed curve coverage')
        position_mm, rotation_deg = [], []
        for i, (sample, vector) in enumerate(zip(trace, vectors)):
            if len(vector) != 6 or not all(math.isfinite(float(x)) for x in vector):
                raise ValueError(f'{label}: invalid guitar world-error vector')
            p = math.sqrt(sum(float(x) ** 2 for x in vector[:3])) * 1000.0
            q = math.sqrt(sum(float(x) ** 2 for x in vector[3:])) * 180.0 / math.pi
            raw_p = float(sample['position_error_m']) * 1000.0
            raw_q = float(sample['rotation_error_deg'])
            if not all(math.isfinite(x) for x in (p, q, raw_p, raw_q)):
                raise ValueError(f'{label}: nonfinite guitar error')
            if abs(p - raw_p) > 1e-5 or abs(q - raw_q) > 1e-5:
                raise ValueError(f'{label}: analyzed error does not match trace')
            position_mm.append(p)
            rotation_deg.append(q)
        lambdas = []
        for step, record in enumerate(contacts, 1):
            if int(record['physics_step']) != step:
                raise ValueError(f'{label}: contact step sequence mismatch')
            values = [float(row['lambda']) for row in record['contacts']
                      if {row.get('body0_name'), row.get('body1_name')} ==
                      {'guitar/guitar', 'human/LH:palm'}]
            value = max(values, default=0.0)
            if abs(value - float(expected_lambda[step - 1])) > 1e-6:
                raise ValueError(f'{label}: raw palm lambda mismatch at step {step}')
            lambdas.append(value)
        if not all(math.isfinite(float(x)) for x in gaps):
            raise ValueError(f'{label}: nonfinite source-normal gap')
        result[label] = {
            'time': times, 'position_mm': position_mm, 'rotation_deg': rotation_deg,
            'gap_mm': [float(x) for x in gaps], 'lambda': lambdas,
        }
    return result


def make_plot(output, data):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager

    font = Path('/usr/share/fonts/truetype/nanum/NanumGothic.ttf')
    if font.exists():
        plt.rcParams['font.family'] = font_manager.FontProperties(fname=font).get_name()
    plt.rcParams['axes.unicode_minus'] = False
    colors = {'baseline': '#555555', 'quarter': '#3977a8',
              'half': '#55a868', 'full': '#d27a27'}
    labels = {'baseline': '기준', 'quarter': 'quarter', 'half': 'half', 'full': 'full'}
    fig, axes = plt.subplots(2, 2, figsize=(12, 8), sharex=True)
    panels = [('position_mm', '기타 위치 오차 (mm)', False),
              ('rotation_deg', '기타 회전 오차 (°)', False),
              ('gap_mm', 'Source normal gap (mm)', False),
              ('lambda', 'Raw palm λ (원시 단위; N 환산 아님)', True)]
    for ax, (field, title, step_series) in zip(axes.flat, panels):
        for name, series in data.items():
            times = series['time'][1:] if step_series else series['time']
            ax.plot(times, series[field], color=colors[name], marker='o', ms=2.5,
                    lw=1.5, label=labels[name])
        ax.set_title(title)
        ax.set_xlim(0, .1)
        ax.set_xlabel('저장 시각 (s)')
        ax.grid(True, alpha=.25)
        ax.legend(fontsize=8)
    axes[1, 1].set_ylim(bottom=0)
    fig.suptitle('저장된 native response · palm–guitar 결합 보정 · 0.1 s', y=.99)
    fig.tight_layout(rect=(0, 0, 1, .96))
    fig.savefig(output, dpi=160, bbox_inches='tight')
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out-dir', type=Path, default=PHASE / 'artifacts')
    args = parser.parse_args()
    out_dir = args.out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    image = out_dir / 'palm_coupled_correction.png'
    manifest = out_dir / 'plot_manifest.json'
    if image.exists() or manifest.exists():
        raise FileExistsError('output exists; choose a fresh output directory')
    inputs = explicit_inputs()
    before = {str(path): sha256(path) for path in inputs}
    data = read_data()
    make_plot(image, data)
    after = {str(path): sha256(path) for path in inputs}
    if before != after:
        image.unlink(missing_ok=True)
        raise RuntimeError('input SHA changed during plotting')
    manifest.write_text(json.dumps({
        'input_sha256': before,
        'producer_sha256': sha256(__file__),
        'output_sha256': {str(image): sha256(image)},
    }, indent=2) + '\n')
    print(image)
    print(manifest)


if __name__ == '__main__':
    main()

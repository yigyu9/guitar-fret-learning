# 손목 Y/Z 측정 응답 비교와 작은 feedback 설계

기존 Y 두 실제5초와 새 Z 두 실제5초의 동일 원quiet baseline을 비교한다. 두6×1열은 t5 trial−baseline의world위치[m]와 world회전log[rad]를 명목목표간격.01rad로나눈 유한응답이다. 이것을순간Jacobian이나전역gain으로인증하지않는다.

새 저장진단은 baseline world p/q·시간grid·오차시계열이exact인지 확인한 뒤6×2행렬과열독립성·오차축기여를계산한다. 비교용위치스케일.03m/회전스케일5°를명시해SVD와열cosine을계산한다. 이스케일은기존임시표시구역을쓰는단위정규화이며새성공gate나물리제약이아니다. 원Yanalysis/series와원baselineinitial은Y봉인inventory SHA에대조한다. 읽은JSON/소스/계획은전후SHA·source사본·사전invocation으로보존한다.

최대±.005rad의2변수boundedleast-squares를저장자료에서만계산해예상world p/q오차를보고한다. 합성된회전은exp(world회전log응답)×baseline회전이며두축동시작용은아직native미측정이다. 값은후보이지실제성능예측의검증/안전보장이아니다. 6×2는arbitrary6D복원권한을보장하지않는다.

다음구조는 q_final=q_hold(or q_play)+delta_q_stabilize를한번합성해nativePD에주는것이다. 우선측정된손목Y/Z에만기타의현재p/q오차로작은목표보정을내고,손가락·몸통목표·root하체·고정strap는유지한다. 초기목표와의world오차를사용하며기타에직접복원력을가하지않는다. 후보가나오면한정된변화율/각도범위에서feedback OFF/ON 실제5초를비교하고접촉·손바닥상향·관절한계·몸통실제각도같이확인한다. 측정소단계를무한히늘리지않고이feedback실험으로진행한다.

- [ ] 두완료Z5초·저장42검사
- [ ] Y/Z6×2·단위정규화·bounded후보·예측한계확인
- [ ] 실제feedback OFF/ON 실행leaf와구현·검증

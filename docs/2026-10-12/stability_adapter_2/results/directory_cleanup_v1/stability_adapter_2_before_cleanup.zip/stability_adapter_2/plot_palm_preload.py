#!/usr/bin/env python3
"""Plot saved 0/1/2 N initial-law preload traces; never runs physics."""

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

LOADS = (0, 1, 2)
COLORS = {0: '#4c78a8', 1: '#f58518', 2: '#54a24b'}
NAMES = {0: '0 N law', 1: '1 N law', 2: '2 N law'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_sha_map(mapping, count):
    if not isinstance(mapping, dict) or len(mapping) != count:
        raise ValueError(f'expected {count} embedded input SHA records')
    for name, digest in mapping.items():
        path = Path(name)
        if not path.is_file() or sha(path) != digest:
            raise ValueError('input SHA mismatch: ' + name)


def load_json(path):
    return json.loads(Path(path).read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True, help='palm_preload_v1 result directory')
    parser.add_argument('--out', type=Path, required=True, help='new PNG output path')
    args = parser.parse_args()
    run = args.run.resolve()
    out = args.out.resolve()
    comp_path = run / 'comparison_validated.json'
    strap_path = run / 'strap_inputs.json'
    execution_path = run / 'rollout_executions.json'
    selection_path = run / 'selection.json'
    manifest_path = out.with_name('plot_manifest.json')
    required = (comp_path, strap_path, execution_path, selection_path)
    if not all(path.is_file() for path in required):
        raise FileNotFoundError('comparison_validated, strap_inputs, rollout_executions, selection required')
    if out.exists() or manifest_path.exists():
        raise FileExistsError('preserve existing plot output and manifest')

    comp = load_json(comp_path)
    strap = load_json(strap_path)
    executions = load_json(execution_path)
    selection = load_json(selection_path)
    expected_checks = {
        'initial_audit_contracts', 'selected_unique_and_accepted', 'declared_fresh_run_coverage',
        'hold_selection_follows_short_shoulder_rule', 'initial_audit_sources_current', 'all_run_checks_pass',
    }
    if set(comp.get('checks', {})) != expected_checks or not all(comp['checks'].values()):
        raise ValueError('comparison contracts missing or failed')
    if len(comp.get('input_sha256', {})) != 136:
        raise ValueError('expected 136 validated comparison SHA entries')
    verify_sha_map(comp['input_sha256'], 136)
    rows = comp.get('rows', [])
    if len(rows) != 6 or not all(all(row.get('checks', {}).values()) for row in rows):
        raise ValueError('all six comparison rows and their checks are required')
    if selection.get('hold_ids') != ['load_01n', 'load_02n']:
        raise ValueError('validated hold selection differs')
    if not isinstance(executions, list) or len(executions) != 4 or not all(e.get('returncode') == 0 for e in executions):
        raise ValueError('expected four successful fresh rollout execution records')

    hold_rows = {int(round(float(row['initial_law_tension_n']))): row
                 for row in rows if row['group'] == 'hold_05s'}
    if set(hold_rows) != set(LOADS):
        raise ValueError('hold_05s must contain 0, 1, and 2 N initial-law conditions')
    traces = {}
    for load in LOADS:
        trace_path = Path(hold_rows[load]['run']) / 'trace.json'
        if not trace_path.is_file():
            raise FileNotFoundError(trace_path)
        trace = load_json(trace_path)
        if len(trace) != 121:
            raise ValueError(f'{load} N hold trace must contain 121 states')
        times = np.asarray([row['time_s'] for row in trace], dtype=float)
        pos = np.asarray([row['position_error_m'] for row in trace], dtype=float) * 1000.0
        rot = np.asarray([row['rotation_error_deg'] for row in trace], dtype=float)
        if not np.allclose(times, np.arange(121) / 240.0, atol=1e-12, rtol=0):
            raise ValueError(f'{load} N trace time coverage differs')
        if pos.shape != (121,) or rot.shape != (121,) or not np.isfinite(pos).all() or not np.isfinite(rot).all():
            raise ValueError(f'{load} N position/rotation traces must be finite length 121')
        traces[load] = {'path': trace_path.resolve(), 'time': times, 'pos': pos, 'rot': rot}

    fig, axes = plt.subplots(2, 2, figsize=(13.2, 8.2), sharex='col')
    for load in LOADS:
        label = NAMES[load] + (' (reused baseline)' if hold_rows[load].get('reused_baseline') else '')
        axes[0, 0].plot(traces[load]['time'], traces[load]['pos'], color=COLORS[load], lw=1.8, label=label)
        axes[0, 1].plot(traces[load]['time'], traces[load]['rot'], color=COLORS[load], lw=1.8, label=label)
    axes[0, 0].set_title('Absolute guitar position error')
    axes[0, 0].set_ylabel('Position error (mm)')
    axes[0, 1].set_title('Absolute guitar rotation error')
    axes[0, 1].set_ylabel('Rotation error (deg)')

    for load in (1, 2):
        delta_pos = traces[load]['pos'] - traces[0]['pos']
        delta_rot = traces[load]['rot'] - traces[0]['rot']
        axes[1, 0].plot(traces[load]['time'], delta_pos, color=COLORS[load], lw=1.8,
                        label=f'{load} N − 0 N (scalar error difference)')
        axes[1, 1].plot(traces[load]['time'], delta_rot, color=COLORS[load], lw=1.8,
                        label=f'{load} N − 0 N (scalar error difference)')
    axes[1, 0].axhline(0, color='#555555', lw=1, alpha=.75)
    axes[1, 1].axhline(0, color='#555555', lw=1, alpha=.75)
    axes[1, 0].set_title('Pointwise signed position-error difference')
    axes[1, 0].set_ylabel('1/2 N minus 0 N (mm)')
    axes[1, 1].set_title('Pointwise signed rotation-error difference')
    axes[1, 1].set_ylabel('1/2 N minus 0 N (deg)')
    for ax in axes.flat:
        ax.grid(True, alpha=.25)
        ax.legend(frameon=False, fontsize=8)
    axes[1, 0].set_xlabel('Saved trace time (s)')
    axes[1, 1].set_xlabel('Saved trace time (s)')
    fig.suptitle('0.5 s saved strap initial-law preload comparison', fontsize=14)
    fig.tight_layout(rect=(0, 0, 1, .95))

    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=180, bbox_inches='tight')
    plt.close(fig)
    direct_inputs = {str(path): sha(path) for path in required}
    direct_inputs.update({str(v['path']): sha(v['path']) for v in traces.values()})
    manifest = {
        'purpose': 'saved PhysX trace plotting only; no simulation or settings changes',
        'validated_comparison': {'path': str(comp_path), 'sha256': sha(comp_path), 'checks': comp['checks'],
                                 'embedded_input_sha256_count': len(comp['input_sha256'])},
        'strap_inputs': {'path': str(strap_path), 'sha256': sha(strap_path)},
        'rollout_executions': {'path': str(execution_path), 'sha256': sha(execution_path), 'fresh_rollouts': len(executions)},
        'selection': {'path': str(selection_path), 'sha256': sha(selection_path)},
        'trace_inputs': {str(v['path']): sha(v['path']) for v in traces.values()},
        'validated_input_sha256': comp['input_sha256'],
        'direct_input_sha256': direct_inputs,
        'series_semantics': 'top row: saved scalar error norms; bottom row: pointwise scalar norm error differences, not displacement vectors or controller corrections',
        'plotter': {'path': str(Path(__file__).resolve()), 'sha256': sha(__file__)},
        'outputs': {'image': {'path': str(out), 'sha256': sha(out)}},
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'image': str(out), 'sha256': sha(out), 'comparison_sha_count': len(comp['input_sha256']),
                      'hold_traces': 3, 'samples_per_trace': 121}))


if __name__ == '__main__':
    main()

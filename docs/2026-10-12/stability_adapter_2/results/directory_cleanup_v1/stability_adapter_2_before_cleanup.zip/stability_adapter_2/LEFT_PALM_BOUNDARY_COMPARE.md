# 왼손 초기 형상 간격 경계 비교

2026-10-07. 이전 왼팔 단일축9조건에서LH:palm 음수query 경계를 확인했지만 실제LH접촉/안정은없었다.
동일 negative_pose_late_v1/wrist_minus0050 기준·LA1.1010801317960974m에서
L_Elbow_x+0.003125/+0.00625,L_Elbow_y−0.0015625/−0.003125,
L_Wrist_x−0.00625/−0.0125,L_Wrist_y−0.0375rad를한축씩초기설정한다.
전체105중다른104q유지,기존C02±0.3rad∩모델범위안이다. 이전동결자료는덮어쓰지않는다.

- [x] 1. 기준+7후보를기존 audit_arm_initial_inputs.py로fresh검사한다.
  source 음수pair0/LH위쪽반구·국소넥아래·projection/noSteps/초기상태·PD·route/LA계약유지.
  거절후보는실행하지않는다. signedquery는cookedclearance/깊이/접촉/지지인증이아니다.
- [x] 2. 통과조건과기준의0.1초PI ON을비교한다. 새어깨접촉없는조건은
  짧은순위로거르지않고0.5/1초ON을직접비교한다(최대24ON).
- [x] 3. 1초최대이동·회전모두기준보다작은후보중정규화양오차합이작은최대2조건만
  같은초기상태OFF0.1/0.5/1초비교한다. 개선없으면기존각/LA유지한다.
  unchanged compare_arm_initial_trials.py와read-only원본참조연결로prefix/계약/명시SHA검증.
- [x] 4. Luna가표·저장trace이미지·설명을누적32절에추가하고독립변경검수한다.
  경로·실제줄·설정/명령/로그/원자료·보존본/검증을남긴다.

humanoid root고정,기타자유/+5mm목표p/q,몸통9·손가락42·C02하체초기PD목표유지.
주요Thorax이하66연결·팔24 PI±0.15rad/60Hz·기존PD/gain/solver유지.
고정·강제부착·runtime pose덮어쓰기·동적strap·새gate/제어/학습은없다.
기타p/q feedback은사용자확인전이다. 실제각·속도·포화·접촉을측정한다.
접촉행/sample·첫끝점은힘/인과/깊이/연속지지인증이아니다. 기준도안정/연주성공이아니다.

입력: stability_adapter_2/trials/left_palm_boundary_v1.
결과: docs/2026-10-12/stability_adapter_2/results/left_palm_boundary_v1.

## 실행 결과와 다음 방향

초기8조건중기준+5후보가통과했다. Elbow_y−0.003125/Wrist_y−0.0375는각2 source
음수pair로거절했다. 다른104q·근위8body·기타초기p/q/목표·PD·route/LA계약은유지했다.
통과조건ON18회와상위2후보OFF6회를완료했다. 1초기준73.660431mm/13.502121°대비
Wrist_x−0.0125는73.268255mm/13.439339°,Elbow_y−0.0015625는73.371659mm/13.452251°,
Elbow_x+0.00625는73.552292mm/13.475650°로소폭작았다.
같은초기각Wrist_x OFF144.267967mm/36.395296°,Elbow_y OFF144.193935mm/36.363384°였다.
기존PI의ON/OFF비교이며새제어를추가하지않았다. Wrist_x−0.0125만다음진단기준으로쓴다.
이는약0.392mm/0.063°차이이며큰drift/속도·LH/어깨contact0·ON포화212sample이남는다.
안정/연주성공은아니다. 초기최소LH query는기준0.440263mm,Wrist_x후보0.167218mm,
Elbow_y후보0.013130mm였다. query근접·contact행/첫끝점은물리적지지인증이아니다.
명시236입력SHA/기준raw5/기간prefix/짝초기상태·명령coverage/제어·물리계약이통과했다.

다음에는새왼손목초기각의fullpose를유지하고초기법칙장력0/1/2N에해당하는
고정절대LA를fresh source/fullpose/LH계약부터비교한다. 이전strap결과는다른왼손목자세로
새결과에승계하지않는다. runtime LA고정/원본법칙tension가변·기존목표/PI/PD/solver/gate유지.
새제어·학습은사용자확인전이다.

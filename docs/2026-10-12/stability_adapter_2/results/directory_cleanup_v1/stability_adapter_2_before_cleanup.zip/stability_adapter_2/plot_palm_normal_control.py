#!/usr/bin/env python3
"""Plot saved palm normal-control traces and reuse stored native camera frames."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from PIL import Image
import numpy as np

from plot_palm_side_feedback import overlay


ROOT = Path('/home/ajou/yigyu/3')
RESULTS = ROOT / 'docs/2026-10-12/stability_adapter_2/results'
PHASE = RESULTS / 'palm_normal_control_v1'
PRIOR = RESULTS / 'palm_side_feedback_v1/native_tracking'
FACET = RESULTS / 'palm_neck_side_v1/facet_distal_search/search.json'
CONDITIONS = (
    ('full_0p15', 'short/full', 'Full 0.15'),
    ('normal_0p15', 'short/normal', 'Normal 0.15'),
    ('normal_0p3', 'cap_0p3/short', 'Normal 0.30'),
    ('normal_0p5', 'cap_0p5/short', 'Normal 0.50'),
)
COLORS = {'full_0p15': '#666666', 'normal_0p15': '#e07a24',
          'normal_0p3': '#1878b8', 'normal_0p5': '#25855a'}


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def make_curves(out, inputs):
    font = Path('/usr/share/fonts/truetype/nanum/NanumGothic.ttf')
    if font.exists():
        plt.rcParams['font.family'] = font_manager.FontProperties(fname=font).get_name()
    plt.rcParams['axes.unicode_minus'] = False
    fig, axes = plt.subplots(2, 2, figsize=(13, 8))
    panels = (
        ('추적점 오차 크기 (mm)', lambda task, trace: np.linalg.norm(task[:, :3], axis=1) * 1000),
        ('법선 대향각 (°)', lambda task, trace: np.rad2deg(np.linalg.norm(task[:, 3:], axis=1) / 0.08)),
        ('기타 위치 오차 크기 (mm)', lambda task, trace: np.asarray([r['position_error_m'] for r in trace]) * 1000),
        ('기타 회전 오차 (°)', lambda task, trace: np.asarray([r['rotation_error_deg'] for r in trace])),
    )
    data = {}
    for label, rel, legend in CONDITIONS:
        trace = read(PHASE / rel / 'trace.json')
        tasks = read(PHASE / rel / 'normal_tasks.json')
        report = read(PHASE / rel / 'report.json')
        if len(trace) != 25 or len(tasks) != 25 or not all(report['checks'].values()):
            raise ValueError(f'{label}: saved-run structure/check mismatch')
        t = np.asarray([r['time_s'] for r in trace], dtype=float)
        task = np.asarray(tasks, dtype=float)
        if task.shape != (25, 6) or not np.isfinite(task).all() or not np.isfinite(t).all():
            raise ValueError(f'{label}: malformed or nonfinite task trace')
        if t[0] != 0 or abs(t[-1] - 0.1) > 1e-12 or np.any(np.diff(t) <= 0):
            raise ValueError(f'{label}: unexpected saved time coverage')
        data[label] = (trace, task, t, legend)
        for paths in (PHASE / rel / 'trace.json', PHASE / rel / 'normal_tasks.json', PHASE / rel / 'report.json'):
            inputs[str(paths.resolve())] = sha(paths)
    for ax, (ylabel, metric) in zip(axes.flat, panels):
        for label, _, _ in CONDITIONS:
            trace, task, t, legend = data[label]
            ax.plot(t, metric(task, trace), color=COLORS[label], marker='o', ms=2.4,
                    lw=1.7, label=legend)
        ax.set_xlabel('저장 시각 (s)')
        ax.set_ylabel(ylabel)
        ax.set_xlim(0, 0.1)
        ax.grid(True, alpha=.25)
        ax.legend(fontsize=8)
    axes[0, 0].set_title('손바닥 source 추적점')
    axes[0, 1].set_title('source 면 방향')
    axes[1, 0].set_title('기타 위치 오차')
    axes[1, 1].set_title('기타 회전 오차')
    fig.suptitle('저장 native trace — 짧은 조건 비교', y=1.01)
    fig.tight_layout()
    path = out / 'palm_normal_control_curves.png'
    fig.savefig(path, dpi=160, bbox_inches='tight')
    plt.close(fig)
    return path


def make_camera(out, inputs):
    facet = read(FACET)
    local_facet = np.asarray(facet['palmar_facet_point_local_m'], dtype=float)
    conditions = (
        ('Prior full 0.15 · 0.1 s', PRIOR, 24),
        ('Normal cap 0.30 · initial', PHASE / 'native_cap_0p3', 0),
        ('Normal cap 0.30 · 0.1 s', PHASE / 'native_cap_0p3', 24),
    )
    rows = []
    for title, directory, step in conditions:
        report = read(directory / 'report.json')
        states = read(directory / 'states.json')
        if len(states) != 25 or states[step]['physics_step'] != step:
            raise ValueError(f'{title}: camera frame has no matching saved pose')
        panels = []
        for view, camera_key in (('front', 'blue_front'), ('side', 'blue_side')):
            key = next(k for k, meta in report['images'].items()
                       if f'blue_{view}_' in k and meta['physics_step'] == step)
            meta = report['images'][key]
            image_path = ROOT / key
            if not image_path.is_file() or sha(image_path) != meta['sha256']:
                raise ValueError(f'{key}: stored camera image hash mismatch')
            camera = report['camera_specs'][camera_key]
            panels.append(overlay(image_path, meta, camera, states[step], local_facet,
                                  f'{title} · {view}'))
            inputs[str(image_path.resolve())] = sha(image_path)
        inputs[str((directory / 'report.json').resolve())] = sha(directory / 'report.json')
        inputs[str((directory / 'states.json').resolve())] = sha(directory / 'states.json')
        rows.append(panels)
    inputs[str(FACET.resolve())] = sha(FACET)
    width, height = rows[0][0].size
    if any(image.size != (width, height) for row in rows for image in row):
        raise ValueError('camera frames do not share a common size')
    canvas = Image.new('RGB', (2 * width, 3 * height), (25, 25, 25))
    for r, pair in enumerate(rows):
        for c, image in enumerate(pair):
            canvas.paste(image, (c * width, r * height))
    path = out / 'palm_normal_control_camera.png'
    canvas.save(path)
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out-dir', type=Path, required=True)
    args = parser.parse_args()
    out = args.out_dir.resolve()
    if out.exists():
        raise FileExistsError(f'output directory already exists: {out}')
    analysis = PHASE / 'analysis.json'
    data = read(analysis)
    if len(data['checks']) != 11 or not all(data['checks'].values()):
        raise ValueError('analysis.json must contain eleven passing checks')
    if data['counts'] != {'native_initializations': 8, 'physics_steps': 123}:
        raise ValueError('unexpected saved experiment counts')
    out.mkdir(parents=True)
    inputs = {str(analysis.resolve()): sha(analysis),
              str(Path(__file__).resolve()): sha(__file__),
              str(Path(__import__('plot_palm_side_feedback').__file__).resolve()):
                  sha(Path(__import__('plot_palm_side_feedback').__file__).resolve())}
    curves = make_curves(out, inputs)
    camera = make_camera(out, inputs)
    outputs = {curves.name: sha(curves), camera.name: sha(camera)}
    manifest = {
        'producer': str(Path(__file__).resolve()),
        'producer_sha256': sha(__file__),
        'inputs_sha256': inputs,
        'outputs_sha256': outputs,
        'scope': 'Saved traces and existing camera frames only; no native initialization or physics step.'
    }
    (out / 'plot_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'out_dir': str(out), 'outputs': outputs,
                      'manifest': str(out / 'plot_manifest.json')}))


if __name__ == '__main__':
    main()

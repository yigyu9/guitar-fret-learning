# 파란 측면 손바닥 목표 보정 소단계

이전 goal turn은 진행이다: 새 초기각/source gap49.807µm 및 실제 첫step 접촉4점,
lambda0/후기소실을 확인해 다음 제어가 필요하다는 증거를 얻었다. 정지 안정 목표는
미완성이다. 사용자 자율 진행 지침에 따라 별도 승인 없이 아래 작은 단위를 수행한다.

## 불변 조건과 제어권

`palm_neck_side_v1/facet_distal`의 초기각과 기타 p/q, 절대 LA1.1018469719600776m,
몸통9/오른팔/손가락 초기목표·기존PD·root/하체 물리고정·self collision ON을 유지한다.
기타 free/gravity/passive strap이며 runtime state 쓰기/강제 부착/인위적 기타힘은 없다.
이번에는 leftarm12만 진단하되 66축 목표 합성 경로와 이후 양팔/손 연주 제어권을 유지한다.
초기 q_play는 저장된 초기목표이며 `q_final=q_play+bias+task_residual`로 합성한다.
최종leftarm target은 C02±.3∩native∩이번초기각±.15rad 안에 둔다. 몸통/오른팔/
손가락/나머지 목표는 불변이다. 최종 연주·학습 구조는 아직 확정하지 않는다.

## 계획 → 구현 → 검증 → 검토

- [x] 1. 새 palm facet 내부 추적점의 initial native FK Jacobian6×12를 측정한다.
  양손 link원점용 이전 Jacobian은 재사용하지 않는다. 초기화-only12축 +0.001rad
  (box의양쪽여유를읽고필요시−방향)와 결합 held-out probe를 별도 환경에서 측정한다.
  작은probe형상은채택자세가아니고물리step0의FK진단임을명시한다. 현재q/worldpose,
  기타/root하체/PD/LA·비대상initialq·조회상태불변을검사한다.
- [x] 2. 같은 새자세에서12축 PD target±.03rad의첫step응답을측정한다. 초기각은
  바꾸지않는다. 각1step의palm 추적점+orientation error를 자유기타의현재blue frame과
  비교해6×12단기응답행렬을만든다. bounded least-squares로startup bias±.15를
  구하고예측과실제1step을대조한다. 초기FK는runtime actuator 응답인증이아니다.
- [x] 3. 동일조건 OFF / bias-only / bias+blue-tracking 각0.1초 비교를한다.
  Task goal은기타actualblue중앙+initial50µm normal gap과 초기palm/guitar상대rotation이다.
  기타복귀 힘을인위적으로가하지않는다. 목표각 task 보정은initial native Jacobian의
  damped inverse(.01m/rad)와KP2/KI4/s,±.15rad/1rad/s이며control60Hz/physics240Hz다.
  최종 clipping+rate saturation의 anti-windup과state불변성을검사한다. 월드초기점만
  유지해기타가움직일때손이떨어지는현상과현재blue추적을구분한다.
- [x] 4. 위치/회전·실제palm contact/lambda·surfacepoint 이탈·몸통drift·보정포화를
  측정하고native/source 조건을구별한다. 첫0.1초에지지가없으면후기연장/손가락추가를
  동시에하지않고다음방향을데이터로정한다. 실제Gym camera 증거와그림설명을
  결과문서에추가하고Luna산출물·독립change-reviewer검수를한다.

코드/설정/메인계획은stability_adapter_2, 결과/로그/문서/이미지는
`docs/2026-10-12/stability_adapter_2/results/palm_side_feedback_v1/`에저장한다.
이전phase의source_final110개/artifact_inventory228개와원본·Aug19를보존한다.
Phase별실패/partial raw/actualinit와step을따로집계하며재실행을숨기지않는다.
이진단의범위/gain/0.1초를최종안정성성공기준으로정의하지않는다.

초기 FK14회/0step과 target-response14회/14step을 완료했다. heldout 위치오차는
약0.683µm로 계약을 통과했다. startup bias는 여러축 ±.15rad에 포화됐고 실제
첫step point오차0.848058→0.379425mm, orientation0.134891→0.106163°지만
접촉4점 lambda는0이다. 기하Jacobian과 단기PD응답행렬은 서로 다른 측정이다.
다음 OFF/bias/bias+tracking 동일0.1초를 비교하며 최종box는 확장하지 않는다.

0.1초3조건의계약이통과했다. OFF는이전native states/trace/contacts를exact재현했고
bias 첫step도검증probe와exact다. source-facet 추적점최대오차71.909699→49.465670→48.323668mm로
감소했지만기타body states·p/q·오차곡선은세조건exact(전체trace는route/torso field차이)이며max5.107730mm/0.969008°다.
세조건모두첫step4palm rows lambda0,step2~24접촉0다. 지지/정지안정성성공이아니다.
Tracking의실제Gym camera초기/0.1초재현1회를추가했고same raw5배열을확인했다.

검수에서bias 계약이참조한response/columns.json의productionSHA누락을확인했다.
기존raw/producer를보존하고후속runner는columns를시작/끝hash에포함한다.
교정input은current byte또는exact역사helper 사본으로연결하며, FK뒤추가한
controller class를제외한measurement helper AST가동일함을확인한다. 새preflight만
별도로실행한다. 후처리검증을과거production input불변증명으로소급하지않는다.

## 이번 결과와 다음 제한된 실험

startup bias의7축이±.15rad에포화됐다. tracking도6회의control update 중후기4회에는
6축의적분이제한됐다. 현재범위에서추적오차가약48mm남고첫접촉4행의raw lambda0·후기접촉없음이므로0.5초연장이나
손가락grip을추가하지않는다. 다음에는초기각/C02초기box는유지한채PD목표보정만
initial±.3rad,필요시±.5rad∩native까지별도1step검증한다. 이는과거finger단계에서
다뤘던runtime목표범위이며이번±.15진단과구별한다. 작은±.03응답행렬의외삽이므로
실제첫step오차/접촉/기타변화가예측과맞는지읽은뒤짧은rollout여부를결정한다.
실제지원이생기면runtime normal gap50µm→0의접촉추적과그다음손가락제어를
따로비교한다. 시작각의겹침금지와몸통최소움직임조건을완화하지않는다.
새initialroute1.080474113m에비해현재LA는약21.373mm slack이므로스트랩후보도
그새자세에서다시측정할필요가있다. 이번에는LA를바꾸지않아손제어효과를분리했다.

저장 raw coverage/finite 및 camera 재현을 포함한14검사를 통과했다. 접촉·기타
변화는 성공을 강제하는 gate가 아닌 관측값으로 분리했다. 독립검수의 미해결 지적은
없으며 결과/실제이미지/검수는 해당phase README·review.md에 저장했다.

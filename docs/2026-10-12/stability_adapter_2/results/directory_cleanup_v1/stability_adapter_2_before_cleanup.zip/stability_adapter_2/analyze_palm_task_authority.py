"""Analyze saved local palm position mobility within the existing correction box."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from .compare_palm_fk_coordinates import left_expmap_tangent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime-dir', type=Path, required=True)
    parser.add_argument('--reference-run', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise FileExistsError('preserve prior authority analysis')
    report_path = args.runtime_dir / 'report.json'
    report = json.loads(report_path.read_text())
    if not all(report['checks'].values()) or not all(sha(p) == h for p, h in report['input_sha256'].items()):
        raise ValueError('runtime contracts or input SHA differ')
    paths = [report_path] + [args.runtime_dir / (n + '.json') for n in ('queries', 'states')]
    paths += [args.reference_run / 'report.json', Path(__file__).resolve(), Path(__file__).with_name('compare_palm_fk_coordinates.py')]
    queries, states, reference = (json.loads(p.read_text()) for p in paths[1:4])
    columns = [i for i in reference['arm_indices'] if reference['human_joint_names'][i].startswith('L_')]
    arm_columns = [reference['arm_indices'].index(i) for i in columns]
    play = np.array(reference['initial_joint_targets_rad'])[columns]
    lower = np.maximum(-.15, np.array(reference['diagnostic_lower_rad'])[arm_columns] - play)
    upper = np.minimum(.15, np.array(reference['diagnostic_upper_rad'])[arm_columns] - play)
    goal = np.array(queries[0]['palms']['L']['source_center_world_m'])
    records = []
    for query, state in zip(queries, states):
        palm = query['palms']['L']
        actual = np.array([d['pos'] for d in state['human_dof_states']])[columns]
        jac = np.array(palm['refreshed_J'])[:, columns]
        for k in range(0, 12, 3):
            jac[:, k:k+3] = jac[:, k:k+3] @ left_expmap_tangent(actual[k:k+3])
        center = np.array(palm['source_center_world_m'])
        x, y, z = center - np.array(palm['COM_world_m'])
        cross = np.array([[0, -z, y], [z, 0, -x], [-y, x, 0]])
        a = jac[:3] - cross @ jac[3:]
        base = a @ (play - actual)
        lo = base + np.where(a >= 0, a * lower, a * upper).sum(axis=1)
        hi = base + np.where(a >= 0, a * upper, a * lower).sum(axis=1)
        needed = goal - center
        records.append({'physics_step': query['physics_step'], 'time_s': query['time_s'],
            'singular_values_m_per_rad': np.linalg.svd(a, compute_uv=False).tolist(),
            'required_displacement_m': needed.tolist(), 'axis_interval_lower_m': lo.tolist(),
            'axis_interval_upper_m': hi.tolist(), 'required_within_each_axis_interval': ((needed >= lo) & (needed <= hi)).tolist()})
    inputs = dict(report['input_sha256'])
    inputs.update({str(p.resolve()): sha(p) for p in paths})
    result = {'scope': 'saved local linear independent-axis mobility; no new controller or joint reachability/FK/stability certificate',
        'checks': {'25_aligned_samples': len(records) == 25 and [q['physics_step'] for q in queries] == [s['physics_step'] for s in states],
            'finite_records': bool(np.isfinite([r['singular_values_m_per_rad'] + r['required_displacement_m'] + r['axis_interval_lower_m'] + r['axis_interval_upper_m'] for r in records]).all()),
            'existing_delta_box_contains_zero': bool(((lower <= 0) & (upper >= 0)).all())},
        'left_columns': columns, 'left_joint_names': [reference['human_joint_names'][i] for i in columns],
        'delta_lower_rad': lower.tolist(), 'delta_upper_rad': upper.tolist(), 'records': records, 'input_sha256': inputs}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'checks': result['checks'], 'last_sample': records[-1], 'input_hashes': len(inputs)}, indent=2))
    if not all(result['checks'].values()):
        raise SystemExit(1)


if __name__ == '__main__':
    main()

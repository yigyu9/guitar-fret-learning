# 오른어깨 접촉 전후의 원본 형상 관측

2026-10-06. right_support_v1 기준과 candidate_01의 저장 상태만 읽는다.
새 제어·초기각·스트랩 변경이나 native 실행을 추가하지 않는다.
원본 형상의 unsigned hull 거리는 물리 접촉/관통 깊이 인증이 아니다.

- [x] 1. 시작, 첫 접촉 직전(step2), 첫 어깨 접촉(step3), 다음 접촉(step4), 종료(step24)의
  R_Thorax/Shoulder/Elbow/Wrist 및 RH:palm–기타 body/neck 거리를 기록한다.
  부위에 여러 활성 source geom이 있으면 모든 조합을 검사하고 최솟값을 쓴다.
  기존20mm cutoff signed query와 unsigned hull witness를 구별한다.
- [x] 2. 기준/후보 초기 RH 거리가 기존 결과를 재현하는지, 부위 형상 누락이 없는지,
  QP 성공·feasibility와 읽은 원자료/코드/자산 SHA 보존을 확인한다.
- [x] 3. Sol이 의미와 다음 초기각 관측 방향을 판단했다. Luna가 거리·witness 그림과
  설명을 별도 결과 폴더 및 누적17절에 남기고 별도 change-reviewer가 검수한다.

손의 근접만을 최적화한 후보에서 어깨가 함께 기타에 접근했는지 확인하는 것이 목적이다.
source와 native가 다르면 차이를 보고하며 source 값으로 cooked clearance를 대신하지 않는다.
이 관측으로 새 hard gate·gain·Jacobian 위치 보정·학습을 적용하지 않는다.
구현은 stability_adapter_2, 결과는
docs/2026-10-12/stability_adapter_2/results/right_shoulder_audit_v1에 둔다.

## 실측 결과

100개 부위/시점 query의 계약·QP feasibility·기존 RH 초기값 재현을 확인했다.
기준의 초기 어깨–body unsigned hull 거리는35.395mm, 후보는0.787mm였다.
손바닥 거리100.306→3.230mm의 감소와 함께 어깨도 매우 가까워졌다.
candidate_01 저장 step2에는 hull 거리 약0과 backend signed gap −4.092mm가
관찰됐다. 접촉 step3의 raw initialOverlap은 이 직전 상태의 signed gap과
약2.04e−8m 차이였고, step4도 저장 step3 query와 약6.71e−9m 차이였다.
동일 step의 실행 후 source 상태와 직접 대조하면 다른 값을 볼 수 있다.
이 두 행의 관측을 전체 solver 단계나 모든 cooked/source 형상의 일치로 일반화하지 않는다.
다음 초기각 후보는 손 근접과 어깨/상완 접근을 함께 관측한다. 새 hard gate는 추가하지 않는다.

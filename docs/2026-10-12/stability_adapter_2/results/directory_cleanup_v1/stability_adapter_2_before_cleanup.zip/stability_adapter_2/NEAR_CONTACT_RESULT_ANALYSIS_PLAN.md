# 근접 세 면 초기 배치 결과 분석·산출물 계획

이번 단위는 wider33 source12후보, support-plane source3후보와 별도 no-overlap native두조건을 구분해서 정리한다. 기존 source거절사유와 native진단 admission은 유지하며 겹침 없음만으로 grip성공을 선언하지 않는다.

1. 새 native각조건의 실제초기값·1200step·151frame/두카메라와 제출목표300update, root/하체 고정, 기타p/q오차·passive법칙을 원자료로 재계산한다. 손가락21만 두조건간 목표가 다르고 initial81q/G/LA/PD/나머지목표는 같은지 확인한다.
2. 각손body–기타 접촉행/raw lambda 양의 고유step·마지막step을 집계한다. body명/rawlambda는 면별지지·뉴턴힘·관통인증이 아니다. 최초/종료 source거리와 actual영상 설명도 구분한다.
3. 실제Gym 초기/후기PNG와 두조건 영상 및 이동/회전 곡선·source실패 요약을 새phase에 저장한다. 불리한 결과·제약위반도 포함한다. 메인PLAN/README와 누적보고서는 추가로 기록한다.
4. 원본27phase inventory/legacy87 stat/Aug19 SHA/누적§1..87을 대조하고 새 source·실행·분석·산출물을 봉인한다. 독립검수는 도구thread limit으로 현재 불가하며 root검증과 구분한다. Luna 산출물 도구도 같은 오류면 root가 이번 문서·그림을 만들고 실제 담당을 명시한다.

- [ ] 새원자료·비교조건/영상coverage 검증
- [ ] 그림·영상·한국어설명/실제줄 색인
- [ ] 기존보존/새봉인·후속방향 기록

완료된소스·leaf계획·로그·출력을 덮어쓰지 않는다. 결과분석 오류나 재시도는 별도변형을 보존하고 진행한다. 사용자 자율진행 지침에 따라 추가 승인 질문을 하지 않는다.

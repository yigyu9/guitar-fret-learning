# 새 왼손목 자세의 고정 초기 스트랩 길이 비교

2026-10-07. left_palm_boundary_v1/l_wrist_x_minus0125를다음진단초기각기준으로쓴다.
기존기준대비왼손목X−0.0125rad의1초ON은73.268255mm/13.439339°지만안정성공은아니다.
같은fullpose에서초기원본법칙장력0/1/2N에해당하는절대LA만비교한다.
LA=초기route−T/6000,초기vel0이며runtime LA고정/장력은원본법칙에따라변한다.
다른왼손목초기각의이전strap결과를승계하지않는다.

- [x] 1. 기준길이와1/2N길이를기존 audit_strap_initial_inputs.py로fresh검사한다.
  fullq/nativebody/G/goal/PD/route/main66/noSteps·source 음수pair0/LH위쪽반구·국소넥아래유지.
  기존0–5N허용길이안이며거절조건은실행하지않는다. source는cookedclearance/지지인증아니다.
- [x] 2. 통과조건의0.1초기존PI ON을실행한다. 새어깨접촉없는조건만0.5/1초ON으로
  직접비교하며짧은성능으로거르지않는다(최대9ON).
- [x] 3. 1초최대이동·회전모두기준보다작은길이최대2조건만OFF0.1/0.5/1초비교한다.
  개선없으면0N길이유지. 기존 compare_strap_initial_trials.py로계약/prefix/명령coverage/SHA검증.
  frozencomparer의참조layout group/wrist_minus0050는새read-onlysymlink로
  실제left_palm_boundary_v1/group/l_wrist_x_minus0125를가리킨다. 이름은호환alias이며
  실제원본/각도·resolve경로는manifest에기록한다. 기존기록/도구는수정하지않는다.
- [x] 4. Luna가표·저장trace이미지·설명을누적33절에추가하고독립검수한다.
  절대경로·실제줄·입력/명령/로그/원자료·보존본/검증을남긴다.

root고정·기타자유/+5mm목표p/q·몸통9/손가락42/C02하체PD목표유지.
주요66연결·팔24 PI±0.15rad/60Hz·기존PD/gain/solver·source/LHgate유지.
고정·강제부착·runtime pose덮어쓰기·동적strap·새gate/제어/학습은없다.
기타p/q feedback은사용자확인전이다. 실제각·속도·접촉·포화를측정한다.
contact수·첫끝점은힘/인과/깊이/연속지지인증이아니다. 성공기준은임의로정하지않는다.

입력: stability_adapter_2/trials/left_wrist_strap_v1.
결과: docs/2026-10-12/stability_adapter_2/results/left_wrist_strap_v1.

## 실행 결과와 다음 방향

초기3조건은fullq/body/G/goal/PD/route·source/LH계약을모두통과했다.
LA0/1/2N은각1.1010801317960974/1.1009134651294308/1.1007467984627641m이다.
ON0.1/0.5/1초9회를완료했다. 1초기준73.268255mm/13.439339°대비
1N118.622890mm/28.826878°,2N120.835674mm/30.129771°로양오차가컸다.
새길이를채택하지않고0N LA를유지하며OFF를추가하지않는다.
1초모두LH/어깨contact0·ON포화212samples,종료선속도0.293048–0.464767m/s,
각속도1.191623–2.870732rad/s가남아안정/연주성공이아니다.
이초기장력은시간내내일정한힘이아니다. 실제최대적용장력은15.035908/15.452612/16.020121N이다.
actual arm scalar-limit위반0.030297–0.030300°와최종targetbounds통과를구분한다.
명시139입력SHA/기준raw5/기간prefix/명령coverage/기존제어·물리계약이통과했다.
compatibility symlink의이름은이전pose를뜻하지않고새왼손목원본raw를직접resolve한다.

다음은현재왼손목각/0N LA/기존PI를유지한3초자유기타정지진단이다.
이전1초raw prefix를대조하고후기p/q·속도·접촉·포화를측정해새접촉/평형또는이탈을관찰한다.
관측기간연장이며WAIT필수과정이나새성공기준이아니다. 기존초기각범위·목표/gate/제어/PD/solver
유지,기타고정·강제부착·pose덮어쓰기·기타p/q feedback·학습추가는없다.

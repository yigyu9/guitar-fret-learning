"""Verify one saved 3 s ON run against its prior 1 s prefix; no simulation."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--reference-run', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise FileExistsError('preserve prior comparison')
    names = ('report', 'trace', 'states', 'contacts', 'controls', 'leg_torques')
    raw = {n: read(args.run / (n + '.json')) for n in names}
    prior = {n: read(args.reference_run / (n + '.json')) for n in names}
    report, trace, states, controls = [raw[n] for n in ('report', 'trace', 'states', 'controls')]
    base = prior['report']
    audit_path = args.reference_run.parents[1] / 'strap_inputs.json'
    audit = read(audit_path)
    matched = [r for r in audit['records'] if r['settings'] == report['initial_settings']]
    q = np.array([[d['pos'] for d in s['human_dof_states']] for s in states])
    initial = np.array(report['initial_joint_targets_rad'])
    arm = report['arm_indices']
    targets = np.array([c['final_arm_targets_rad'] for c in controls])
    interval = report['physics_hz'] // report['control_hz']
    checks = {'native_checks': all(report['checks'].values()),
        'three_second_ON': report['mode'] == 'on' and report['physics_steps'] == 3 * report['physics_hz'],
        'accepted_prior_initial_recipe': bool(matched) and all(r['accepted_for_diagnostic'] and all(r['checks'].values()) for r in matched),
        'full_initial_state_exact': states[0] == prior['states'][0],
        'all_prior_raw_prefixes_exact': all(raw[n][:len(prior[n])] == prior[n] for n in names if n != 'report'),
        'initial_q_and_zero_velocity': np.array_equal(q[0], initial) and all(d['vel'] == 0 for d in states[0]['human_dof_states']),
        'root_fixed_all_samples': all(s['human_body_states'][0] == states[0]['human_body_states'][0] for s in states),
        'sample_counts': all(len(raw[n]) == report['physics_steps'] + (n in ('trace', 'states', 'leg_torques')) for n in names if n != 'report'),
        'exact_control_schedule': all(c['updated_before_step'] == (i % interval == 0) and c['physics_step'] == i + 1 for i, c in enumerate(controls)),
        'fixed_LA': all(s['strap_rest_length_m'] == report['absolute_rest_length_m'] for s in trace),
        'target_bounds': bool(((targets >= np.array(report['diagnostic_lower_rad']) - 2e-7) & (targets <= np.array(report['diagnostic_upper_rad']) + 2e-7)).all() and (np.abs(targets - initial[arm]) <= .15 + 2e-7).all()),
        'finite_dofs_and_targets': bool(np.isfinite(q).all() and np.isfinite(targets).all())}
    for key in ('scope', 'mode', 'initial_settings', 'human_joint_names', 'human_body_names', 'guitar_body_names', 'initial_joint_targets_rad', 'arm_indices', 'diagnostic_lower_rad', 'diagnostic_upper_rad', 'native_joint_lower_rad', 'native_joint_upper_rad', 'native_pd_kp', 'native_pd_kd', 'native_drive_modes', 'native_effort_caps_nm', 'physics_parameters', 'physics_hz', 'control_hz', 'guitar_goal_position_m', 'guitar_goal_quaternion_xyzw', 'absolute_rest_length_m', 'initial_route_length_m', 'controller'):
        checks[key + '_unchanged'] = report[key] == base[key]
    counts, steps = {}, {}
    for sample in raw['contacts']:
        for contact in sample['contacts']:
            pair = (contact['body0_name'], contact['body1_name'])
            if any(n.startswith('guitar/') for n in pair):
                for n in pair:
                    if n.startswith('human/'):
                        counts[n] = counts.get(n, 0) + 1
                        steps.setdefault(n, set()).add(sample['physics_step'])
    palm_up = []
    for state in states:
        body = state['human_body_states']
        p = {n: np.array([body[report['human_body_names'].index(n)]['pose']['p'][a] for a in ('x', 'y', 'z')]) for n in ('L_Wrist', 'LH:middle1', 'LH:index1', 'LH:pinky1')}
        normal = np.cross(p['LH:middle1'] - p['L_Wrist'], p['LH:index1'] - p['LH:pinky1'])
        length = float(np.linalg.norm(normal))
        if length <= 1e-12:
            raise ValueError('undefined landmark palm-normal proxy')
        palm_up.append(float(normal[2] / length))
    row = {'run': str(args.run.resolve()), 'group': 'quiescent_3s', 'name': 'reference', 'mode': 'on', 'duration_s': trace[-1]['time_s'], 'checks': checks,
        'max_position_error_m': max(s['position_error_m'] for s in trace), 'max_rotation_error_deg': max(s['rotation_error_deg'] for s in trace),
        'end_position_error_m': trace[-1]['position_error_m'], 'end_rotation_error_deg': trace[-1]['rotation_error_deg'],
        'end_linear_speed_mps': trace[-1]['linear_speed_mps'], 'end_angular_speed_rad_s': trace[-1]['angular_speed_rad_s'],
        'max_applied_tension_n': max(s['last_applied_tension_n'] for s in trace[1:]),
        'max_arm_raw_drift_deg': float(np.rad2deg(np.abs(q[:, arm] - initial[arm])).max()),
        'max_arm_scalar_limit_violation_deg': float(np.rad2deg(np.maximum(np.maximum(np.array(report['native_joint_lower_rad'])[arm] - q[:, arm], q[:, arm] - np.array(report['native_joint_upper_rad'])[arm]), 0)).max()),
        'min_left_palm_up_dot': min(palm_up), 'saturated_physics_samples': sum(any(c['saturated']) for c in controls),
        'contact_rows_by_human_body': counts, 'contact_physics_samples_by_human_body': {n: len(v) for n, v in steps.items()},
        'contact_first_last_step_by_human_body': {n: [min(v), max(v)] for n, v in steps.items()}}
    paths = [run / (n + '.json') for run in (args.run, args.reference_run) for n in names]
    paths += [audit_path, Path(__file__).resolve()] + [Path(p) for p in report['source_sha256']] + [Path(p) for p in audit['source_sha256']]
    checks['runtime_and_audit_sources_current'] = all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for mapping in (report['source_sha256'], audit['source_sha256']) for p, h in mapping.items())
    output = {'scope': 'Unchanged joint PI, longer observation only; no WAIT requirement or stability/playing certificate', 'checks': checks, 'rows': [row],
        'late_1_to_3s': {key: max(s[field] for s in trace if s['time_s'] >= 1) for key, field in (('max_position_error_m', 'position_error_m'), ('max_rotation_error_deg', 'rotation_error_deg'))},
        'semantics': 'contact counts/endpoints are not force/depth/continuity; held-sample saturation; landmark palm proxy has unverified anatomical sign',
        'input_sha256': {str(p.resolve()): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
    args.out.write_text(json.dumps(output, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'checks': checks, 'p_m': row['max_position_error_m'], 'q_deg': row['max_rotation_error_deg']}, indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == '__main__':
    main()

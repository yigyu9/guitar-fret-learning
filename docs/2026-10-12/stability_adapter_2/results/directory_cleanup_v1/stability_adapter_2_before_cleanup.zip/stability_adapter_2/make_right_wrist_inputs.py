"""Seven fixed initial Wrist_x recipes; unchanged source gates and no rollout."""
import argparse
import hashlib
import json
from pathlib import Path

from .environment import InitialEnvironment, np, gymapi
from .initial_overlap import build_probe, query_pairs
from .pose_strap_inputs import pose_metrics, input_hashes
from .search_hand_support import palm_neck_gap


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-settings',type=Path,required=True)
    parser.add_argument('--settings-dir',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args = parser.parse_args()
    args.settings_dir.mkdir(parents=True,exist_ok=True)
    if any(args.settings_dir.iterdir()) or args.out.exists():
        raise FileExistsError('preserve prior inputs and audit')
    c02_path = Path(__file__).with_name('trials')/'lower_initial_pose_c02.json'
    hashes = input_hashes(args.base_settings)
    for p in (c02_path,Path(__file__).resolve(),Path(__file__).with_name('search_hand_support.py')):
        hashes[str(p.resolve())] = hashlib.sha256(p.read_bytes()).hexdigest()
    c02 = InitialEnvironment(json.loads(c02_path.read_text()))
    try:
        bounds,names = c02.initial_q.copy(),list(c02.names)
    finally:
        c02.close()
    common = json.loads(args.base_settings.read_text())
    env = InitialEnvironment(common)
    try:
        if list(env.names)!=names:
            raise ValueError('C02 joint layout differs')
        base,lower,upper = env.initial_q.copy(),env.lower.copy(),env.upper.copy()
        joint = names.index('R_Wrist_x')
        other = [i for i in range(len(names)) if i!=joint]
        proximal = [i for i,n in enumerate(env.human_bodies) if n!='R_Wrist' and not n.startswith('RH:')]
        human,guitar,goal = env.bodies(env.human),env.bodies(env.guitar),env.goal_position.copy()
        props = env.gym.get_actor_dof_properties(env.env,env.human).copy()
        route = env.initial_route_length
    finally:
        env.close()
    records = []
    for name,delta in [('reference',0.),('minus0100',-.01),('minus0050',-.005),('minus0025',-.0025),('plus0025',.0025),('plus0050',.005),('plus0100',.01)]:
        angles = dict(common['joint_angles_rad'])
        angles['R_Wrist_x'] = float(base[joint])+delta
        env = InitialEnvironment(dict(common,joint_angles_rad=angles))
        try:
            h,g = env.bodies(env.human),env.bodies(env.guitar)
            q = env.gym.get_actor_dof_states(env.env,env.human,gymapi.STATE_ALL).copy()
            probe = build_probe(env)
            geometry,hand = query_pairs(*probe),pose_metrics(env,probe)
            checks = {'only_wrist_x_initial_target_changed':bool(np.array_equal(env.initial_q[other],base[other])),
                'C02_and_model_initial_bounds':bool((np.abs(env.initial_q-bounds)<=.3+2e-7).all() and ((env.initial_q>=lower-2e-7)&(env.initial_q<=upper+2e-7)).all()),
                'unchanged_proximal_body_states':bool(np.array_equal(h[proximal],human[proximal])),
                'initial_dofs_match_target':bool(np.array_equal(q['pos'],env.initial_q) and (q['vel']==0).all()),
                'guitar_initial_states_and_goal_unchanged':bool(np.array_equal(g,guitar) and np.array_equal(env.goal_position,goal)),
                'native_pd_unchanged':bool(np.array_equal(props,env.gym.get_actor_dof_properties(env.env,env.human))),
                'absolute_length_and_route_unchanged':env.rest_length==common['strap_rest_length_m'] and env.initial_route_length==route,
                'read_only_no_steps':bool(env.steps==0 and np.array_equal(h,env.bodies(env.human)) and np.array_equal(g,env.bodies(env.guitar)) and np.array_equal(q,env.gym.get_actor_dof_states(env.env,env.human,gymapi.STATE_ALL)))}
            if not all(checks.values()):raise AssertionError(checks)
            accepted = geometry['negative_gap_pair_count']==0 and hand['palm_normal_valid'] and hand['palm_up_dot']>=0 and hand['neck_projection_in_range'] and hand['palm_height_vs_local_lower_m']<=0
            records.append({'id':name,'nominal_wrist_x_delta_rad':delta,'actual_wrist_x_delta_rad':float(env.initial_q[joint]-base[joint]),
                'settings':env.initial_settings,'checks':checks,'geometry':geometry,'hand':hand,
                'palm_body_hulls':palm_neck_gap(probe,'RH:palm','G:body'),'accepted_for_diagnostic':bool(accepted)})
            if accepted:(args.settings_dir/(name+'.json')).write_text(json.dumps(env.initial_settings,indent=2)+'\n')
        finally:
            env.close()
    output = {'scope':'seven Wrist_x-only initial recipes in approved C02 bounds; no clearance/support/stability certificate',
        'checks':{'all_initial_contracts':all(all(r['checks'].values()) for r in records),'sources_unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==s for p,s in hashes.items())},
        'source_sha256':hashes,'records':records}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'checks':output['checks'],'recipes':[{'id':r['id'],'accepted':r['accepted_for_diagnostic'],'rh_gap_mm':r['palm_body_hulls']['source_hull_distance_m']*1000} for r in records]},indent=2))
    if not all(output['checks'].values()):raise SystemExit(1)


if __name__=='__main__':main()

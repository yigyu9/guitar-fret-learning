"""Check named initial-angle JSON candidates in the approved 24-arm box; no rollout."""
import argparse
import hashlib
import json
from pathlib import Path

from .environment import InitialEnvironment, np, gymapi
from .initial_overlap import build_probe, query_pairs
from .pose_strap_inputs import pose_metrics, input_hashes
from .search_hand_support import palm_neck_gap


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-settings',type=Path,required=True)
    parser.add_argument('--settings-dir',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args = parser.parse_args()
    if args.out.exists():raise FileExistsError('preserve prior audit')
    candidates = sorted(args.settings_dir.glob('*.json'))
    if not candidates:raise ValueError('no initial settings inputs')
    c02_path = Path(__file__).with_name('trials')/'lower_initial_pose_c02.json'
    hashes = input_hashes(args.base_settings)
    for p in candidates+[c02_path,Path(__file__).resolve(),Path(__file__).with_name('search_hand_support.py')]:
        hashes[str(p.resolve())] = hashlib.sha256(p.read_bytes()).hexdigest()
    c02 = InitialEnvironment(json.loads(c02_path.read_text()))
    try:
        bounds,names = c02.initial_q.copy(),list(c02.names)
    finally:
        c02.close()
    env = InitialEnvironment(json.loads(args.base_settings.read_text()))
    try:
        if list(env.names)!=names:raise ValueError('C02 joint layout differs')
        base,lower,upper = env.initial_q.copy(),env.lower.copy(),env.upper.copy()
        arm = [i for i in env.main_indices if not names[i].startswith(('LH:','RH:'))]
        other = [i for i in range(len(names)) if i not in arm]
        fixed = [i for i,n in enumerate(env.human_bodies) if n in ('Pelvis','Torso','Spine','Chest','L_Thorax','R_Thorax','L_Shoulder','R_Shoulder')]
        human,guitar,goal = env.bodies(env.human),env.bodies(env.guitar),env.goal_position.copy()
        props = env.gym.get_actor_dof_properties(env.env,env.human).copy()
        route,rest = env.initial_route_length,env.rest_length
    finally:
        env.close()
    records = []
    for path in candidates:
        env = InitialEnvironment(json.loads(path.read_text()))
        try:
            h,g = env.bodies(env.human),env.bodies(env.guitar)
            q = env.gym.get_actor_dof_states(env.env,env.human,gymapi.STATE_ALL).copy()
            probe = build_probe(env)
            geometry,hand = query_pairs(*probe),pose_metrics(env,probe)
            checks = {'only_approved_arm_initial_targets_changed':bool(np.array_equal(env.initial_q[other],base[other])),
                'C02_and_model_initial_bounds':bool((np.abs(env.initial_q-bounds)<=.3+2e-7).all() and ((env.initial_q>=lower-2e-7)&(env.initial_q<=upper+2e-7)).all()),
                'fixed_proximal_body_states':bool(np.array_equal(h[fixed],human[fixed])),
                'initial_dofs_match_target':bool(np.array_equal(q['pos'],env.initial_q) and (q['vel']==0).all()),
                'guitar_initial_states_and_goal_unchanged':bool(np.array_equal(g,guitar) and np.array_equal(env.goal_position,goal)),
                'native_pd_unchanged':bool(np.array_equal(props,env.gym.get_actor_dof_properties(env.env,env.human))),
                'absolute_length_and_route_unchanged':env.rest_length==rest and env.initial_route_length==route,
                'main66_arm24_layout':len(env.main_indices)==66 and len(arm)==24,
                'read_only_no_steps':bool(env.steps==0 and np.array_equal(h,env.bodies(env.human)) and np.array_equal(g,env.bodies(env.guitar)) and np.array_equal(q,env.gym.get_actor_dof_states(env.env,env.human,gymapi.STATE_ALL)))}
            if not all(checks.values()):raise AssertionError(checks)
            accepted = geometry['negative_gap_pair_count']==0 and hand['palm_normal_valid'] and hand['palm_up_dot']>=0 and hand['neck_projection_in_range'] and hand['palm_height_vs_local_lower_m']<=0
            records.append({'id':path.stem,'input_path':str(path.resolve()),'settings':env.initial_settings,
                'initial_joint_targets_rad':env.initial_q.astype(float).tolist(),
                'changed_initial_targets_rad':{names[i]:float(env.initial_q[i]-base[i]) for i in arm if env.initial_q[i]!=base[i]},
                'checks':checks,'geometry':geometry,'hand':hand,'palm_body_hulls':palm_neck_gap(probe,'RH:palm','G:body'),'accepted_for_diagnostic':bool(accepted)})
        finally:
            env.close()
    output = {'scope':'read-only initial input audit; keeps proximal body/route; no cooked clearance, support or stability certificate',
        'base_settings':str(args.base_settings.resolve()),'joint_names':names,
        'checks':{'all_initial_contracts':all(all(r['checks'].values()) for r in records),'sources_unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==s for p,s in hashes.items())},
        'source_sha256':hashes,'records':records}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'checks':output['checks'],'recipes':[{'id':r['id'],'accepted':r['accepted_for_diagnostic'],'changes':r['changed_initial_targets_rad'],'rh_gap_mm':r['palm_body_hulls']['source_hull_distance_m']*1000} for r in records]},indent=2))
    if not all(output['checks'].values()):raise SystemExit(1)


if __name__=='__main__':main()

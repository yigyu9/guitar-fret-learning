"""Summarize the read-only geometry screen without rerunning its queries."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "docs/2026-10-12/stability_adapter_2/results"
PHASE = BASE / "guitar_pose_geometry_screen_v1"
SCREEN = PHASE / "screen.json"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    output = PHASE / "analysis.json"
    if output.exists():
        raise FileExistsError(f"preserve existing analysis: {output}")
    screen = read(SCREEN)
    comparison_paths = [Path(row["candidate_path"]).with_name("comparison.json")
                        for row in screen["rows"]]
    inputs = [Path(__file__).resolve(), SCREEN, *comparison_paths]
    before = {str(path.resolve()): sha(path) for path in inputs}
    rows = []
    for row, path in zip(screen["rows"], comparison_paths):
        comparison = read(path)
        overlaps = row["source_human_guitar_intersections"]
        left = row["source_left_hand_guitar_intersections"]
        rows.append({
            "candidate": row["candidate"],
            "case_id": comparison["id"],
            "body_center_W_m": comparison["body_center_W_m"],
            "translation_W_m": comparison["translation_W_m"],
            "rotation_delta_deg": comparison["rotation_delta_deg"],
            "neck_elevation_deg": comparison["neck_elevation_deg"],
            "neck_audience_yaw_deg": comparison["neck_audience_yaw_deg"],
            "front_normal_elevation_deg": comparison[
                "front_normal_elevation_deg"],
            "human_guitar_intersection_pairs": len(overlaps),
            "left_hand_guitar_intersection_pairs": len(left),
            "minimum_left_hand_signed_gap_mm": min(
                (value["signed_gap_m"] * 1000 for value in
                 row["source_left_hand_guitar_pairs_within_20mm"]),
                default=None),
            "minimum_human_guitar_signed_gap_mm": min(
                (value["signed_gap_m"] * 1000 for value in overlaps),
                default=None),
            "full_geometry_clear": row["source_geometry_clear"],
        })
    left_clear = [row["case_id"] for row in rows
                  if row["left_hand_guitar_intersection_pairs"] == 0]
    full_clear = [row["case_id"] for row in rows if row["full_geometry_clear"]]
    by_least_left_overlap = sorted(
        rows, key=lambda row: (row["left_hand_guitar_intersection_pairs"],
                               -(row["minimum_left_hand_signed_gap_mm"]
                                 if row["minimum_left_hand_signed_gap_mm"]
                                 is not None else 1000.0)))
    after = {path: sha(path) for path in before}
    if before != after:
        raise AssertionError("an analysis input changed during summarization")
    result = {
        "checks": {
            "all_30_candidates_have_semantic_labels": len(rows) == 30,
            "screen_and_comparison_files_unchanged": before == after,
            "no_native_or_physics_replay": True,
        },
        "input_sha256_before": before,
        "input_sha256_after": after,
        "candidate_count": len(rows),
        "left_hand_clear_candidate_count": len(left_clear),
        "left_hand_clear_candidates": left_clear,
        "full_geometry_clear_candidate_count": len(full_clear),
        "full_geometry_clear_candidates": full_clear,
        "least_left_overlap_candidates": by_least_left_overlap[:6],
        "rows": rows,
        "native_initializations": 0,
        "physics_steps": 0,
        "actor_inference_calls": 0,
        "training_updates": 0,
        "scope": "summary of the saved MuJoCo source signed-gap screen; negative signed gap is not a calibrated PhysX penetration depth and no pose is selected or adopted",
    }
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2,
                                 allow_nan=False) + "\n")
    print(json.dumps({"checks": result["checks"],
                      "left_hand_clear_candidates": left_clear,
                      "full_geometry_clear_candidates": full_clear,
                      "least_left_overlap_candidates": [
                          {k: row[k] for k in ("candidate", "case_id",
                                               "left_hand_guitar_intersection_pairs",
                                               "minimum_left_hand_signed_gap_mm",
                                               "human_guitar_intersection_pairs")}
                          for row in by_least_left_overlap[:6]]},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

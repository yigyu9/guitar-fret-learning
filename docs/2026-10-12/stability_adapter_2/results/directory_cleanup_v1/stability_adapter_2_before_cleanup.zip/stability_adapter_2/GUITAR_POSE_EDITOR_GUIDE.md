# 기타 초기 배치 직접 고르기

Isaac Gym 창에서 기타를 움직여 자연스러워 보이는 배치를 여러 개 저장하는 도구다. humanoid의 초기 관절각과 하체 고정은 유지한다. 저장한 후보가 이후 관절 자세·연주 범위를 설계할 기준이다. 기존 자동 탐색과 학습은 재개하지 않는다.

그래픽 데스크톱의 VS Code 터미널에서 실행한다. 런처가 기존 rl38 환경을 사용한다.

```bash
bash /home/ajou/yigyu/3/stability_adapter_2/open_guitar_pose_editor.sh
```

스트랩 없이 시작하려면 다음과 같이 실행한다. 기본은 원본 고정 길이 스트랩 ON이다.

```bash
bash /home/ajou/yigyu/3/stability_adapter_2/open_guitar_pose_editor.sh --no-strap
```

| 키 | 동작 |
|---|---|
| F1 / F2 / F3 | 이동 X / Y / Z 축 선택 |
| F4 / F5 / F6 | 회전 X / Y / Z 축 선택 |
| J / L | 선택 축의 음 / 양 방향으로 한 단계 조절 |
| F | 기본 2mm·1° ↔ 정밀 0.5mm·0.25° |
| Tab | world 축 ↔ 기타 local 축 |
| Z / R | 실행취소 / 원래 기준 기타 배치로 복원 |
| T | 스트랩 힘·표시 ON/OFF. 길이는 바꾸지 않음 |
| C / G | 전체·손 시점 / 시각·충돌 형상 보기 |
| S | 현재 후보 JSON과 전체·손 이미지 저장 |
| Space | 현재 후보에서 5초 자유 물리 및 녹화 시작 |
| E | 새 환경을 만들어 선택한 초기 배치로 복귀 |
| H / Esc | 도움말 / 종료 |

먼저 F3 → J/L로 높이를 고르고, F4~F6과 J/L로 기울기를 조절해 본다. 화면의 빨강/초록/파랑 선은 X/Y/Z 축이다. 회전 중심은 기타 actor root 원점이며 손이나 넥 접촉점이 아니다. world/local 선택은 이동과 회전에 모두 적용된다. 시점은 Gym 기본 마우스 조작이나 C로 바꾼다. 선택 축·정밀도·스트랩·시뮬레이션 시간·선택한 p/q는 터미널에 표시된다.

EDIT에서는 시간이 0에 멈춰 있으며 사용자 입력으로 초기 기타 배치를 바꾼다. 이 장면 자체는 물리적 지지 상태를 뜻하지 않는다. 위치/회전 선택 뒤 S로 후보를 저장하고 Space로 실제 움직임을 본다. PREVIEW 동안 이동·회전·스트랩 전환·후보 저장은 차단된다. 5초가 끝나면 PREVIEW COMPLETE로 시간이 멈춘다. 평형 도달 판정이 아니다. CPU 렌더링 속도에 따라 실제 대기 시간은 5초보다 길 수 있다.

PREVIEW에서 기타는 자유 상태이며 중력·접촉·PD와 선택한 스트랩만 작용한다. 시작 후 상태 setter를 차단한다. 이 도구의 관절 목표는 기존 기준의 일정 목표이며 이전 Wrist_x 흔들림·feedback·fret/strike actor는 실행하지 않는다. Torso/Spine/Chest 9관절 PD는 기존 ×2/×√2이고 root·하체는 고정이다. Thorax 이하 66관절 구조는 유지한다. 손과 기타를 부착하지 않는다.

초기값·이미지·로그·영상의 기본 위치는 다음 디렉토리다.

`/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/interactive_guitar_pose_sessions/<실행시각>/`

- `candidate_000/pose.json`: 절대 위치(m), xyzw quaternion, 기준 대비 변위·회전, 초기각·일정 PD 목표, 스트랩 조건. S를 누를 때마다 새 번호다.
- `candidate_000/images/frames/{whole_body,hands}/00000.png`: 실제 Gym 카메라 이미지. viewer 축 선은 카메라 이미지에 포함되지 않으며, 스트랩 ON 이미지는 실제 route overlay를 별도로 포함한다.
- `preview_000/initial_values.json`: 물리 시작 시 native 상태·관절각·목표·gain·조건.
- `preview_000/states.jsonl`: 240Hz 실제 상태. 영상은 `whole_body.mp4`, `hands.mp4`이며 0~5초 151frame/30fps다. 마지막 frame의 sim 시간은 5초이고 영상 길이는 약 5.033초다.
- `preview_000/report.json`: 완료 여부·실제 step 수·상태 setter 횟수·영상 정보. 종료·오류 시 확보된 부분 기록을 보존한다.

저장한 후보로 다시 열 때에는 `--candidate`에 pose.json의 절대 경로를 준다. 후보에 저장된 스트랩 ON/OFF 조건이 적용되며 `--no-strap`보다 우선한다. 실행마다 새 출력 경로를 사용하고 과거 결과를 덮어쓰지 않는다.

```bash
bash /home/ajou/yigyu/3/stability_adapter_2/open_guitar_pose_editor.sh \
  --candidate /home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/interactive_guitar_pose_v1/native_verification/session/candidate_001/pose.json
```

위 예시 후보는 기능 검증용 임의 배치이며 권장 자세가 아니다. 마음에 드는 배치를 여러 개 저장해 범위를 함께 검토한다. 후보의 축별 최솟값/최댓값을 조합한 모든 자세를 자연스럽거나 충돌 없이 가능하다고 간주하지 않는다. G로 겹침을 살펴볼 수 있지만 수치적 관통/접촉 검증은 별도다. 손 관절 최적화와 학습된 연주 연결은 이후 단계다.

검증 결과·이미지 설명은 [실제 결과 문서](/home/ajou/yigyu/3/docs/2026-10-12/stability_adapter_2/results/interactive_guitar_pose_v1/README.md:1)에 정리한다. 이번 실행 세션의 직접 사용자 마우스 조작은 미검증이며, native Xvfb 창과 실제 키 이벤트로 도구 동작을 확인한다. 스트랩 OFF의 5초 물리는 이번에 실행하지 않았으며 정적 OFF 표시와 raw native 녹화 분기를 검사했다.
